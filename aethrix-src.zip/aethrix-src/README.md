# Aethrix OS

> **A modern educational operating system built from scratch in C and x86 Assembly.**

![Version](https://img.shields.io/badge/version-v1.0-blue)
![Architecture](https://img.shields.io/badge/architecture-x86-orange)
![Language](https://img.shields.io/badge/language-C%20%7C%20Assembly-green)
![License](https://img.shields.io/badge/license-Aethrix%20Public%20License-red)

---

# About

Aethrix OS is an independently developed operating system created from scratch for educational, research, and engineering purposes.

The project focuses on understanding how operating systems work internally by implementing every major subsystem manually rather than relying on existing operating system kernels.

Its long-term goal is to become a stable operating system capable of running on both virtual machines and real x86 hardware while remaining lightweight, modular, and maintainable.

---

# Vision

The vision of Aethrix OS is to provide a complete learning platform for operating system development, networking, hardware programming, and low-level computer architecture.

Future releases aim to include:

- Modern kernel architecture
- Reliable networking stack
- Stable filesystem
- Process scheduling
- Memory management
- GUI desktop environment
- AI-powered terminal assistant
- Browser
- Package manager
- Real hardware support

---

# Current Features

- Bootloader
- Protected Mode
- VGA Text Console
- Keyboard Driver
- ATA Disk Driver
- Basic Filesystem
- User Login System
- Shell
- PCI Detection
- Network Driver Support
- Ethernet
- ARP
- IPv4
- ICMP (Ping)
- UDP
- DHCP (Work in Progress)
- DNS
- TCP (Work in Progress)
- Socket API (Work in Progress)

---

# Project Goals

- Learn operating system development
- Learn networking from the protocol level
- Build modular kernel architecture
- Support real laptops and desktops
- Support VirtualBox
- Support VMware
- Support QEMU
- Maintain clean and readable source code
- Document every subsystem

---

# Project Structure

```
AethrixOS/

boot/
kernel/
arch/
drivers/
net/
fs/
mm/
process/
shell/
users/
gui/
apps/
ai/
include/
lib/
docs/
tests/
tools/
iso/
assets/
build/
```

See **PROJECT_STRUCTURE.md** for a detailed explanation.

---

# Building

See:

- BUILD.md
- INSTALL.md

---

# Documentation

Documentation is available inside the **docs/** directory.

Topics include:

- Boot Process
- Kernel
- Memory Management
- Networking
- Filesystem
- Drivers
- Scheduler
- System Calls
- Security
- Shell
- GUI
- AI

---

# Supported Platforms

Current development targets:

- QEMU
- VirtualBox
- VMware
- x86 BIOS systems
- Legacy Intel/AMD PCs

Future targets:

- UEFI
- x86_64
- Multi-core systems

---

# Development Philosophy

Aethrix OS follows these principles:

- Simplicity
- Modularity
- Stability
- Readability
- Maintainability
- Educational Value

Every subsystem should be understandable, documented, and independently maintainable.

---

# License

This project is distributed under the **Aethrix Public License (APL)**.

See **LICENSE.md** for details.

---

# Contributing

Contributions are welcome after reviewing:

- CONTRIBUTING.md
- CODE_OF_CONDUCT.md
- STYLE_GUIDE.md

---

# Roadmap

The complete development roadmap is available in:

ROADMAP.md

---

# Security

Security issues should be reported according to:

SECURITY.md

---

# Disclaimer

Aethrix OS is an educational operating system.

It is under active development and should not be relied upon for production environments.

Features may change without notice between releases.

---

# Credits

Created and maintained by the Aethrix OS Project.

Special thanks to the operating systems and open-source communities whose publicly available documentation and educational resources have inspired this project.

---

© 2026 Aethrix OS Project. All rights reserved.
