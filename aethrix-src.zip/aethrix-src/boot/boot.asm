section .multiboot
align 4
    dd 0x1BADB002
    dd 0x00000003
    dd -(0x1BADB002 + 0x00000003)
section .text
global _start
_start:
    mov esp, stack_top
    push ebx
    push eax
    extern kernel_main
    call kernel_main
    cli
.hang: hlt
    jmp .hang
section .bss
align 16
stack_bottom: resb 65536
stack_top:
