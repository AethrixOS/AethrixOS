/* ================================================================
   AETHRIX OS - kernel.h
   Public kernel interface.

   This header exposes the declarations other translation units need
   to interoperate with kernel.c: shared types, configuration
   constants, extern globals, and public function prototypes for
   console, keyboard, disk, filesystem, PCI, and the kernel entry
   point.

   This is a declarations-only extraction. No algorithm, no boot
   sequence, no driver behavior, and no global's semantics have
   changed -- every symbol below still has exactly one definition,
   in kernel.c, unchanged from before this header existed.

   Networking (Ethernet/ARP/IPv4/ICMP/UDP/DHCP/DNS/TCP/sockets) is
   intentionally not declared here. Those types, globals, and
   functions remain private to kernel.c for now, pending whatever
   module boundary a later, carefully-scoped change establishes for
   them -- this header does not anticipate or design that boundary.
   ================================================================ */

#ifndef AETHRIX_KERNEL_H
#define AETHRIX_KERNEL_H

/* ================================================================
   1. CONFIGURATION CONSTANTS
   ================================================================ */

/** VGA text-mode video memory, mapped at the standard address. */
#define VIDEO        ((volatile char*)0xB8000)

/** VGA text-mode screen dimensions, in characters. */
#define WIDTH        80
#define HEIGHT       25

/** Displayed hostname and kernel version string. */
#define HOSTNAME     "Aethrix"
#define VERSION      "v1.0"

/** Filesystem and user-table limits. */
#define MAX_USERS    10
#define MAX_FILES    512
#define FILE_DATA    1024
#define FILE_SLOT    128
#define FILES_PER_SECTOR 4

/**
 * VGA text-mode color attribute bytes (foreground nibble; background
 * is black unless otherwise composed by the caller). Shared across
 * every subsystem that prints to the console.
 */
#define COLOR_RUST    0x0E
#define COLOR_MAGENTA 0x0D
#define COLOR_BLUE    0x09
#define COLOR_GREEN   0x0A
#define COLOR_WHITE   0x0F
#define COLOR_BLACK   0x00
#define COLOR_GRAY    0x08
#define COLOR_SHADOW  0x08

/* ================================================================
   2. PUBLIC TYPEDEFS / STRUCTURES
   ================================================================ */

/**
 * struct User (typedef User)
 *
 * A single local account: display name, password (stored in plain
 * text on disk, matching this kernel's existing persistence format
 * -- unchanged by this header extraction), and a role flag (0 =
 * standard user, nonzero = root/admin).
 */
typedef struct {
    char n[32];  /* username             */
    char p[32];  /* password             */
    int  r;      /* role: 0 = user, 1 = root */
} User;

/**
 * struct File (typedef File)
 *
 * A single filesystem entry (file or directory) in the flat,
 * fixed-size in-memory table backing Aethrix's simple filesystem.
 * parent is the 1-based index of the containing directory's entry
 * (0 means "root").
 */
typedef struct {
    char n[64];        /* name                                   */
    int  is_dir;        /* nonzero if this entry is a directory   */
    char c[FILE_DATA];  /* file contents (unused for directories) */
    int  s;             /* content size, in bytes                 */
    int  parent;         /* parent directory's entry index (1-based,
                            0 = root)                               */
} File;

/* ================================================================
   3. EXTERN VARIABLES
   ================================================================ */

/**
 * VGA cursor position, in character cells. Updated by the console
 * output routines; read by anything that needs to know where the
 * next character will be drawn (e.g. the nano editor's status line).
 */
extern int cx, cy;

/**
 * User table and count. users[] holds up to MAX_USERS accounts;
 * uc is the number currently populated. cu/cr describe the
 * currently logged-in user's name and role (cr nonzero = root).
 */
extern User users[MAX_USERS];
extern int  uc;
extern char cu[32];
extern int  cr;

/**
 * Filesystem table, count, and current working directory. files[]
 * holds up to MAX_FILES entries; fc is the number currently
 * populated. cwd is the current directory's entry index (0 = root),
 * matching File.parent's indexing convention.
 */
extern File files[MAX_FILES];
extern int  fc;
extern int  cwd;

/**
 * Disk subsystem status: whether a usable ATA disk was found at
 * boot (disk_ok), and which I/O base/drive selector it lives on.
 * Set by load_disk() during boot; read by save_disk() and by
 * sysinfo-style shell output.
 */
extern int            disk_ok;
extern unsigned short disk_base;
extern unsigned char  disk_drv_sel;

/**
 * Sound toggle: nonzero enables the PC speaker beep/jingle
 * routines, zero silences them. Shared so a shell command can flip
 * it without needing its own copy of the flag.
 */
extern int sound_on;

/**
 * TSC calibration result: PIT-measured CPU cycles per millisecond,
 * used by get_tick_ms() for all kernel timing. Set once by
 * calibrate_tsc() during boot.
 */
extern unsigned int rdtsc_ticks_per_ms;

/**
 * Multiboot-reported upper memory size, in KB, if the bootloader
 * supplied a valid memory map. Zero if unknown.
 */
extern unsigned int mb_mem_upper;

/* ================================================================
   4. FUNCTION PROTOTYPES
   ================================================================ */

/* ── VGA console ───────────────────────────────────────────────── */

/** Clears the screen and resets the cursor to the top-left. */
void cls(void);

/**
 * Prints a NUL-terminated string in a given color. prt() and its
 * color-suffixed variants (prt_m/prt_b/prt_g/prt_w/prt_gr) are the
 * primary console output routines used throughout the kernel and
 * shell.
 */
void prt(const char *s);
void prt_m(const char *s);
void prt_b(const char *s);
void prt_g(const char *s);
void prt_w(const char *s);
void prt_gr(const char *s);

/** Prints a signed/unsigned decimal integer. */
void prt_int(int n);
void prt_uint(unsigned int n);

/** Prints a byte or 32-bit value as lowercase hexadecimal. */
void prt_hex8(unsigned char b);
void prt_hex32(unsigned int v);

/** Prints a 4-byte IPv4 address in dotted-decimal form. */
void prt_ip(unsigned char *ip);

/* ── Keyboard ──────────────────────────────────────────────────── */

/** Blocks until a translated (non-modifier) keypress is available. */
char read_key(void);

/**
 * Reads a line of input into buf (capacity ml, including the NUL
 * terminator). If hidden is nonzero, echoes '*' instead of the
 * typed character (used for password entry).
 */
void input(char *buf, int ml, int hidden);

/** Blocks until Enter is pressed, discarding the keypress. */
void wait_enter(void);

/* ── Timing ────────────────────────────────────────────────────── */

/** Busy-waits for approximately ms milliseconds. */
void delay_ms(unsigned int ms);

/** Measures TSC ticks-per-millisecond using PIT channel 2. Called once at boot. */
void calibrate_tsc(void);

/** Returns the current tick count, in milliseconds, derived from the TSC. */
unsigned int get_tick_ms(void);

/* ── Sound ─────────────────────────────────────────────────────── */

/** Plays a tone of the given frequency (Hz) for the given duration (ms). */
void sound_play(unsigned int freq, unsigned int ms);

/** Plays the three-note boot chime. */
void boot_jingle(void);

/* ── CMOS / ATA ────────────────────────────────────────────────── */

/** Reads a CMOS RTC register. */
unsigned char cmos_read(unsigned char reg);

/** Converts a BCD-encoded CMOS byte to a plain integer. */
int cmos_bcd(unsigned char v);

/** Reads/writes one 256-word (512-byte) sector via ATA PIO. */
int ata_read(unsigned short base, unsigned char drv, unsigned int lba, unsigned char *buf);
int ata_write(unsigned short base, unsigned char drv, unsigned int lba, unsigned char *buf);

/** Issues ATA IDENTIFY; fills ibuf with the 512-byte identify block. */
int ata_identify(unsigned short base, unsigned char drv, unsigned char *ibuf);

/* ── Disk persistence ─────────────────────────────────────────── */

/** Probes the standard ATA I/O bases for a usable disk and loads saved state, if any. */
void load_disk(void);

/** Persists users, files, and static network configuration to disk. */
void save_disk(void);

/* ── Filesystem helpers ───────────────────────────────────────── */

/** Looks up a user by name; returns its index, or -1 if not found. */
int fuser(const char *name);

/** Looks up a file by name within the current directory; returns its index, or -1. */
int ffile(const char *name);

/** Looks up a file by name anywhere in the table; returns its index, or -1. */
int ffile_any(const char *name);

/** Writes the current working directory's path (e.g. "~/docs") into out. */
void build_pwd(char *out);

/* ── PCI ───────────────────────────────────────────────────────── */

/** Reads/writes a 32-bit PCI configuration space register via the legacy 0xCF8/0xCFC mechanism. */
unsigned int pci_read(unsigned char bus, unsigned char dev, unsigned char fn, unsigned char reg);
void pci_write(unsigned char bus, unsigned char dev, unsigned char fn, unsigned char reg, unsigned int val);

/* ── Kernel entry point ───────────────────────────────────────── */

/**
 * kernel_main()
 *
 * Entry point invoked by the bootloader trampoline. magic must be
 * the Multiboot magic value (0x2BADB002); mb_addr is the physical
 * address of the Multiboot information structure, or 0 if unused.
 * Never returns under normal operation.
 */
void kernel_main(unsigned int magic, unsigned int mb_addr);

#endif /* AETHRIX_KERNEL_H */