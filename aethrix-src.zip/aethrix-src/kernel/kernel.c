/* ================================================================
   AETHRIX OS - V1.0 Real Hardware Edition
   ================================================================ */

#include "kernel.h"

/* ── Defines ─────────────────────────────────────────────────── */
/* VIDEO, WIDTH, HEIGHT, HOSTNAME, VERSION, MAX_USERS, MAX_FILES,
   FILE_DATA, FILE_SLOT, FILES_PER_SECTOR, and the COLOR_* constants
   moved to kernel.h -- they're used by more than this file's own
   internals conceptually (console/user/file-table shape) and are
   exactly the kind of shared configuration constants kernel.h is
   for. Everything below here is unchanged. */
#define NIC_NONE     0
#define NIC_RTL      1
#define NIC_PCNET    2
#define NIC_E1000    3
#define NIC_WIFI     4
#define ETH_BUF      1536
#define PCNET_TX     8
#define PCNET_RX     8
#define PCNET_BS     1536
#define ARP_CACHE    16
#define ARP_TTL      60
#define PKT_QUEUE_SIZE 32
#define PKT_MAX        1536
#define TCP_MAX_CONN   4
#define TCP_BUF_SIZE   4096
#define SOCK_MAX       4
#define SOCK_NONE      0
#define SOCK_TCP       1
#define SOCK_UDP       2

/* ── NUD state machine (from Linux net/neighbour.h) ─────────── */
#define NUD_INCOMPLETE  0x01
#define NUD_REACHABLE   0x02
#define NUD_STALE       0x04
#define NUD_FAILED      0x20
#define NUD_REACHABLE_MS   30000
#define NUD_RETRANS_MS      1000
#define ARP_MAX_TRIES          3
#define ARP_LOCKTIME_MS     1000

/* ── Forward declarations ────────────────────────────────────── */
static int  do_ping_quiet(unsigned char *dst, int count);
static int  dns_lookup_ip(const char *domain, unsigned char *out_ip);
static int  dhcp_do(void);
static void login(void);

/* ── I/O primitives ───────────────────────────────────────────── */
static inline void outb(unsigned short p,unsigned char v){asm volatile("outb %0,%1"::"a"(v),"Nd"(p));}
static inline unsigned char inb(unsigned short p){unsigned char r;asm volatile("inb %1,%0":"=a"(r):"Nd"(p));return r;}
static inline void outw(unsigned short p,unsigned short v){asm volatile("outw %0,%1"::"a"(v),"Nd"(p));}
static inline unsigned short inw(unsigned short p){unsigned short r;asm volatile("inw %1,%0":"=a"(r):"Nd"(p));return r;}
static inline void outl(unsigned short p,unsigned int v){asm volatile("outl %0,%1"::"a"(v),"Nd"(p));}
static inline unsigned int inl(unsigned short p){unsigned int r;asm volatile("inl %1,%0":"=a"(r):"Nd"(p));return r;}

/* ── String / memory utilities ────────────────────────────────── */
static int strcmp(const char *a,const char *b){while(*a&&*a==*b){a++;b++;}return(unsigned char)*a-(unsigned char)*b;}
static int strncmp(const char *a,const char *b,int n){for(int i=0;i<n;i++){if(a[i]!=b[i])return(unsigned char)a[i]-(unsigned char)b[i];if(!a[i])return 0;}return 0;}
static int strlen(const char *s){int l=0;if(!s)return 0;while(*s++)l++;return l;}
static void strcpy(char *d,const char *s){if(!d||!s)return;while((*d++=*s++));}
static void strncpy(char *d,const char *s,int n){if(!d||!s||n<=0)return;int i=0;for(;i<n-1&&s[i];i++)d[i]=s[i];d[i]=0;}
static void strcat(char *d,const char *s){if(!d||!s)return;while(*d)d++;while((*d++=*s++));}
static void strncat_s(char *d,const char *s,int n){if(!d||!s||n<=0)return;while(*d)d++;int i=0;for(;i<n-1&&s[i];i++)d[i]=s[i];d[i]=0;}
static void memset(void *dst,unsigned char v,int n){if(!dst||n<=0)return;unsigned char *p=dst;for(int i=0;i<n;i++)p[i]=v;}
static void memcpy(void *dst,const void *src,int n){if(!dst||!src||n<=0)return;unsigned char *d=dst;const unsigned char *s=src;for(int i=0;i<n;i++)d[i]=s[i];}
static void memmove(void *dst,const void *src,int n){if(!dst||!src||n<=0)return;unsigned char *d=dst;const unsigned char *s=src;if(d<s){for(int i=0;i<n;i++)d[i]=s[i];}else{for(int i=n-1;i>=0;i--)d[i]=s[i];}}
static int memcmp(const void *a,const void *b,int n){if(!a||!b||n<=0)return 0;const unsigned char *p=a,*q=b;for(int i=0;i<n;i++)if(p[i]!=q[i])return p[i]-q[i];return 0;}
static int strstr_pos(const char *hay,const char *needle){if(!hay||!needle)return -1;int hl=strlen(hay),nl=strlen(needle);if(nl==0)return 0;if(nl>hl)return -1;for(int i=0;i<=hl-nl;i++){int ok=1;for(int j=0;j<nl;j++)if(hay[i+j]!=needle[j]){ok=0;break;}if(ok)return i;}return -1;}
static int strstr_fn(const char *hay,const char *needle){return strstr_pos(hay,needle)>=0;}
static char *strstr_ptr(const char *h,const char *n){int p=strstr_pos(h,n);return p>=0?(char*)(h+p):0;}
#define strstr strstr_fn
static char tolower_c(char c){if(c>='A'&&c<='Z')c+=32;return c;}
static int atoi(const char *s){if(!s)return 0;int n=0,neg=0;if(*s=='-'){neg=1;s++;}while(*s>='0'&&*s<='9')n=n*10+(*s++)-'0';return neg?-n:n;}

/* ── VGA console ──────────────────────────────────────────────── */
int cx=0,cy=0; /* declared extern in kernel.h */
static void schar_attr(int x,int y,char ch,char attr){if(x<0||x>=WIDTH||y<0||y>=HEIGHT)return;int o=(y*WIDTH+x)*2;VIDEO[o]=ch;VIDEO[o+1]=attr;}
void cls(void){for(int y=0;y<HEIGHT;y++)for(int x=0;x<WIDTH;x++)schar_attr(x,y,' ',COLOR_SHADOW);cx=0;cy=0;}
static void scroll(void){for(int y=0;y<HEIGHT-1;y++)for(int x=0;x<WIDTH;x++){int s=((y+1)*WIDTH+x)*2,d=(y*WIDTH+x)*2;VIDEO[d]=VIDEO[s];VIDEO[d+1]=VIDEO[s+1];}for(int x=0;x<WIDTH;x++)schar_attr(x,HEIGHT-1,' ',COLOR_SHADOW);}
static void hcur(void){schar_attr(cx,cy,' ',COLOR_SHADOW);}
static void scur(void){schar_attr(cx,cy,'|',COLOR_RUST);}
static void pchar_attr(char ch,char attr){hcur();if(ch=='\n'){cx=0;cy++;if(cy>=HEIGHT){scroll();cy=HEIGHT-1;}scur();return;}if(ch=='\b'){if(cx>0){cx--;schar_attr(cx,cy,' ',COLOR_SHADOW);}scur();return;}schar_attr(cx,cy,ch,attr);cx++;if(cx>=WIDTH){cx=0;cy++;if(cy>=HEIGHT){scroll();cy=HEIGHT-1;}}scur();}
static void pchar_a(char ch){pchar_attr(ch,COLOR_RUST);}
static void pchar_m(char ch){pchar_attr(ch,COLOR_MAGENTA);}
static void pchar_b(char ch){pchar_attr(ch,COLOR_BLUE);}
static void pchar_g(char ch){pchar_attr(ch,COLOR_GREEN);}
static void pchar_w(char ch){pchar_attr(ch,COLOR_WHITE);}
static void pchar_gr(char ch){pchar_attr(ch,COLOR_GRAY);}
void prt(const char *s){if(!s)return;while(*s)pchar_a(*s++);}
void prt_m(const char *s){if(!s)return;while(*s)pchar_m(*s++);}
void prt_b(const char *s){if(!s)return;while(*s)pchar_b(*s++);}
void prt_g(const char *s){if(!s)return;while(*s)pchar_g(*s++);}
void prt_w(const char *s){if(!s)return;while(*s)pchar_w(*s++);}
void prt_gr(const char *s){if(!s)return;while(*s)pchar_gr(*s++);}
void prt_int(int n){if(n<0){pchar_a('-');n=-n;}if(n>=10)prt_int(n/10);pchar_a('0'+n%10);}
void prt_uint(unsigned int n){if(n>=10)prt_uint(n/10);pchar_a('0'+n%10);}
void prt_hex8(unsigned char b){const char *h="0123456789abcdef";pchar_a(h[b>>4]);pchar_a(h[b&0xF]);}
void prt_hex32(unsigned int v){prt_hex8(v>>24);prt_hex8(v>>16);prt_hex8(v>>8);prt_hex8(v);}
void prt_ip(unsigned char *ip){if(!ip)return;prt_uint(ip[0]);pchar_a('.');prt_uint(ip[1]);pchar_a('.');prt_uint(ip[2]);pchar_a('.');prt_uint(ip[3]);}

/* ── Keyboard ─────────────────────────────────────────────────── */
static int shift_held=0,ctrl_held=0,caps_lock=0;
static char kb_translate(unsigned char sc){
    if(sc==0x2A||sc==0x36){shift_held=1;return 0;}
    if(sc==0xAA||sc==0xB6){shift_held=0;return 0;}
    if(sc==0x1D){ctrl_held=1;return 0;}
    if(sc==0x9D){ctrl_held=0;return 0;}
    if(sc==0x3A){caps_lock^=1;return 0;}
    static const char map[128]={0,27,'1','2','3','4','5','6','7','8','9','0','-','=','\b','\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',0,'a','s','d','f','g','h','j','k','l',';',39,'`',0,92,'z','x','c','v','b','n','m',',','.','/',0,'*',0,' '};
    static const char smap[128]={0,27,'!','@','#','$','%','^','&','*','(',')','_','+','\b','\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',0,'A','S','D','F','G','H','J','K','L',':','"','~',0,'|','Z','X','C','V','B','N','M','<','>','?',0,'*',0,' '};
    if(sc==0x52)return'0';if(sc==0x4F)return'1';if(sc==0x50)return'2';if(sc==0x51)return'3';
    if(sc==0x4B)return'4';if(sc==0x4C)return'5';if(sc==0x4D)return'6';if(sc==0x47)return'7';
    if(sc==0x48)return'8';if(sc==0x49)return'9';if(sc==0x53)return'.';
    if(ctrl_held&&sc==0x1F)return 19;
    if(ctrl_held&&sc==0x2D)return 24;
    if(ctrl_held&&sc==0x2E)return 3;
    if(ctrl_held)return 0;
    if(sc&0x80)return 0;
    if(sc>=128)return 0;
    char c=shift_held?smap[sc]:map[sc];
    if(caps_lock&&c>='a'&&c<='z')c-=32;
    if(caps_lock&&c>='A'&&c<='Z'&&!shift_held)c+=32;
    return c;
}
char read_key(void){while(1){unsigned char st=inb(0x64);if(!(st&0x01))continue;if(st&0x20){inb(0x60);continue;}char c=kb_translate(inb(0x60));if(c)return c;}}
void delay_ms(unsigned int ms){for(unsigned int m=0;m<ms;m++)for(volatile unsigned int i=0;i<20000;i++);}
int sound_on=1; /* declared extern in kernel.h */
void sound_play(unsigned int freq,unsigned int ms){if(!sound_on||freq==0)return;unsigned int div=1193180/freq;outb(0x43,0xB6);outb(0x42,div&0xFF);outb(0x42,div>>8);unsigned char t=inb(0x61);outb(0x61,t|3);delay_ms(ms);t=inb(0x61);outb(0x61,t&~3);}
void boot_jingle(void){sound_play(262,100);sound_play(330,100);sound_play(392,150);}

/* ── TSC calibration using PIT channel 2 ─────────────────────── */
unsigned int rdtsc_ticks_per_ms = 2000; /* declared extern in kernel.h */
void calibrate_tsc(void){
    unsigned int start_lo, end_lo;
    outb(0x43, 0xB0);
    outb(0x42, 0x0B);
    outb(0x42, 0xE9);
    unsigned char gate = inb(0x61);
    outb(0x61, (gate & 0xFD) | 0x01);
    asm volatile("rdtsc":"=a"(start_lo)::"edx");
    int timeout = 10000000;
    while(!(inb(0x61) & 0x20) && timeout-- > 0);
    asm volatile("rdtsc":"=a"(end_lo)::"edx");
    outb(0x61, gate);
    if(timeout > 0){
        unsigned int elapsed = end_lo - start_lo;
        if(elapsed > 0){
            rdtsc_ticks_per_ms = elapsed / 50;
            if(rdtsc_ticks_per_ms < 100)     rdtsc_ticks_per_ms = 100;
            if(rdtsc_ticks_per_ms > 10000000) rdtsc_ticks_per_ms = 10000000;
        }
    }
}
unsigned int get_tick_ms(void){
    unsigned int lo;
    asm volatile("rdtsc":"=a"(lo)::"edx");
    return lo / rdtsc_ticks_per_ms;
}

/* ── Boot screen ──────────────────────────────────────────────── */
static void boot_screen(void){
    for(int y=0;y<HEIGHT;y++)for(int x=0;x<WIDTH;x++)schar_attr(x,y,' ',0x00);
    for(int x=0;x<WIDTH;x++)schar_attr(x,0,205,COLOR_GRAY);
    for(int x=0;x<WIDTH;x++)schar_attr(x,HEIGHT-1,205,COLOR_GRAY);
    for(int y=0;y<HEIGHT;y++){schar_attr(0,y,186,COLOR_GRAY);schar_attr(WIDTH-1,y,186,COLOR_GRAY);}
    schar_attr(0,0,201,COLOR_GRAY);schar_attr(WIDTH-1,0,187,COLOR_GRAY);
    schar_attr(0,HEIGHT-1,200,COLOR_GRAY);schar_attr(WIDTH-1,HEIGHT-1,188,COLOR_GRAY);
    static const char *logo[]={"     A       EEEEE  TTTTT  H   H  RRRR   III  X   X     ","    A A      E        T    H   H  R   R   I    X X      ","   AAAAA     EEEE     T    HHHHH  RRRR    I     X       ","  A     A    E        T    H   H  R  R    I    X X      "," A       A   EEEEE    T    H   H  R   R  III  X   X     ",};
    for(int i=0;i<5;i++)for(int j=0;logo[i][j]&&j<78;j++)if(j+1<WIDTH-1&&i+4<HEIGHT-1)schar_attr(j+1,i+4,logo[i][j],COLOR_RUST);
    static const char *lt="[ Loading Aethrix v1.0... ]";
    int lt_len=strlen(lt),lx=(WIDTH-lt_len)/2;
    for(int i=0;lt[i];i++)schar_attr(lx+i,15,lt[i],0x70);
    static const char *be="[                    ]";
    int bx=(WIDTH-22)/2;
    for(int i=0;be[i];i++)schar_attr(bx+i,17,be[i],0x70);
    static const char blocks[]={176,177,178,219};
    for(int p=0;p<=20;p++){
        for(int b=0;b<4;b++){
            if(p<20)schar_attr(bx+1+p,17,blocks[b],0x70);
            char pct[8];pct[0]=' ';pct[1]='0'+(p*5)/10;pct[2]='0'+(p*5)%10;pct[3]='%';pct[4]=' ';pct[5]=0;
            for(int i=0;pct[i];i++)schar_attr(bx+7+i,18,pct[i],0x70);
            delay_ms(30);
        }
    }
    delay_ms(60000);
}

/* ── CMOS / ATA ───────────────────────────────────────────────── */
unsigned char cmos_read(unsigned char r){outb(0x70,r);return inb(0x71);}
int cmos_bcd(unsigned char v){return(v/16)*10+(v&0xF);}
static void ata_delay(unsigned short b){inb(b+0x206);inb(b+0x206);inb(b+0x206);inb(b+0x206);}
static int ata_wait_bsy(unsigned short b){for(int t=0;t<500000;t++)if(!(inb(b+7)&0x80))return 1;return 0;}
static int ata_wait_drq(unsigned short b){for(int t=0;t<500000;t++){unsigned char s=inb(b+7);if(s&0x01)return 0;if(s&0x08)return 1;}return 0;}
static void ata_setup(unsigned short b,unsigned char drv,unsigned int lba){outb(b+6,0xE0|(drv<<4)|((lba>>24)&0x0F));ata_delay(b);outb(b+2,1);outb(b+3,(unsigned char)lba);outb(b+4,(unsigned char)(lba>>8));outb(b+5,(unsigned char)(lba>>16));}
int ata_read(unsigned short b,unsigned char drv,unsigned int lba,unsigned char *buf){if(!ata_wait_bsy(b))return 0;ata_setup(b,drv,lba);outb(b+7,0x20);ata_delay(b);if(!ata_wait_bsy(b)||!ata_wait_drq(b))return 0;for(int i=0;i<256;i++){unsigned short w=inw(b);buf[i*2]=w&0xFF;buf[i*2+1]=w>>8;}return 1;}
int ata_write(unsigned short b,unsigned char drv,unsigned int lba,unsigned char *buf){if(!ata_wait_bsy(b))return 0;ata_setup(b,drv,lba);outb(b+7,0x30);ata_delay(b);if(!ata_wait_drq(b))return 0;for(int i=0;i<256;i++)outw(b,(unsigned short)(buf[i*2]|(buf[i*2+1]<<8)));if(!ata_wait_bsy(b))return 0;outb(b+7,0xE7);if(!ata_wait_bsy(b))return 0;return 1;}
int ata_identify(unsigned short b,unsigned char drv,unsigned char *ibuf){outb(b+6,0xA0|(drv<<4));ata_delay(b);unsigned char s=inb(b+7);if(s==0xFF||s==0)return 0;outb(b+2,0);outb(b+3,0);outb(b+4,0);outb(b+5,0);outb(b+7,0xEC);ata_delay(b);s=inb(b+7);if(!s)return 0;if(!ata_wait_bsy(b))return 0;if(inb(b+4)||inb(b+5))return 0;for(int t=0;t<100000;t++){s=inb(b+7);if(s&0x01)return 0;if(s&0x08)break;}if(!(inb(b+7)&0x08))return 0;for(int i=0;i<256;i++){unsigned short w=inw(b);ibuf[i*2]=w&0xFF;ibuf[i*2+1]=w>>8;}return 1;}

/* ── Users / Files ────────────────────────────────────────────── */
/* User and File typedefs moved to kernel.h. users/uc/files/fc/cu/cr/
   cwd are declared extern there; defined here exactly as before,
   minus the 'static' keyword so kernel.h's extern declarations
   resolve to these definitions. */
User users[MAX_USERS];
int uc=0;
File files[MAX_FILES];
int fc=0;
char cu[32]="";
int cr=0;
int cwd=0;
int fuser(const char *n){if(!n)return -1;for(int i=0;i<uc;i++)if(strcmp(users[i].n,n)==0)return i;return -1;}
int ffile(const char *n){if(!n)return -1;for(int i=0;i<fc;i++)if(strcmp(files[i].n,n)==0&&files[i].parent==cwd)return i;return -1;}
int ffile_any(const char *n){if(!n)return -1;for(int i=0;i<fc;i++)if(strcmp(files[i].n,n)==0)return i;return -1;}
void build_pwd(char *out){if(!out)return;if(cwd==0){strcpy(out,"~");return;}static int chain[64];int depth=0;int cur=cwd;while(cur>0&&depth<63){chain[depth]=cur;depth++;cur=(cur>0&&cur<=fc)?files[cur-1].parent:0;}strcpy(out,"~");if(depth==0)return;for(int i=depth-1;i>=0;i--){strcat(out,"/");if(chain[i]>0&&chain[i]<=fc)strcat(out,files[chain[i]-1].n);}}

/* ── PCI ──────────────────────────────────────────────────────── */
unsigned int pci_read(unsigned char bus,unsigned char dev,unsigned char fn,unsigned char reg){outl(0xCF8,0x80000000|((unsigned int)bus<<16)|((unsigned int)dev<<11)|((unsigned int)fn<<8)|(reg&0xFC));return inl(0xCFC);}
void pci_write(unsigned char bus,unsigned char dev,unsigned char fn,unsigned char reg,unsigned int val){outl(0xCF8,0x80000000|((unsigned int)bus<<16)|((unsigned int)dev<<11)|((unsigned int)fn<<8)|(reg&0xFC));outl(0xCFC,val);}

/* ── Network statistics ───────────────────────────────────────── */
typedef struct{
    unsigned int tx_packets,rx_packets,tx_errors,rx_errors,rx_dropped;
    unsigned int arp_requests_sent,arp_replies_sent,arp_replies_recv;
    unsigned int arp_cache_hits,arp_cache_misses;
    unsigned int dhcp_discover,dhcp_offer,dhcp_request,dhcp_ack;
    unsigned int dns_queries,dns_replies,dns_timeouts;
    unsigned int icmp_echo_sent,icmp_echo_recv,icmp_timeout;
    unsigned int tcp_connect,tcp_data_tx,tcp_data_rx,tcp_rst,tcp_timeout;
    unsigned int ip_cksum_errors,ip_malformed,timeouts;
}NetStats;
static NetStats net_stats;
#define net_tx (net_stats.tx_packets)
#define net_rx (net_stats.rx_packets)

/* ── Packet queue ─────────────────────────────────────────────── */
typedef struct{unsigned char data[PKT_MAX];int len;int used;}PktEntry;
static PktEntry pkt_queue[PKT_QUEUE_SIZE];
static int pkt_q_head=0,pkt_q_tail=0;

static int pkt_queue_push(unsigned char *d,int l){
    if(!d||l<=0||l>PKT_MAX)return 0;
    int next=(pkt_q_tail+1)%PKT_QUEUE_SIZE;
    if(next==pkt_q_head){net_stats.rx_dropped++;return 0;}
    memcpy(pkt_queue[pkt_q_tail].data,d,l);
    pkt_queue[pkt_q_tail].len=l;
    pkt_queue[pkt_q_tail].used=0;
    pkt_q_tail=next;
    return 1;
}
static unsigned char *pkt_queue_peek(int *len_out){
    if(pkt_q_head==pkt_q_tail){if(len_out)*len_out=0;return 0;}
    if(len_out)*len_out=pkt_queue[pkt_q_head].len;
    return pkt_queue[pkt_q_head].data;
}
static void pkt_queue_pop(void){if(pkt_q_head==pkt_q_tail)return;pkt_q_head=(pkt_q_head+1)%PKT_QUEUE_SIZE;}

/* ── virt_to_phys (identity mapped kernel) ───────────────────── */
static inline unsigned int virt_to_phys(void *v){return(unsigned int)v;}

/* ── NIC drivers ──────────────────────────────────────────────── */
static int            nic_type=NIC_NONE;
static unsigned short nic_io=0;
static unsigned int   nic_mmio=0;
static unsigned char  nic_mac[6]={0};
static unsigned char  tx_buf[ETH_BUF] __attribute__((aligned(16)));
static unsigned char  rtl_rx_ring[8192+16+1500] __attribute__((aligned(16)));
static unsigned char  raw_pkt[ETH_BUF];

/* ── RTL8139 ──────────────────────────────────────────────────── */
static int rtl_tx_cur=0,rtl_rx_ptr=0;
static void rtl_init(unsigned short io){
    outb(io+0x52,0);delay_ms(10);
    outb(io+0x37,0x10);for(int t=0;t<100000;t++)if(!(inb(io+0x37)&0x10))break;
    for(int i=0;i<6;i++)nic_mac[i]=inb(io+i);
    outl(io+0x30,virt_to_phys(rtl_rx_ring));
    outl(io+0x44,0x0000070F);outl(io+0x40,0x03000700);
    outb(io+0x37,0x0C);outw(io+0x3C,0x0005);
    rtl_rx_ptr=0;rtl_tx_cur=0;
}
static int rtl_send(unsigned short io,unsigned char *d,unsigned int l){
    if(!d||l==0||l>1500)return 0;
    int free=0;
    for(int t=0;t<500000;t++)if(!(inl(io+0x10+rtl_tx_cur*4)&0x2000)){free=1;break;}
    if(!free){net_stats.tx_errors++;return 0;}
    memcpy(tx_buf,d,l);
    if(l<60){memset(tx_buf+l,0,60-l);l=60;}
    outl(io+0x20+rtl_tx_cur*4,virt_to_phys(tx_buf));
    outl(io+0x10+rtl_tx_cur*4,l&0x1FFF);
    int ok=0;
    for(int t=0;t<500000;t++)if(inl(io+0x10+rtl_tx_cur*4)&0x8000){ok=1;break;}
    if(!ok){net_stats.tx_errors++;return 0;}
    rtl_tx_cur=(rtl_tx_cur+1)%4;net_stats.tx_packets++;return 1;
}
static int rtl_recv(unsigned short io,unsigned char *o,int m){
    if(!o||m<=0)return 0;
    rtl_rx_ptr=rtl_rx_ptr%8192;
    unsigned short cbr=inw(io+0x3A);
    if((rtl_rx_ptr&0x1FFF)==(cbr&0x1FFF))return 0;
    unsigned char *h=rtl_rx_ring+rtl_rx_ptr;
    unsigned short status=(unsigned short)(h[1]<<8)|h[0];
    unsigned short len=(unsigned short)(h[3]<<8)|h[2];
    if(!(status&0x0001)||len<8||len>1518){
        net_stats.rx_errors++;rtl_rx_ptr=cbr&0x1FFF;
        outw(io+0x38,(unsigned short)((rtl_rx_ptr-16)&0xFFFF));return 0;
    }
    int dl=(int)len-4;if(dl>m)dl=m;
    if(dl<=0){net_stats.rx_errors++;return 0;}
    int ring_sz=8192+16+1500;
    for(int i=0;i<dl;i++)o[i]=rtl_rx_ring[(rtl_rx_ptr+4+i)%ring_sz];
    rtl_rx_ptr=(rtl_rx_ptr+len+4+3)&~3;
    if(rtl_rx_ptr>=8192)rtl_rx_ptr-=8192;
    outw(io+0x38,(unsigned short)((rtl_rx_ptr-16)&0xFFFF));
    net_stats.rx_packets++;return dl;
}

/* ── PCnet ────────────────────────────────────────────────────── */
static unsigned char pcnet_tb[PCNET_TX][PCNET_BS] __attribute__((aligned(16)));
static unsigned char pcnet_rb[PCNET_RX][PCNET_BS] __attribute__((aligned(16)));
typedef struct __attribute__((packed)){unsigned int addr;unsigned short bcnt;unsigned short status;unsigned int msg_len;unsigned int reserved;}PCNetDesc;
static PCNetDesc pcnet_tx_ring[PCNET_TX] __attribute__((aligned(16)));
static PCNetDesc pcnet_rx_ring[PCNET_RX] __attribute__((aligned(16)));
typedef struct __attribute__((packed)){unsigned short mode;unsigned char rlen;unsigned char tlen;unsigned char mac[6];unsigned short reserved;unsigned int laddr;unsigned int rx_desc;unsigned int tx_desc;}PCNetInit;
static PCNetInit pcnet_ib __attribute__((aligned(32)));
static int pcnet_tc=0,pcnet_rc=0;
static void pcnet_write_csr(unsigned short io,unsigned short idx,unsigned short val){outw(io+0x12,idx);outw(io+0x10,val);}
static unsigned short pcnet_read_csr(unsigned short io,unsigned short idx){outw(io+0x12,idx);return inw(io+0x10);}
static void pcnet_setup(unsigned short io){
    inw(io+0x14);delay_ms(10);
    outw(io+0x12,18);unsigned short b18=inw(io+0x16);b18&=~(1<<7);outw(io+0x16,b18);
    for(int i=0;i<6;i++)nic_mac[i]=inb(io+i);
    memset(&pcnet_ib,0,sizeof(pcnet_ib));
    pcnet_ib.mode=0;pcnet_ib.rlen=(3<<4);pcnet_ib.tlen=(3<<4);
    for(int i=0;i<6;i++)pcnet_ib.mac[i]=nic_mac[i];
    pcnet_ib.rx_desc=virt_to_phys(pcnet_rx_ring);
    pcnet_ib.tx_desc=virt_to_phys(pcnet_tx_ring);
    for(int i=0;i<PCNET_RX;i++){pcnet_rx_ring[i].addr=virt_to_phys(pcnet_rb[i]);pcnet_rx_ring[i].bcnt=(unsigned short)(-(int)PCNET_BS)|0xF000;pcnet_rx_ring[i].status=0x8000;pcnet_rx_ring[i].msg_len=0;pcnet_rx_ring[i].reserved=0;}
    for(int i=0;i<PCNET_TX;i++){pcnet_tx_ring[i].addr=virt_to_phys(pcnet_tb[i]);pcnet_tx_ring[i].bcnt=0;pcnet_tx_ring[i].status=0;pcnet_tx_ring[i].msg_len=0;pcnet_tx_ring[i].reserved=0;}
    unsigned int ia=virt_to_phys(&pcnet_ib);
    pcnet_write_csr(io,1,(unsigned short)(ia&0xFFFF));
    pcnet_write_csr(io,2,(unsigned short)(ia>>16));
    pcnet_write_csr(io,0,0x0001);
    for(int i=0;i<100000;i++)if(pcnet_read_csr(io,0)&0x0100)break;
    pcnet_write_csr(io,0,0x0042);pcnet_tc=0;pcnet_rc=0;
}
static int pcnet_send(unsigned short io,unsigned char *d,unsigned int l){
    if(!d||l==0||l>PCNET_BS)return 0;
    PCNetDesc *td=&pcnet_tx_ring[pcnet_tc];
    int owned=0;for(int t=0;t<1000000;t++)if(!(td->status&0x8000)){owned=1;break;}
    if(!owned){net_stats.tx_errors++;return 0;}
    if(l<60){memcpy(pcnet_tb[pcnet_tc],d,l);memset(pcnet_tb[pcnet_tc]+l,0,60-l);l=60;}
    else memcpy(pcnet_tb[pcnet_tc],d,l);
    td->addr=virt_to_phys(pcnet_tb[pcnet_tc]);td->bcnt=(unsigned short)(-(int)l)|0xF000;td->msg_len=0;td->status=0x8300;
    pcnet_write_csr(io,0,0x0048);pcnet_tc=(pcnet_tc+1)%PCNET_TX;net_stats.tx_packets++;return 1;
}
static int pcnet_recv(unsigned short io,unsigned char *o,int m){
    if(!o||m<=0)return 0;
    for(int checked=0;checked<PCNET_RX;checked++){
        PCNetDesc *rd=&pcnet_rx_ring[pcnet_rc];
        if(rd->status&0x8000){pcnet_rc=(pcnet_rc+1)%PCNET_RX;continue;}
        if(rd->status&0x4000){net_stats.rx_errors++;rd->bcnt=(unsigned short)(-(int)PCNET_BS)|0xF000;rd->msg_len=0;rd->status=0x8000;pcnet_rc=(pcnet_rc+1)%PCNET_RX;continue;}
        int len=(int)(rd->msg_len&0x0FFF)-4;
        if(len<=0||len>m||len>PCNET_BS){net_stats.rx_errors++;rd->bcnt=(unsigned short)(-(int)PCNET_BS)|0xF000;rd->msg_len=0;rd->status=0x8000;pcnet_rc=(pcnet_rc+1)%PCNET_RX;continue;}
        memcpy(o,pcnet_rb[pcnet_rc],len);
        rd->msg_len=0;rd->bcnt=(unsigned short)(-(int)PCNET_BS)|0xF000;rd->status=0x8000;
        pcnet_rc=(pcnet_rc+1)%PCNET_RX;net_stats.rx_packets++;return len;
    }
    return 0;
}

/* ── E1000 ────────────────────────────────────────────────────── */
#define E1000_TX_DESC  16
#define E1000_RX_DESC  16
#define E1000_PKT_SIZE 2048
#define ROUND_UP(n,a) (((n)+(a)-1)&~((a)-1))
typedef struct __attribute__((packed)){unsigned long long addr;unsigned short length;unsigned char cso;unsigned char cmd;unsigned char status;unsigned char css;unsigned short special;}E1000TxDesc;
typedef struct __attribute__((packed)){unsigned long long addr;unsigned short length;unsigned char checksum;unsigned char status;unsigned char errors;unsigned short special;}E1000RxDesc;
static E1000TxDesc e1000_tx_ring[E1000_TX_DESC] __attribute__((aligned(16)));
static E1000RxDesc e1000_rx_ring[E1000_RX_DESC] __attribute__((aligned(16)));
static unsigned char e1000_tx_buf[E1000_TX_DESC][E1000_PKT_SIZE] __attribute__((aligned(16)));
static unsigned char e1000_rx_buf[E1000_RX_DESC][E1000_PKT_SIZE] __attribute__((aligned(16)));
static unsigned int e1000_mmio=0;
static int e1000_tx_tail=0,e1000_rx_tail=0,e1000_rx_head=0;
static inline unsigned int  e1000_rd(unsigned int r){return*(volatile unsigned int*)(e1000_mmio+r);}
static inline void e1000_wr(unsigned int r,unsigned int v){*(volatile unsigned int*)(e1000_mmio+r)=v;}
static void e1000_init(unsigned int bar0){
    e1000_mmio=bar0&0xFFFFFFF0;
    e1000_wr(0x0000,e1000_rd(0x0000)|0x04000000);delay_ms(10);
    unsigned int ral=e1000_rd(0x5400),rah=e1000_rd(0x5404);
    nic_mac[0]=ral&0xFF;nic_mac[1]=(ral>>8)&0xFF;nic_mac[2]=(ral>>16)&0xFF;nic_mac[3]=(ral>>24)&0xFF;nic_mac[4]=rah&0xFF;nic_mac[5]=(rah>>8)&0xFF;
    for(int i=0;i<128;i++)e1000_wr(0x5200+i*4,0);
    for(int i=0;i<E1000_TX_DESC;i++){memset(&e1000_tx_ring[i],0,sizeof(E1000TxDesc));e1000_tx_ring[i].addr=(unsigned long long)virt_to_phys(e1000_tx_buf[i]);}
    e1000_wr(0x3800,virt_to_phys(e1000_tx_ring));e1000_wr(0x3804,0);
    e1000_wr(0x3808,ROUND_UP(E1000_TX_DESC*(int)sizeof(E1000TxDesc),128));
    e1000_wr(0x3810,0);e1000_wr(0x3818,0);e1000_wr(0x0400,0x0003010A);
    for(int i=0;i<E1000_RX_DESC;i++){memset(&e1000_rx_ring[i],0,sizeof(E1000RxDesc));e1000_rx_ring[i].addr=(unsigned long long)virt_to_phys(e1000_rx_buf[i]);}
    e1000_wr(0x2800,virt_to_phys(e1000_rx_ring));e1000_wr(0x2804,0);
    e1000_wr(0x2808,ROUND_UP(E1000_RX_DESC*(int)sizeof(E1000RxDesc),128));
    e1000_wr(0x2810,0);e1000_wr(0x2818,E1000_RX_DESC-1);
    e1000_wr(0x0100,0x04008002);
    e1000_wr(0x5400,ral);e1000_wr(0x5404,rah|0x80000000);
    e1000_rx_head=0;e1000_rx_tail=E1000_RX_DESC-1;e1000_tx_tail=0;
}
static int e1000_send(unsigned char *d,unsigned int l){
    if(!d||l==0||l>1500)return 0;
    if(l<60){memcpy(e1000_tx_buf[e1000_tx_tail],d,l);memset(e1000_tx_buf[e1000_tx_tail]+l,0,60-l);l=60;}
    else memcpy(e1000_tx_buf[e1000_tx_tail],d,l);
    E1000TxDesc *td=&e1000_tx_ring[e1000_tx_tail];
    td->addr=(unsigned long long)virt_to_phys(e1000_tx_buf[e1000_tx_tail]);
    td->length=(unsigned short)l;td->cmd=0x0B;td->status=0;
    e1000_tx_tail=(e1000_tx_tail+1)%E1000_TX_DESC;e1000_wr(0x3818,e1000_tx_tail);
    int ok=0;for(int t=0;t<500000;t++)if(td->status&0x0F){ok=1;break;}
    if(!ok){net_stats.tx_errors++;return 0;}
    net_stats.tx_packets++;return 1;
}
static int e1000_recv(unsigned char *o,int m){
    if(!o||m<=0)return 0;
    E1000RxDesc *rd=&e1000_rx_ring[e1000_rx_head];
    if(!(rd->status&0x01))return 0;
    int len=(int)rd->length;if(len<=0||len>m)len=m;
    memcpy(o,e1000_rx_buf[e1000_rx_head],len);
    rd->status=0;e1000_rx_tail=e1000_rx_head;e1000_wr(0x2818,e1000_rx_tail);
    e1000_rx_head=(e1000_rx_head+1)%E1000_RX_DESC;net_stats.rx_packets++;return len;
}

/* ── Unified NIC ──────────────────────────────────────────────── */
static int nic_send_raw(unsigned char *d,unsigned int l){if(nic_type==NIC_RTL)return rtl_send(nic_io,d,l);if(nic_type==NIC_PCNET)return pcnet_send(nic_io,d,l);if(nic_type==NIC_E1000)return e1000_send(d,l);return 0;}
static int nic_recv_raw(unsigned char *o,int m){if(nic_type==NIC_RTL)return rtl_recv(nic_io,o,m);if(nic_type==NIC_PCNET)return pcnet_recv(nic_io,o,m);if(nic_type==NIC_E1000)return e1000_recv(o,m);return 0;}
static void net_pump(void){unsigned char tmp[ETH_BUF];int l=nic_recv_raw(tmp,ETH_BUF);if(l>0)pkt_queue_push(tmp,l);}

/* ── Network headers ──────────────────────────────────────────── */
typedef struct __attribute__((packed)){unsigned char dst[6];unsigned char src[6];unsigned short ethertype;}EthHdr;
typedef struct __attribute__((packed)){unsigned char ver_ihl;unsigned char dscp;unsigned short total_len;unsigned short id;unsigned short flags_frag;unsigned char ttl;unsigned char proto;unsigned short checksum;unsigned char src_ip[4];unsigned char dst_ip[4];}IPhdr;
typedef struct __attribute__((packed)){unsigned char type;unsigned char code;unsigned short checksum;unsigned short id;unsigned short seq;}ICMPhdr;
typedef struct __attribute__((packed)){unsigned short src_port;unsigned short dst_port;unsigned short length;unsigned short checksum;}UDPhdr;
typedef struct __attribute__((packed)){unsigned char op;unsigned char htype;unsigned char hlen;unsigned char hops;unsigned int xid;unsigned short secs;unsigned short flags;unsigned char ciaddr[4];unsigned char yiaddr[4];unsigned char siaddr[4];unsigned char giaddr[4];unsigned char chaddr[16];unsigned char sname[64];unsigned char file[128];unsigned char options[312];}DHCPpkt;
typedef struct __attribute__((packed)){unsigned short src_port;unsigned short dst_port;unsigned int seq_num;unsigned int ack_num;unsigned char data_offset;unsigned char flags;unsigned short window;unsigned short checksum;unsigned short urgent;}TCPHdr;

/* ── Network state ────────────────────────────────────────────── */
static unsigned char net_ip[4]  ={10,0,2,15};
static unsigned char net_gw[4]  ={10,0,2,2};
static unsigned char net_mask[4]={255,255,255,0};
static unsigned char net_dns[4] ={8,8,8,8};
static int           net_up=0;
static unsigned char bcast_mac[6]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

/* ── Byte-order ───────────────────────────────────────────────── */
static unsigned short htons_f(unsigned short v){return(v>>8)|(v<<8);}
static unsigned int   htonl_f(unsigned int v){return((v>>24)&0xFF)|((v>>8)&0xFF00)|((v<<8)&0xFF0000)|((v<<24)&0xFF000000);}
static unsigned int   ntohl_f(unsigned int v){return htonl_f(v);}

/* ── IP checksum ──────────────────────────────────────────────── */
static unsigned short ip_cksum(void *data,int len){
    if(!data||len<=0)return 0xFFFF;
    unsigned short *p=data;unsigned int s=0;
    while(len>1){s+=*p++;len-=2;}
    if(len)s+=(unsigned char)*(unsigned char*)p;
    while(s>>16)s=(s&0xFFFF)+(s>>16);
    return~(unsigned short)s;
}
static unsigned short ip_id_ctr=0x1337;

/* ── IPv4 validation ──────────────────────────────────────────── */
static int ipv4_validate(IPhdr *iph,int payload_len){
    if(!iph)return 0;
    if((iph->ver_ihl>>4)!=4)return 0;
    int ihl=(iph->ver_ihl&0x0F)*4;
    if(ihl<20)return 0;
    int total=(int)htons_f(iph->total_len);
    if(total<ihl||total>payload_len)return 0;
    if(iph->ttl==0)return 0;
    unsigned short ff=htons_f(iph->flags_frag);
    if((ff&0x2000)||(ff&0x1FFF))return 0;
    unsigned short saved=iph->checksum;
    iph->checksum=0;
    unsigned short calc=ip_cksum(iph,ihl);
    iph->checksum=saved;
    if(calc!=saved){net_stats.ip_cksum_errors++;return 0;}
    return 1;
}

/* ================================================================
   ARP SUBSYSTEM — Linux-derived NUD state machine
   ================================================================ */
typedef struct{
    unsigned char  ip[4];
    unsigned char  mac[6];
    int            nud_state;
    unsigned int   updated_ms;
    unsigned int   used_ms;
    int            probes_sent;
    unsigned int   last_probe_ms;
}ARPEntry;
static ARPEntry arp_cache[ARP_CACHE];

static void arp_expire(void){
    unsigned int now=get_tick_ms();
    for(int i=0;i<ARP_CACHE;i++){
        if(arp_cache[i].nud_state==0)continue;
        if(arp_cache[i].nud_state==NUD_REACHABLE&&
           (now-arp_cache[i].updated_ms)>NUD_REACHABLE_MS)
            arp_cache[i].nud_state=NUD_STALE;
        if(arp_cache[i].nud_state==NUD_STALE&&
           (now-arp_cache[i].used_ms)>(unsigned int)(ARP_TTL*1000))
            arp_cache[i].nud_state=0;
        if(arp_cache[i].nud_state==NUD_FAILED&&
           (now-arp_cache[i].updated_ms)>10000)
            arp_cache[i].nud_state=0;
    }
}

static void arp_cache_update(unsigned char *ip,unsigned char *mac){
    if(!ip||!mac)return;
    unsigned int now=get_tick_ms();
    for(int i=0;i<ARP_CACHE;i++){
        if(arp_cache[i].nud_state==0)continue;
        if(memcmp(arp_cache[i].ip,ip,4)!=0)continue;
        if(arp_cache[i].nud_state==NUD_REACHABLE&&
           (now-arp_cache[i].updated_ms)<ARP_LOCKTIME_MS&&
           memcmp(arp_cache[i].mac,mac,6)!=0)
            return;
        memcpy(arp_cache[i].mac,mac,6);
        arp_cache[i].nud_state=NUD_REACHABLE;
        arp_cache[i].updated_ms=now;
        arp_cache[i].probes_sent=0;
        return;
    }
    int slot=-1;
    unsigned int oldest=0xFFFFFFFF;
    for(int i=0;i<ARP_CACHE;i++)if(arp_cache[i].nud_state==0){slot=i;break;}
    if(slot<0){
        for(int i=0;i<ARP_CACHE;i++)
            if((arp_cache[i].nud_state==NUD_FAILED||arp_cache[i].nud_state==NUD_STALE)&&
               arp_cache[i].updated_ms<oldest){oldest=arp_cache[i].updated_ms;slot=i;}
    }
    if(slot<0){
        for(int i=0;i<ARP_CACHE;i++)
            if(arp_cache[i].updated_ms<oldest){oldest=arp_cache[i].updated_ms;slot=i;}
    }
    if(slot<0)return;
    memcpy(arp_cache[slot].ip,ip,4);
    memcpy(arp_cache[slot].mac,mac,6);
    arp_cache[slot].nud_state=NUD_REACHABLE;
    arp_cache[slot].updated_ms=now;
    arp_cache[slot].used_ms=now;
    arp_cache[slot].probes_sent=0;
    arp_cache[slot].last_probe_ms=0;
}

static int arp_cache_lookup(unsigned char *ip,unsigned char *mac_out){
    if(!ip||!mac_out)return 0;
    unsigned int now=get_tick_ms();
    for(int i=0;i<ARP_CACHE;i++){
        if(arp_cache[i].nud_state==0)continue;
        if(memcmp(arp_cache[i].ip,ip,4)!=0)continue;
        if(arp_cache[i].nud_state==NUD_REACHABLE&&
           (now-arp_cache[i].updated_ms)>NUD_REACHABLE_MS)
            arp_cache[i].nud_state=NUD_STALE;
        if(arp_cache[i].nud_state==NUD_REACHABLE||
           arp_cache[i].nud_state==NUD_STALE){
            memcpy(mac_out,arp_cache[i].mac,6);
            arp_cache[i].used_ms=now;
            net_stats.arp_cache_hits++;
            return 1;
        }
        net_stats.arp_cache_misses++;
        return 0;
    }
    net_stats.arp_cache_misses++;
    return 0;
}

/* ── Ethernet send ────────────────────────────────────────────── */
static int eth_send(unsigned char *dst,unsigned short et,unsigned char *pay,int pl){
    if(!dst||!pay||pl<=0||pl>1480)return 0;
    EthHdr *eh=(EthHdr*)tx_buf;
    for(int i=0;i<6;i++){eh->dst[i]=dst[i];eh->src[i]=nic_mac[i];}
    eh->ethertype=htons_f(et);
    memcpy(tx_buf+sizeof(EthHdr),pay,pl);
    int tot=sizeof(EthHdr)+pl;
    if(tot<60){memset(tx_buf+tot,0,60-tot);tot=60;}
    return nic_send_raw(tx_buf,tot);
}

/* ── ARP send ─────────────────────────────────────────────────── */
static void arp_send_request(unsigned char *tip){
    if(!tip)return;
    unsigned char b[28];
    b[0]=0;b[1]=1;b[2]=8;b[3]=0;b[4]=6;b[5]=4;b[6]=0;b[7]=1;
    for(int i=0;i<6;i++)b[8+i]=nic_mac[i];
    for(int i=0;i<4;i++)b[14+i]=net_ip[i];
    memset(b+18,0,6);
    for(int i=0;i<4;i++)b[24+i]=tip[i];
    eth_send(bcast_mac,0x0806,b,28);
    net_stats.arp_requests_sent++;
}
static void arp_send_reply(unsigned char *dst_mac,unsigned char *dst_ip){
    if(!dst_mac||!dst_ip)return;
    unsigned char b[28];
    b[0]=0;b[1]=1;b[2]=8;b[3]=0;b[4]=6;b[5]=4;b[6]=0;b[7]=2;
    for(int i=0;i<6;i++)b[8+i]=nic_mac[i];
    for(int i=0;i<4;i++)b[14+i]=net_ip[i];
    for(int i=0;i<6;i++)b[18+i]=dst_mac[i];
    for(int i=0;i<4;i++)b[24+i]=dst_ip[i];
    eth_send(dst_mac,0x0806,b,28);
    net_stats.arp_replies_sent++;
}

static void arp_process(unsigned char *frame,int len){
    if(!frame)return;
    if(len<(int)sizeof(EthHdr)+28)return;
    unsigned char *a=frame+sizeof(EthHdr);
    unsigned short htype=(unsigned short)(a[0]<<8)|a[1];
    unsigned short ptype=(unsigned short)(a[2]<<8)|a[3];
    if(htype!=1||ptype!=0x0800||a[4]!=6||a[5]!=4)return;
    unsigned short oper=(unsigned short)(a[6]<<8)|a[7];
    unsigned char *sender_mac=a+8;
    unsigned char *sender_ip =a+14;
    unsigned char *target_ip =a+24;
    int is_garp=(memcmp(sender_ip,target_ip,4)==0);
    if(memcmp(sender_ip,net_ip,4)!=0)
        arp_cache_update(sender_ip,sender_mac);
    if(oper==2)net_stats.arp_replies_recv++;
    if(is_garp)return;
    if(oper==1&&memcmp(target_ip,net_ip,4)==0)
        arp_send_reply(sender_mac,sender_ip);
}

static int arp_resolve(unsigned char *ip,unsigned char *mac_out){
    if(!ip||!mac_out)return 0;
    if(arp_cache_lookup(ip,mac_out))return 1;
    for(int try=0;try<ARP_MAX_TRIES;try++){
        arp_send_request(ip);
        unsigned int t0=get_tick_ms();
        while((get_tick_ms()-t0)<NUD_RETRANS_MS){
            net_pump();
            int qlen;
            unsigned char *pkt=pkt_queue_peek(&qlen);
            if(pkt&&qlen>=(int)sizeof(EthHdr)){
                EthHdr *eh=(EthHdr*)pkt;
                if(htons_f(eh->ethertype)==0x0806)arp_process(pkt,qlen);
                pkt_queue_pop();
            }
            if(arp_cache_lookup(ip,mac_out))return 1;
        }
    }
    for(int i=0;i<ARP_CACHE;i++){
        if(arp_cache[i].nud_state!=0&&memcmp(arp_cache[i].ip,ip,4)==0){
            arp_cache[i].nud_state=NUD_FAILED;break;
        }
    }
    net_stats.timeouts++;
    return 0;
}

/* ── IP send ──────────────────────────────────────────────────── */
static int ip_send(unsigned char *dst_ip,unsigned char proto,unsigned char *pay,int plen){
    if(!dst_ip||!pay||plen<=0)return 0;
    unsigned char dst_mac[6];
    int same=1;
    for(int i=0;i<4;i++)if((dst_ip[i]&net_mask[i])!=(net_ip[i]&net_mask[i])){same=0;break;}
    unsigned char *nh=same?dst_ip:net_gw;
    if(!arp_resolve(nh,dst_mac))return 0;
    static unsigned char ipb[1500];
    if(plen>(int)(1500-sizeof(IPhdr)))plen=1500-sizeof(IPhdr);
    IPhdr *iph=(IPhdr*)ipb;
    iph->ver_ihl=0x45;iph->dscp=0;
    iph->total_len=htons_f((unsigned short)(sizeof(IPhdr)+plen));
    iph->id=htons_f(ip_id_ctr++);
    iph->flags_frag=htons_f(0x4000);
    iph->ttl=64;iph->proto=proto;iph->checksum=0;
    memcpy(iph->src_ip,net_ip,4);memcpy(iph->dst_ip,dst_ip,4);
    iph->checksum=ip_cksum(iph,sizeof(IPhdr));
    memcpy(ipb+sizeof(IPhdr),pay,plen);
    return eth_send(dst_mac,0x0800,ipb,sizeof(IPhdr)+plen);
}

/* ── Protocol dispatcher ──────────────────────────────────────── */
static void icmp_process(unsigned char *frame,int len);
static void tcp_process(unsigned char *frame,int len);
static void udp_process(unsigned char *frame,int len);
static void dhcp_process_pkt(unsigned char *frame,int len);
static int dhcp_waiting=0;

static int net_dispatch_one(void){
    net_pump();
    int qlen;
    unsigned char *pkt=pkt_queue_peek(&qlen);
    if(!pkt){return 0;}
    if(qlen<(int)sizeof(EthHdr)){pkt_queue_pop();return 0;}
    EthHdr *eh=(EthHdr*)pkt;
    unsigned short et=htons_f(eh->ethertype);
    if(et==0x0806){
        arp_process(pkt,qlen);
    } else if(et==0x0800){
        if(qlen>=(int)(sizeof(EthHdr)+sizeof(IPhdr))){
            IPhdr *iph=(IPhdr*)(pkt+sizeof(EthHdr));
            int ip_frame_len=qlen-(int)sizeof(EthHdr);
            if(ipv4_validate(iph,ip_frame_len)){
                unsigned char proto=iph->proto;
                if(proto==1)      icmp_process(pkt,qlen);
                else if(proto==6) tcp_process(pkt,qlen);
                else if(proto==17){if(dhcp_waiting)dhcp_process_pkt(pkt,qlen);else udp_process(pkt,qlen);}
            } else net_stats.ip_malformed++;
        }
    }
    pkt_queue_pop();
    return 1;
}
static void net_process(int max_iters){for(int i=0;i<max_iters;i++)if(!net_dispatch_one())break;}

/* ── DHCP ─────────────────────────────────────────────────────── */
static unsigned int dhcp_xid=0xDEADBEEF;
static unsigned char dhcp_offered_ip[4]={0};
static unsigned char dhcp_offered_gw[4]={0};
static unsigned char dhcp_offered_mask[4]={255,255,255,0};
static unsigned char dhcp_offered_dns[4]={8,8,8,8};
static unsigned char dhcp_server_ip[4]={0};
static unsigned int  dhcp_lease_time=0;
static unsigned int  dhcp_renew_time=0;
static int dhcp_got_offer=0,dhcp_got_ack=0;

static void dhcp_send_discover(void){
    static unsigned char dbuf[sizeof(UDPhdr)+sizeof(DHCPpkt)];
    memset(dbuf,0,sizeof(dbuf));
    UDPhdr *uh=(UDPhdr*)dbuf;
    DHCPpkt *d=(DHCPpkt*)(dbuf+sizeof(UDPhdr));
    d->op=1;d->htype=1;d->hlen=6;d->xid=htonl_f(dhcp_xid);d->flags=htons_f(0x8000);
    for(int i=0;i<6;i++)d->chaddr[i]=nic_mac[i];
    d->options[0]=99;d->options[1]=130;d->options[2]=83;d->options[3]=99;
    d->options[4]=53;d->options[5]=1;d->options[6]=1;
    d->options[7]=55;d->options[8]=4;d->options[9]=1;d->options[10]=3;d->options[11]=6;d->options[12]=51;
    d->options[13]=255;
    int plen=(int)(sizeof(UDPhdr)+sizeof(DHCPpkt));
    uh->src_port=htons_f(68);uh->dst_port=htons_f(67);uh->length=htons_f((unsigned short)plen);uh->checksum=0;
    static unsigned char ipb[sizeof(IPhdr)+sizeof(UDPhdr)+sizeof(DHCPpkt)];
    unsigned char zero[4]={0},bip[4]={255,255,255,255};
    IPhdr *iph=(IPhdr*)ipb;
    iph->ver_ihl=0x45;iph->dscp=0;iph->total_len=htons_f((unsigned short)(sizeof(IPhdr)+plen));
    iph->id=htons_f(ip_id_ctr++);iph->flags_frag=0;iph->ttl=64;iph->proto=17;
    iph->checksum=0;memcpy(iph->src_ip,zero,4);memcpy(iph->dst_ip,bip,4);
    iph->checksum=ip_cksum(iph,sizeof(IPhdr));
    memcpy(ipb+sizeof(IPhdr),dbuf,plen);
    eth_send(bcast_mac,0x0800,ipb,sizeof(IPhdr)+plen);
    net_stats.dhcp_discover++;
}
static void dhcp_send_request(void){
    static unsigned char dbuf[sizeof(UDPhdr)+sizeof(DHCPpkt)];
    memset(dbuf,0,sizeof(dbuf));
    UDPhdr *uh=(UDPhdr*)dbuf;
    DHCPpkt *d=(DHCPpkt*)(dbuf+sizeof(UDPhdr));
    d->op=1;d->htype=1;d->hlen=6;d->xid=htonl_f(dhcp_xid);d->flags=htons_f(0x8000);
    for(int i=0;i<6;i++)d->chaddr[i]=nic_mac[i];
    d->options[0]=99;d->options[1]=130;d->options[2]=83;d->options[3]=99;
    d->options[4]=53;d->options[5]=1;d->options[6]=3;
    d->options[7]=50;d->options[8]=4;for(int i=0;i<4;i++)d->options[9+i]=dhcp_offered_ip[i];
    d->options[13]=54;d->options[14]=4;for(int i=0;i<4;i++)d->options[15+i]=dhcp_server_ip[i];
    d->options[19]=255;
    int plen=(int)(sizeof(UDPhdr)+sizeof(DHCPpkt));
    uh->src_port=htons_f(68);uh->dst_port=htons_f(67);uh->length=htons_f((unsigned short)plen);uh->checksum=0;
    static unsigned char ipb[sizeof(IPhdr)+sizeof(UDPhdr)+sizeof(DHCPpkt)];
    unsigned char zero[4]={0},bip[4]={255,255,255,255};
    IPhdr *iph=(IPhdr*)ipb;
    iph->ver_ihl=0x45;iph->dscp=0;iph->total_len=htons_f((unsigned short)(sizeof(IPhdr)+plen));
    iph->id=htons_f(ip_id_ctr++);iph->flags_frag=0;iph->ttl=64;iph->proto=17;
    iph->checksum=0;memcpy(iph->src_ip,zero,4);memcpy(iph->dst_ip,bip,4);
    iph->checksum=ip_cksum(iph,sizeof(IPhdr));
    memcpy(ipb+sizeof(IPhdr),dbuf,plen);
    eth_send(bcast_mac,0x0800,ipb,sizeof(IPhdr)+plen);
    net_stats.dhcp_request++;
}
static void dhcp_process_pkt(unsigned char *frame,int len){
    int min=(int)(sizeof(EthHdr)+sizeof(IPhdr)+sizeof(UDPhdr)+sizeof(DHCPpkt));
    if(!frame||len<min)return;
    EthHdr *eh=(EthHdr*)frame;
    if(htons_f(eh->ethertype)!=0x0800)return;
    IPhdr *ri=(IPhdr*)(frame+sizeof(EthHdr));
    if(ri->proto!=17)return;
    int ihl=(ri->ver_ihl&0x0F)*4;
    UDPhdr *ru=(UDPhdr*)((unsigned char*)ri+ihl);
    if(htons_f(ru->dst_port)!=68)return;
    DHCPpkt *rd=(DHCPpkt*)((unsigned char*)ru+sizeof(UDPhdr));
    if(htonl_f(rd->xid)!=dhcp_xid)return;
    if(memcmp(rd->chaddr,nic_mac,6)!=0)return;
    unsigned char *opt=rd->options+4,*end=rd->options+312;
    int type=0;
    unsigned char tmp_gw[4]={0},tmp_dns[4]={8,8,8,8},tmp_mask[4]={255,255,255,0},srv_ip[4]={0};
    unsigned int lease=0,renew=0;
    while(opt<end&&*opt!=255){
        unsigned char tag=*opt++;if(tag==0)continue;
        if(opt>=end)break;unsigned char ol=*opt++;if(opt+ol>end)break;
        if(tag==53&&ol>=1)type=opt[0];
        if(tag==1&&ol==4)memcpy(tmp_mask,opt,4);
        if(tag==3&&ol>=4)memcpy(tmp_gw,opt,4);
        if(tag==6&&ol>=4)memcpy(tmp_dns,opt,4);
        if(tag==54&&ol>=4)memcpy(srv_ip,opt,4);
        if(tag==51&&ol==4)lease=((unsigned int)opt[0]<<24)|((unsigned int)opt[1]<<16)|((unsigned int)opt[2]<<8)|opt[3];
        if(tag==58&&ol==4)renew=((unsigned int)opt[0]<<24)|((unsigned int)opt[1]<<16)|((unsigned int)opt[2]<<8)|opt[3];
        opt+=ol;
    }
    if(type==2&&!dhcp_got_offer){
        memcpy(dhcp_offered_ip,rd->yiaddr,4);memcpy(dhcp_offered_gw,tmp_gw,4);
        memcpy(dhcp_offered_mask,tmp_mask,4);memcpy(dhcp_offered_dns,tmp_dns,4);
        memcpy(dhcp_server_ip,srv_ip,4);dhcp_got_offer=1;net_stats.dhcp_offer++;
    }
    if(type==5&&dhcp_got_offer){
        if(memcmp(srv_ip,dhcp_server_ip,4)!=0&&memcmp(srv_ip,(unsigned char[]){0,0,0,0},4)!=0)return;
        memcpy(net_ip,dhcp_offered_ip,4);memcpy(net_mask,dhcp_offered_mask,4);
        memcpy(net_gw,dhcp_offered_gw,4);memcpy(net_dns,dhcp_offered_dns,4);
        dhcp_lease_time=lease;dhcp_renew_time=renew;dhcp_got_ack=1;net_stats.dhcp_ack++;
    }
}
static int dhcp_do(void){
    if(nic_type==NIC_NONE){prt("No NIC\n");return 0;}
    dhcp_got_offer=0;dhcp_got_ack=0;dhcp_xid++;dhcp_waiting=1;
    prt("DHCP: DISCOVER...\n");dhcp_send_discover();
    for(int t=0;t<200000&&!dhcp_got_offer;t++)net_dispatch_one();
    if(!dhcp_got_offer){prt("DHCP: No offer\n");dhcp_waiting=0;net_up=0;return 0;}
    prt("DHCP: OFFER received, sending REQUEST...\n");dhcp_send_request();
    for(int t=0;t<200000&&!dhcp_got_ack;t++)net_dispatch_one();
    dhcp_waiting=0;
    if(!dhcp_got_ack){prt("DHCP: No ACK\n");net_up=0;return 0;}
    net_up=1;
    prt("DHCP: IP=");prt_ip(net_ip);pchar_a('\n');
    if(dhcp_lease_time){prt("DHCP: Lease=");prt_uint(dhcp_lease_time);prt("s\n");}
    save_disk();return 1;
}
static int dhcp_do_with_retry(int max_attempts){
    for(int attempt=1;attempt<=max_attempts;attempt++){
        if(attempt>1){prt("DHCP: retry ");prt_int(attempt);prt("/");prt_int(max_attempts);prt("\n");delay_ms(500);}
        if(dhcp_do())return 1;
    }
    prt("DHCP: failed after ");prt_int(max_attempts);prt(" attempts. Use 'ipset' for static IP.\n");
    return 0;
}

/* ── ICMP ─────────────────────────────────────────────────────── */
static int     icmp_ping_got=0,icmp_ping_seq=0,icmp_ping_len=0;
static unsigned char icmp_ping_src[4]={0};
static unsigned char icmp_ping_ttl=0;
static unsigned short icmp_ping_id=0;

static void icmp_process(unsigned char *frame,int len){
    if(!frame)return;
    int eth_off=sizeof(EthHdr);
    if(len<eth_off+(int)sizeof(IPhdr))return;
    IPhdr *iph=(IPhdr*)(frame+eth_off);
    int ihl=(iph->ver_ihl&0x0F)*4;
    if(len<eth_off+ihl+(int)sizeof(ICMPhdr))return;
    ICMPhdr *ic=(ICMPhdr*)(frame+eth_off+ihl);
    int pay_len=len-eth_off-ihl;
    if(pay_len<(int)sizeof(ICMPhdr))return;
    unsigned short saved_ck=ic->checksum;
    ic->checksum=0;unsigned short calc_ck=ip_cksum(ic,pay_len);ic->checksum=saved_ck;
    if(calc_ck!=saved_ck){net_stats.ip_cksum_errors++;return;}
    if(ic->type==0){
        if(htons_f(ic->id)!=icmp_ping_id)return;
        icmp_ping_got=1;icmp_ping_seq=(int)htons_f(ic->seq);
        icmp_ping_len=(int)htons_f(iph->total_len);icmp_ping_ttl=iph->ttl;
        memcpy(icmp_ping_src,iph->src_ip,4);net_stats.icmp_echo_recv++;
    }
    if(ic->type==8){
        if(pay_len>1480)return;
        static unsigned char repl[1480];
        memcpy(repl,ic,pay_len);ICMPhdr *ri=(ICMPhdr*)repl;
        ri->type=0;ri->checksum=0;ri->checksum=ip_cksum(repl,pay_len);
        ip_send(iph->src_ip,1,repl,pay_len);
    }
}
static void do_ping(unsigned char *dst,int count){
    if(!net_up){prt("No IP\n");return;}
    if(!dst)return;
    prt("PING ");prt_ip(dst);prt(" 56 bytes\n");
    static unsigned char pk[64];
    unsigned int ok=0;icmp_ping_id=0x5645;
    for(int seq=1;seq<=count;seq++){
        memset(pk,0,64);ICMPhdr *ic=(ICMPhdr*)pk;
        ic->type=8;ic->code=0;ic->id=htons_f(icmp_ping_id);ic->seq=htons_f((unsigned short)seq);
        for(int i=8;i<64;i++)pk[i]=(unsigned char)i;
        ic->checksum=ip_cksum(pk,64);
        unsigned int t0=get_tick_ms();ip_send(dst,1,pk,64);net_stats.icmp_echo_sent++;
        icmp_ping_got=0;
        for(int t=0;t<3000000&&!icmp_ping_got;t++)net_dispatch_one();
        if(icmp_ping_got&&icmp_ping_seq==seq){
            unsigned int rtt=get_tick_ms()-t0;ok++;
            prt_int(icmp_ping_len);prt(" bytes from ");prt_ip(icmp_ping_src);
            prt(": icmp_seq=");prt_int(seq);prt(" ttl=");prt_uint(icmp_ping_ttl);
            prt(" time=");prt_uint(rtt);prt(" ms\n");
        } else {prt("Request timeout\n");net_stats.icmp_timeout++;}
        delay_ms(1000);
    }
    prt_uint((unsigned int)count);prt(" tx, ");prt_uint(ok);prt(" rx\n");
}
static int do_ping_quiet(unsigned char *dst,int count){
    if(!net_up||!dst)return 0;
    static unsigned char pk[64];
    unsigned int ok=0;
    unsigned short saved_id=icmp_ping_id;icmp_ping_id=0x5645;
    for(int seq=1;seq<=count;seq++){
        memset(pk,0,64);ICMPhdr *ic=(ICMPhdr*)pk;
        ic->type=8;ic->code=0;ic->id=htons_f(icmp_ping_id);ic->seq=htons_f((unsigned short)seq);
        for(int i=8;i<64;i++)pk[i]=(unsigned char)i;
        ic->checksum=ip_cksum(pk,64);
        ip_send(dst,1,pk,64);net_stats.icmp_echo_sent++;
        icmp_ping_got=0;
        for(int t=0;t<3000000&&!icmp_ping_got;t++)net_dispatch_one();
        if(icmp_ping_got&&icmp_ping_seq==seq)ok++;else net_stats.icmp_timeout++;
    }
    icmp_ping_id=saved_id;return ok>0?1:0;
}

static int parse_ip(const char *s,unsigned char *ip){
    if(!s||!ip)return 0;
    int p=0,v=0;
    for(;*s;s++){
        if(*s>='0'&&*s<='9')v=v*10+(*s-'0');
        else if(*s=='.'||*s==' '){if(p<4){ip[p]=(unsigned char)v;p++;v=0;}}
        else break;
    }
    if(p<4)ip[p]=(unsigned char)v;return p==3;
}

/* ── DNS ──────────────────────────────────────────────────────── */
static int           dns_got=0;
static unsigned char dns_resolved_ip[4]={0};
static unsigned short dns_txid=0x1234;

static int dns_skip_name(unsigned char *rp,int roff,int rlen){
    int iters=0;
    while(roff<rlen&&iters<64){
        iters++;
        if((rp[roff]&0xC0)==0xC0)return roff+2;
        if(rp[roff]==0)return roff+1;
        int ll=rp[roff];if(roff+1+ll>=rlen)return -1;
        roff+=1+ll;
    }
    return -1;
}
static void udp_process(unsigned char *frame,int len){
    if(!frame||len<(int)(sizeof(EthHdr)+sizeof(IPhdr)+sizeof(UDPhdr)))return;
    IPhdr *iph=(IPhdr*)(frame+sizeof(EthHdr));
    int ihl=(iph->ver_ihl&0x0F)*4;
    UDPhdr *uh=(UDPhdr*)((unsigned char*)iph+ihl);
    if(htons_f(uh->src_port)!=53)return;
    unsigned char *rp=(unsigned char*)uh+sizeof(UDPhdr);
    int rlen=len-((int)sizeof(EthHdr)+ihl+(int)sizeof(UDPhdr));
    if(rlen<12)return;
    unsigned short rxid=(unsigned short)(rp[0]<<8)|rp[1];
    if(rxid!=dns_txid)return;
    if(!(rp[2]&0x80))return;
    int ancount=(rp[6]<<8)|rp[7];if(ancount<=0)return;
    int roff=12,qdcount=(rp[4]<<8)|rp[5];
    for(int q=0;q<qdcount&&roff<rlen;q++){roff=dns_skip_name(rp,roff,rlen);if(roff<0)return;roff+=4;}
    for(int a=0;a<ancount;a++){
        if(roff>=rlen)break;
        roff=dns_skip_name(rp,roff,rlen);if(roff<0)return;
        if(roff+10>rlen)break;
        int type=(rp[roff]<<8)|rp[roff+1];
        unsigned int rdlen=((unsigned int)rp[roff+8]<<8)|(unsigned int)rp[roff+9];
        roff+=10;
        if(type==1&&rdlen==4&&roff+4<=(unsigned int)rlen){
            memcpy(dns_resolved_ip,rp+roff,4);dns_got=1;net_stats.dns_replies++;return;
        }
        roff+=(int)rdlen;
    }
}
static int dns_lookup_ip(const char *domain,unsigned char *out_ip){
    if(!domain||!out_ip||!net_up)return 0;
    static unsigned char pkt[512];memset(pkt,0,512);
    dns_txid++;pkt[0]=(unsigned char)(dns_txid>>8);pkt[1]=(unsigned char)dns_txid;
    pkt[2]=0x01;pkt[3]=0x00;pkt[4]=0;pkt[5]=1;
    int off=12;const char *p=domain;
    while(*p){
        const char *dot=p;while(*dot&&*dot!='.')dot++;
        int llen=(int)(dot-p);
        if(llen<=0||llen>63||off+llen+2>510)return 0;
        pkt[off]=(unsigned char)llen;off++;
        for(int i=0;i<llen;i++){pkt[off]=p[i];off++;}
        p=dot;if(*p=='.')p++;
    }
    pkt[off]=0;off++;pkt[off]=0;off++;pkt[off]=1;off++;pkt[off]=0;off++;pkt[off]=1;off++;
    static unsigned char udpbuf[sizeof(UDPhdr)+512];
    UDPhdr *uh=(UDPhdr*)udpbuf;
    uh->src_port=htons_f((unsigned short)(1234+dns_txid));uh->dst_port=htons_f(53);
    uh->length=htons_f((unsigned short)(sizeof(UDPhdr)+off));uh->checksum=0;
    memcpy(udpbuf+sizeof(UDPhdr),pkt,off);
    ip_send(net_dns,17,udpbuf,sizeof(UDPhdr)+off);net_stats.dns_queries++;
    dns_got=0;
    for(int t=0;t<200000&&!dns_got;t++)net_dispatch_one();
    if(dns_got){memcpy(out_ip,dns_resolved_ip,4);return 1;}
    net_stats.dns_timeouts++;return 0;
}
static void dns_cmd(const char *domain){
    if(!net_up){prt("No network\n");return;}
    if(!domain||!*domain){prt("dns <domain>\n");return;}
    prt("Resolving ");prt(domain);prt("...\n");
    unsigned char ip[4]={0};
    if(dns_lookup_ip(domain,ip)){prt(domain);prt(" -> ");prt_ip(ip);pchar_a('\n');}
    else prt("DNS: Timeout or no A record\n");
}

/* ── Connectivity verification ────────────────────────────────── */
static void net_verify_connectivity(void){
    if(!net_up)return;
    prt("Verifying connectivity...\n");
    unsigned char gw_mac[6];
    if(arp_resolve(net_gw,gw_mac)){
        prt("  ARP gateway:  OK (");
        for(int i=0;i<6;i++){prt_hex8(gw_mac[i]);if(i<5)pchar_a(':');}
        prt(")\n");
    } else {prt("  ARP gateway:  FAIL (");prt_ip(net_gw);prt(")\n");return;}
    if(do_ping_quiet(net_gw,1))prt("  Ping gateway: OK\n");
    else prt("  Ping gateway: FAIL\n");
    unsigned char dns_test[4]={0};
    if(dns_lookup_ip("example.com",dns_test)){prt("  DNS lookup:   OK (");prt_ip(dns_test);prt(")\n");}
    else prt("  DNS lookup:   FAIL\n");
}

/* ── TCP ──────────────────────────────────────────────────────── */
#define TCP_CLOSED      0
#define TCP_SYN_SENT    1
#define TCP_ESTABLISHED 2
#define TCP_FIN_WAIT    3
#define TCP_CLOSE_WAIT  4
#define TCP_LAST_ACK    5
#define TCP_TIME_WAIT   6

typedef struct{
    int state;unsigned char remote_ip[4];unsigned short local_port,remote_port;
    unsigned int seq,ack;
    unsigned char rx_buf[TCP_BUF_SIZE];int rx_head,rx_tail;
}TCPConn;

static TCPConn tcp_conns[TCP_MAX_CONN];
static unsigned short tcp_next_port=49152;
static unsigned short tcp_alloc_port(void){unsigned short p=tcp_next_port++;if(tcp_next_port>65530)tcp_next_port=49152;return p;}
static int tcp_alloc_conn(void){for(int i=0;i<TCP_MAX_CONN;i++)if(tcp_conns[i].state==TCP_CLOSED)return i;return -1;}

static unsigned short tcp_cksum(unsigned char *seg,int len,unsigned char *sip,unsigned char *dip){
    if(!seg||!sip||!dip||len<=0)return 0xFFFF;
    unsigned char ph[12];
    ph[0]=sip[0];ph[1]=sip[1];ph[2]=sip[2];ph[3]=sip[3];
    ph[4]=dip[0];ph[5]=dip[1];ph[6]=dip[2];ph[7]=dip[3];
    ph[8]=0;ph[9]=6;ph[10]=(unsigned char)(len>>8);ph[11]=(unsigned char)(len&0xFF);
    unsigned int sum=0;unsigned short *p=(unsigned short*)ph;
    for(int i=0;i<6;i++)sum+=p[i];
    p=(unsigned short*)seg;int l=len;
    while(l>1){sum+=*p++;l-=2;}
    if(l)sum+=(unsigned char)*(unsigned char*)p;
    while(sum>>16)sum=(sum&0xFFFF)+(sum>>16);
    return~(unsigned short)sum;
}
static unsigned int lcg_seed=12345;
static unsigned int lcg_rand(void){lcg_seed=lcg_seed*1103515245+12345;return(lcg_seed>>16)&0x7FFF;}

static void tcp_send_flags(int ci,unsigned char flags,unsigned char *data,int dlen){
    if(ci<0||ci>=TCP_MAX_CONN)return;
    TCPConn *c=&tcp_conns[ci];
    static unsigned char pkt[1500];
    int hlen=sizeof(TCPHdr);
    if(dlen>1460)dlen=1460;
    if(dlen>0&&data)memcpy(pkt+hlen,data,dlen);else dlen=0;
    TCPHdr *t=(TCPHdr*)pkt;memset(t,0,sizeof(TCPHdr));
    t->src_port=htons_f(c->local_port);t->dst_port=htons_f(c->remote_port);
    t->seq_num=htonl_f(c->seq);t->ack_num=htonl_f(c->ack);
    t->data_offset=(unsigned char)(hlen/4)<<4;t->flags=flags;
    t->window=htons_f(8192);t->checksum=0;
    t->checksum=tcp_cksum(pkt,hlen+dlen,net_ip,c->remote_ip);
    ip_send(c->remote_ip,6,pkt,hlen+dlen);
}
static void tcp_process(unsigned char *frame,int len){
    if(!frame||len<(int)(sizeof(EthHdr)+sizeof(IPhdr)+sizeof(TCPHdr)))return;
    IPhdr *iph=(IPhdr*)(frame+sizeof(EthHdr));int ihl=(iph->ver_ihl&0x0F)*4;
    TCPHdr *rt=(TCPHdr*)((unsigned char*)iph+ihl);
    unsigned short dport=htons_f(rt->dst_port),sport=htons_f(rt->src_port);
    int ip_payload_len=(int)htons_f(iph->total_len)-ihl;
    if(ip_payload_len<(int)sizeof(TCPHdr)){net_stats.ip_cksum_errors++;return;}
    unsigned short saved_ck=rt->checksum;rt->checksum=0;
    unsigned short calc_ck=tcp_cksum((unsigned char*)rt,ip_payload_len,iph->src_ip,iph->dst_ip);
    rt->checksum=saved_ck;
    if(calc_ck!=saved_ck){net_stats.ip_cksum_errors++;return;}
    for(int i=0;i<TCP_MAX_CONN;i++){
        TCPConn *c=&tcp_conns[i];
        if(c->state==TCP_CLOSED)continue;
        if(c->local_port!=dport)continue;
        if(memcmp(c->remote_ip,iph->src_ip,4)!=0)continue;
        if(c->remote_port!=sport)continue;
        unsigned int remote_seq=ntohl_f(rt->seq_num),remote_ack=ntohl_f(rt->ack_num);
        unsigned char fl=rt->flags;
        if(fl&0x04){c->state=TCP_CLOSED;net_stats.tcp_rst++;return;}
        if(c->state==TCP_SYN_SENT&&(fl&0x12)==0x12){
            c->seq=remote_ack;c->ack=remote_seq+1;c->state=TCP_ESTABLISHED;
            tcp_send_flags(i,0x10,0,0);net_stats.tcp_connect++;return;
        }
        if(c->state==TCP_ESTABLISHED&&(fl&0x01)){
            c->ack=remote_seq+1;c->state=TCP_CLOSE_WAIT;tcp_send_flags(i,0x10,0,0);return;
        }
        if(c->state==TCP_FIN_WAIT&&(fl&0x01)){
            c->ack=remote_seq+1;tcp_send_flags(i,0x10,0,0);c->state=TCP_TIME_WAIT;return;
        }
        if(c->state==TCP_TIME_WAIT&&(fl&0x10)){c->state=TCP_CLOSED;return;}
        if(c->state==TCP_ESTABLISHED&&(fl&0x10)){
            int thlen=(rt->data_offset>>4)*4;
            int plen=len-(int)(sizeof(EthHdr)+ihl+thlen);
            if(plen>0){
                unsigned char *pay=(unsigned char*)rt+thlen;
                if(remote_seq==c->ack){
                    for(int j=0;j<plen;j++){int next=(c->rx_tail+1)%TCP_BUF_SIZE;if(next!=c->rx_head){c->rx_buf[c->rx_tail]=pay[j];c->rx_tail=next;}}
                    c->ack=remote_seq+(unsigned int)plen;net_stats.tcp_data_rx+=(unsigned int)plen;
                    tcp_send_flags(i,0x10,0,0);
                }
            }
        }
        return;
    }
}

/* ── Socket API ───────────────────────────────────────────────── */
typedef struct{int type,conn;unsigned char remote_ip[4];unsigned short remote_port,local_port;}Socket;
static Socket sockets[SOCK_MAX];
static void sockets_init(void){for(int i=0;i<SOCK_MAX;i++){sockets[i].type=SOCK_NONE;sockets[i].conn=-1;}}
static int sock_socket(int type){for(int i=0;i<SOCK_MAX;i++)if(sockets[i].type==SOCK_NONE){sockets[i].type=type;sockets[i].conn=-1;return i;}return -1;}
static int sock_connect(int fd,unsigned char *ip,unsigned short port){
    if(fd<0||fd>=SOCK_MAX||!ip)return -1;
    Socket *s=&sockets[fd];if(s->type!=SOCK_TCP)return -1;
    int ci=tcp_alloc_conn();if(ci<0)return -1;
    TCPConn *c=&tcp_conns[ci];memset(c,0,sizeof(TCPConn));
    c->state=TCP_SYN_SENT;memcpy(c->remote_ip,ip,4);c->remote_port=port;
    c->local_port=tcp_alloc_port();c->seq=lcg_rand()<<16|lcg_rand();c->ack=0;
    s->conn=ci;memcpy(s->remote_ip,ip,4);s->remote_port=port;s->local_port=c->local_port;
    tcp_send_flags(ci,0x02,0,0);c->seq++;
    for(int t=0;t<300000&&c->state==TCP_SYN_SENT;t++)net_dispatch_one();
    if(c->state!=TCP_ESTABLISHED){net_stats.tcp_timeout++;return -1;}
    return 0;
}
static int sock_send(int fd,unsigned char *data,int len){
    if(fd<0||fd>=SOCK_MAX||!data||len<=0)return -1;
    Socket *s=&sockets[fd];if(s->type!=SOCK_TCP||s->conn<0)return -1;
    TCPConn *c=&tcp_conns[s->conn];if(c->state!=TCP_ESTABLISHED)return -1;
    int sent=0;
    while(sent<len){int chunk=len-sent;if(chunk>1460)chunk=1460;tcp_send_flags(s->conn,0x18,data+sent,chunk);c->seq+=(unsigned int)chunk;sent+=chunk;net_stats.tcp_data_tx+=(unsigned int)chunk;}
    return sent;
}
static int sock_recv(int fd,unsigned char *buf,int max_len,int timeout_iters){
    if(fd<0||fd>=SOCK_MAX||!buf||max_len<=0)return 0;
    Socket *s=&sockets[fd];if(s->type!=SOCK_TCP||s->conn<0)return 0;
    TCPConn *c=&tcp_conns[s->conn];
    for(int t=0;t<timeout_iters&&c->rx_head==c->rx_tail;t++)net_dispatch_one();
    int n=0;while(n<max_len&&c->rx_head!=c->rx_tail){buf[n++]=c->rx_buf[c->rx_head];c->rx_head=(c->rx_head+1)%TCP_BUF_SIZE;}
    return n;
}
static void sock_close(int fd){
    if(fd<0||fd>=SOCK_MAX)return;
    Socket *s=&sockets[fd];
    if(s->type==SOCK_TCP&&s->conn>=0){
        TCPConn *c=&tcp_conns[s->conn];
        if(c->state==TCP_ESTABLISHED||c->state==TCP_CLOSE_WAIT){
            tcp_send_flags(s->conn,0x11,0,0);
            if(c->state==TCP_ESTABLISHED)c->state=TCP_FIN_WAIT;else c->state=TCP_LAST_ACK;
            c->seq++;
        }
        for(int t=0;t<50000&&c->state!=TCP_CLOSED&&c->state!=TCP_TIME_WAIT;t++)net_dispatch_one();
        c->state=TCP_CLOSED;
    }
    s->type=SOCK_NONE;s->conn=-1;
}
static int http_get(unsigned char *ip,unsigned short port,const char *host,const char *path,unsigned char *out_buf,int out_max){
    if(!ip||!host||!path||!out_buf||out_max<=0)return 0;
    int fd=sock_socket(SOCK_TCP);if(fd<0)return 0;
    if(sock_connect(fd,ip,port)!=0){sock_close(fd);return 0;}
    static char req[1024];req[0]=0;
    strcat(req,"GET ");strcat(req,path);strcat(req," HTTP/1.0\r\nHost: ");strcat(req,host);
    strcat(req,"\r\nUser-Agent: AethrixOS/1.0\r\nConnection: close\r\n\r\n");
    sock_send(fd,(unsigned char*)req,strlen(req));
    int total=sock_recv(fd,out_buf,out_max-1,500000);out_buf[total]=0;
    sock_close(fd);return total;
}

/* ── WiFi stub ────────────────────────────────────────────────── */
#define WIFI_NONE 0
#define WIFI_DETECTED 1
#define WIFI_ASSOC 2
static int wifi_state=WIFI_NONE,wifi_bus=0,wifi_dev=0;
static unsigned int wifi_bar=0;
static char wifi_ssid[33]={0},wifi_psk[64]={0};
static const unsigned short wifi_intel_ids[]={0x4222,0x4229,0x422B,0x422C,0x4232,0x4235,0x4236,0x423A,0x008A,0x0082,0x0085,0x0090,0x0091,0x08B1,0x08B2,0x08B3,0x095A,0x24F3,0x24FD,0x2526,0x2723,0x02F0,0x0000};
static void wifi_detect(void){
    wifi_state=WIFI_NONE;
    for(int bus=0;bus<256&&wifi_state==WIFI_NONE;bus++)for(int dev=0;dev<32;dev++){
        unsigned int word=pci_read(bus,dev,0,0);unsigned short vid=word&0xFFFF;if(vid==0xFFFF)continue;
        unsigned short did=(word>>16)&0xFFFF;
        if(vid==0x8086){for(int k=0;wifi_intel_ids[k];k++)if(did==wifi_intel_ids[k]){wifi_bus=bus;wifi_dev=dev;wifi_bar=pci_read(bus,dev,0,0x10);pci_write(bus,dev,0,4,pci_read(bus,dev,0,4)|7);wifi_state=WIFI_DETECTED;prt("WiFi: Intel detected\n");return;}}
        if(vid==0x168C){wifi_bus=bus;wifi_dev=dev;wifi_bar=pci_read(bus,dev,0,0x10);pci_write(bus,dev,0,4,pci_read(bus,dev,0,4)|7);wifi_state=WIFI_DETECTED;prt("WiFi: Atheros detected\n");return;}
        if(vid==0x14E4){unsigned short cc=(unsigned short)(pci_read(bus,dev,0,8)>>16);if(cc==0x0280){wifi_bus=bus;wifi_dev=dev;wifi_bar=pci_read(bus,dev,0,0x10);pci_write(bus,dev,0,4,pci_read(bus,dev,0,4)|7);wifi_state=WIFI_DETECTED;prt("WiFi: Broadcom detected\n");return;}}
    }
    if(wifi_state==WIFI_NONE)prt("WiFi: None\n");
}
static void wifi_cmd(char *args){
    if(!args)args="";while(*args==' ')args++;
    if(strcmp(args,"status")==0||!*args){prt("wlan0: ");if(wifi_state==WIFI_NONE)prt("No adapter\n");else if(wifi_state==WIFI_DETECTED)prt("Detected (not associated)\n");else{prt("Connected: ");prt(wifi_ssid);pchar_a('\n');}return;}
    if(strcmp(args,"scan")==0){if(wifi_state==WIFI_NONE){prt("No adapter\n");return;}prt("Scan: firmware required. Use: wifi connect <ssid> <psk>\n");return;}
    if(strncmp(args,"connect ",8)==0){if(wifi_state==WIFI_NONE){prt("No adapter\n");return;}char *p=args+8;int si=0;while(*p&&*p!=' '&&si<32){wifi_ssid[si]=*p;si++;p++;}wifi_ssid[si]=0;while(*p==' ')p++;int pi=0;while(*p&&pi<63){wifi_psk[pi]=*p;pi++;p++;}wifi_psk[pi]=0;prt("WiFi: Attempting '");prt(wifi_ssid);prt("'\n");return;}
    if(strcmp(args,"disconnect")==0){wifi_ssid[0]=0;wifi_psk[0]=0;if(wifi_state==WIFI_ASSOC)wifi_state=WIFI_DETECTED;prt("Disconnected\n");return;}
    prt("wifi status|scan|connect <ssid> <psk>|disconnect\n");
}

/* ── NIC detect ───────────────────────────────────────────────── */
static void detect_nic(void){
    nic_type=NIC_NONE;
    for(int bus=0;bus<256&&nic_type==NIC_NONE;bus++)for(int dev=0;dev<32;dev++){
        unsigned int word=pci_read(bus,dev,0,0);unsigned short vid=word&0xFFFF;if(vid==0xFFFF)continue;
        unsigned short did=(word>>16)&0xFFFF;
        unsigned int bar0=pci_read(bus,dev,0,0x10),cmd=pci_read(bus,dev,0,4);
        if(vid==0x1022&&(did==0x2000||did==0x2001)){pci_write(bus,dev,0,4,cmd|7);nic_io=(unsigned short)(bar0&0xFFFC);nic_type=NIC_PCNET;pcnet_setup(nic_io);prt("NIC: AMD PCnet\n");return;}
        if(vid==0x10EC&&did==0x8139){pci_write(bus,dev,0,4,cmd|7);nic_io=(unsigned short)(bar0&0xFFFC);nic_type=NIC_RTL;rtl_init(nic_io);prt("NIC: RTL8139\n");return;}
        if(vid==0x8086){static const unsigned short e1000_ids[]={0x100E,0x100F,0x1010,0x1013,0x1018,0x1019,0x1004,0x1539,0x10EA,0x10D3,0x10F5,0x150C,0x1533,0x1521,0x1502,0x10C9,0x10D6,0x0000};for(int k=0;e1000_ids[k];k++)if(did==e1000_ids[k]){pci_write(bus,dev,0,4,cmd|7);nic_type=NIC_E1000;e1000_init(bar0);prt("NIC: Intel E1000\n");return;}}
    }
    prt("NIC: None\n");wifi_detect();
}

/* ── Disk persistence ─────────────────────────────────────────── */
int disk_ok=0; /* declared extern in kernel.h */
unsigned short disk_base=0; /* declared extern in kernel.h */
unsigned char disk_drv_sel=0; /* declared extern in kernel.h */
static const unsigned char MAGIC[8]={'A','E','T','H','R','I','X','1'};
static unsigned char ata_id_buf[512];
static unsigned int disk_total=0;

static void enc_sec0(unsigned char *b){
    memset(b,0,512);for(int i=0;i<8;i++)b[i]=MAGIC[i];
    int cnt=uc<7?uc:7;b[8]=(unsigned char)cnt;b[9]=(unsigned char)(fc&0xFF);b[10]=(unsigned char)((fc>>8)&0xFF);b[11]=(unsigned char)cwd;
    for(int i=0;i<cnt;i++){int o=16+i*68;for(int j=0;j<32&&users[i].n[j];j++)b[o+j]=users[i].n[j];for(int j=0;j<32&&users[i].p[j];j++)b[o+32+j]=users[i].p[j];b[o+64]=users[i].r?1:0;}
    b[492]=net_ip[0];b[493]=net_ip[1];b[494]=net_ip[2];b[495]=net_ip[3];
    b[496]=net_mask[0];b[497]=net_mask[1];b[498]=net_mask[2];b[499]=net_mask[3];
    b[500]=net_gw[0];b[501]=net_gw[1];b[502]=net_gw[2];b[503]=net_gw[3];
}
static void enc_fsec(unsigned char *b,int si){
    memset(b,0,512);
    for(int s=0;s<FILES_PER_SECTOR;s++){
        int fi=si*FILES_PER_SECTOR+s;if(fi>=fc)break;
        int bs=s*FILE_SLOT;
        for(int j=0;j<63&&files[fi].n[j];j++)b[bs+j]=files[fi].n[j];b[bs+63]=0;
        b[bs+64]=files[fi].is_dir?1:0;
        int sz=files[fi].s>FILE_DATA?FILE_DATA:files[fi].s;
        b[bs+65]=sz&0xFF;b[bs+66]=(sz>>8)&0xFF;
        b[bs+67]=(unsigned char)(files[fi].parent&0xFF);b[bs+68]=(unsigned char)((files[fi].parent>>8)&0xFF);
        for(int j=0;j<sz&&j<(FILE_SLOT-70);j++)b[bs+70+j]=files[fi].c[j];
    }
}
static void dec_sec0(unsigned char *b){
    int cnt=b[8]>7?7:b[8];int fcc=b[9]|(b[10]<<8);if(fcc>MAX_FILES)fcc=MAX_FILES;
    cwd=b[11];uc=0;
    for(int i=0;i<cnt;i++){int o=16+i*68;for(int j=0;j<31;j++)users[uc].n[j]=b[o+j];users[uc].n[31]=0;for(int j=0;j<31;j++)users[uc].p[j]=b[o+32+j];users[uc].p[31]=0;users[uc].r=b[o+64]?1:0;if(users[uc].n[0])uc++;}
    fc=fcc;
    if(b[492]!=0){net_ip[0]=b[492];net_ip[1]=b[493];net_ip[2]=b[494];net_ip[3]=b[495];net_mask[0]=b[496];net_mask[1]=b[497];net_mask[2]=b[498];net_mask[3]=b[499];net_gw[0]=b[500];net_gw[1]=b[501];net_gw[2]=b[502];net_gw[3]=b[503];net_up=1;}
}
static void dec_fsec(unsigned char *b,int si){
    for(int s=0;s<FILES_PER_SECTOR;s++){
        int fi=si*FILES_PER_SECTOR+s;if(fi>=fc)return;
        int bs=s*FILE_SLOT;for(int j=0;j<63;j++)files[fi].n[j]=b[bs+j];files[fi].n[63]=0;
        files[fi].is_dir=b[bs+64]?1:0;
        int sz=b[bs+65]|(b[bs+66]<<8);if(sz>FILE_DATA)sz=FILE_DATA;
        files[fi].s=sz;files[fi].parent=b[bs+67]|(b[bs+68]<<8);
        for(int j=0;j<sz&&j<(FILE_SLOT-70);j++)files[fi].c[j]=b[bs+70+j];files[fi].c[sz]=0;
    }
}
void save_disk(void){
    unsigned char b[512];if(!disk_ok){prt("[WARN] No disk\n");return;}
    enc_sec0(b);if(!ata_write(disk_base,disk_drv_sel,0,b)){prt("[FAIL] disk write\n");return;}
    int fs=(fc+FILES_PER_SECTOR-1)/FILES_PER_SECTOR;if(fs<1)fs=1;
    for(int s=0;s<fs;s++){enc_fsec(b,s);if(!ata_write(disk_base,disk_drv_sel,1+s,b)){prt("[FAIL] disk write\n");return;}}
    prt("[OK] Saved\n");
}
void load_disk(void){
    static const unsigned short bases[]={0x1F0,0x1F0,0x170,0x170};
    static const unsigned char drvs[]={0,1,0,1};
    disk_ok=0;
    for(int i=0;i<4;i++)if(ata_identify(bases[i],drvs[i],ata_id_buf)){disk_base=bases[i];disk_drv_sel=drvs[i];disk_ok=1;disk_total=(unsigned int)ata_id_buf[120]|(unsigned int)ata_id_buf[121]<<8|(unsigned int)ata_id_buf[122]<<16|(unsigned int)ata_id_buf[123]<<24;break;}
    if(!disk_ok)return;
    unsigned char b[512];if(!ata_read(disk_base,disk_drv_sel,0,b))return;
    if(memcmp(b,MAGIC,8)!=0)return;
    dec_sec0(b);if(fc>MAX_FILES)fc=MAX_FILES;
    int fs=(fc+FILES_PER_SECTOR-1)/FILES_PER_SECTOR;
    for(int s=0;s<fs;s++){if(!ata_read(disk_base,disk_drv_sel,1+s,b))continue;dec_fsec(b,s);}
}

/* ── nano editor ──────────────────────────────────────────────── */
static void nano(char *fn){
    while(*fn==' ')fn++;if(!*fn){prt("nano <filename>\n");return;}
    int id=ffile_any(fn);
    if(id<0){if(fc>=MAX_FILES){prt("Max files\n");return;}id=fc;strcpy(files[id].n,fn);files[id].is_dir=0;files[id].c[0]=0;files[id].s=0;files[id].parent=cwd;fc++;}
    if(files[id].is_dir){prt("Is directory\n");return;}
    int sx=cx,sy=cy;cls();
    for(int x=0;x<WIDTH;x++)schar_attr(x,0,' ',0x70);cx=0;cy=0;prt(" nano: ");prt(fn);
    for(int x=0;x<WIDTH;x++)schar_attr(x,HEIGHT-2,' ',0x70);cx=0;cy=HEIGHT-2;prt(" ^S Save  ^X Exit");
    char eb[FILE_DATA];int es=files[id].s<FILE_DATA?files[id].s:FILE_DATA-1;int ep=es;
    for(int i=0;i<es;i++)eb[i]=files[id].c[i];eb[es]=0;cx=0;cy=2;prt(eb);int nx=0,ny=2;
    while(1){
        unsigned char st=inb(0x64);if(!(st&0x01))continue;if(st&0x20){inb(0x60);continue;}
        char c=kb_translate(inb(0x60));
        if(c==24)break;
        if(c==19){eb[ep]=0;es=ep;files[id].s=es;for(int i=0;i<=es;i++)files[id].c[i]=eb[i];save_disk();for(int x=0;x<WIDTH;x++)schar_attr(x,HEIGHT-2,' ',0x70);cx=0;cy=HEIGHT-2;prt(" Saved!");for(volatile int d=0;d<2000000;d++);for(int x=0;x<WIDTH;x++)schar_attr(x,HEIGHT-2,' ',0x70);cx=0;cy=HEIGHT-2;prt(" ^S Save  ^X Exit");cx=nx;cy=ny;scur();continue;}
        if(c=='\n'&&ep<FILE_DATA-2){for(int i=es;i>=ep;i--)eb[i+1]=eb[i];eb[ep]='\n';ep++;es++;}
        else if(c=='\b'&&ep>0){for(int i=ep-1;i<es;i++)eb[i]=eb[i+1];ep--;es--;}
        else if(c>=' '&&c<='~'&&ep<FILE_DATA-2){for(int i=es;i>=ep;i--)eb[i+1]=eb[i];eb[ep]=c;ep++;es++;}
        else continue;
        eb[es]=0;for(int y=2;y<HEIGHT-2;y++)for(int x=0;x<WIDTH;x++)schar_attr(x,y,' ',COLOR_SHADOW);cx=0;cy=2;prt(eb);
        int l=0,co=0;for(int i=0;i<ep;i++){if(eb[i]=='\n'){l++;co=0;}else co++;}
        nx=co;if(nx<0)nx=0;if(nx>=WIDTH)nx=WIDTH-1;ny=2+l;if(ny<0)ny=0;if(ny>=HEIGHT)ny=HEIGHT-1;cx=nx;cy=ny;scur();
    }
    cls();cx=sx;cy=sy;
}

/* ── Input helpers ────────────────────────────────────────────── */
void input(char *buf,int ml,int hidden){
    if(!buf||ml<=1)return;int p=0;buf[0]=0;
    while(1){unsigned char st=inb(0x64);if(!(st&0x01))continue;if(st&0x20){inb(0x60);continue;}char c=kb_translate(inb(0x60));if(c=='\n'){buf[p]=0;pchar_a('\n');return;}if(c=='\b'&&p>0){p--;pchar_a('\b');}else if(c&&c>=' '&&c<='~'&&p<ml-1){buf[p]=c;p++;pchar_a(hidden?'*':c);}}
}
void wait_enter(void){while(1){unsigned char st=inb(0x64);if(!(st&0x01))continue;if(st&0x20){inb(0x60);continue;}if(kb_translate(inb(0x60))=='\n')return;}}
static void prompt(void){char pw[256];build_pwd(pw);prt(cu);prt("@");prt(HOSTNAME);prt(":");prt_m(pw);prt(cr?"# ":"$ ");}

/* ── Shell state ──────────────────────────────────────────────── */
static char aliases[20][2][64];static int alias_count=0;
static char history[20][256];static int hist_count=0;
static void hist_add(const char *cmd){if(!cmd||!cmd[0])return;if(hist_count<20){strncpy(history[hist_count],cmd,255);history[hist_count][255]=0;hist_count++;}else{memmove(history[0],history[1],19*256);strncpy(history[19],cmd,255);history[19][255]=0;}}
static char vars[50][2][64];static int var_count=0;
static void var_set(const char *name,const char *val){if(!name||!val)return;for(int i=0;i<var_count;i++)if(strcmp(vars[i][0],name)==0){strncpy(vars[i][1],val,63);vars[i][1][63]=0;return;}if(var_count<50){strncpy(vars[var_count][0],name,63);vars[var_count][0][63]=0;strncpy(vars[var_count][1],val,63);vars[var_count][1][63]=0;var_count++;}}
static const char *var_get(const char *name){if(!name)return 0;for(int i=0;i<var_count;i++)if(strcmp(vars[i][0],name)==0)return vars[i][1];return 0;}
unsigned int mb_mem_upper=0; /* declared extern in kernel.h */

/* ── grep/show helpers ────────────────────────────────────────── */
typedef void(*line_cb)(const char*,int,void*);
static void each_line(const char *content,line_cb cb,void *ud){if(!content||!cb)return;static char line[256];int li=0,ln=1;for(int i=0;content[i];i++){if(content[i]=='\n'||li>=254){line[li]=0;cb(line,ln,ud);ln++;li=0;if(content[i]!='\n'){line[li]=content[i];li++;}}else{line[li]=content[i];li++;}}if(li>0){line[li]=0;cb(line,ln,ud);}}
typedef struct{const char *pat;int invert,icase,count,linenum,found;}GrepCtx;
static int str_match_i(const char *hay,const char *needle){if(!hay||!needle)return 0;int hl=strlen(hay),nl=strlen(needle);if(nl>hl||nl==0)return 0;for(int i=0;i<=hl-nl;i++){int ok=1;for(int j=0;j<nl;j++){if(tolower_c(hay[i+j])!=tolower_c(needle[j])){ok=0;break;}}if(ok)return 1;}return 0;}
static void grep_line_cb(const char *line,int ln,void *ud){if(!line||!ud)return;GrepCtx *g=(GrepCtx*)ud;int match=g->icase?str_match_i(line,g->pat):(g->pat?strstr(line,g->pat):0);if(g->invert)match=!match;if(match){g->found++;if(g->count==0){if(g->linenum){prt_int(ln);prt(": ");}prt(line);pchar_a('\n');}}}
typedef struct{int linenum,page_lines,done,single_step;}ShowCtx;
static void show_line_cb(const char *line,int ln,void *ud){if(!line||!ud)return;ShowCtx *s=(ShowCtx*)ud;if(s->done)return;if(s->linenum){prt_int(ln);prt("\t");}prt(line);pchar_a('\n');s->page_lines++;if(s->single_step){s->done=1;return;}if(s->page_lines>=23){for(int x=0;x<WIDTH;x++)schar_attr(x,HEIGHT-1,' ',0x70);cx=0;cy=HEIGHT-1;prt("--More-- (space=page, enter=line, q=quit)");char k=read_key();for(int x=0;x<WIDTH;x++)schar_attr(x,HEIGHT-1,' ',COLOR_SHADOW);if(k=='q'){s->done=1;return;}if(k==' ')s->page_lines=0;else if(k=='\n')s->single_step=1;}}

/* ── Calculator ───────────────────────────────────────────────── */
static const char *calc_ptr;
static int calc_expr(void);
static int calc_term(void){if(!calc_ptr)return 0;while(*calc_ptr==' ')calc_ptr++;if(*calc_ptr=='('){calc_ptr++;int v=calc_expr();while(*calc_ptr==' ')calc_ptr++;if(*calc_ptr==')')calc_ptr++;return v;}int neg=0;if(*calc_ptr=='-'){neg=1;calc_ptr++;}int v=0;while(*calc_ptr>='0'&&*calc_ptr<='9'){v=v*10+(*calc_ptr)-'0';calc_ptr++;}return neg?-v:v;}
static int calc_mul(void){int v=calc_term();while(1){while(*calc_ptr==' ')calc_ptr++;if(*calc_ptr=='*'){calc_ptr++;v*=calc_term();}else if(*calc_ptr=='/'){calc_ptr++;int d=calc_term();v=(d!=0)?v/d:0;}else break;}return v;}
static int calc_expr(void){int v=calc_mul();while(1){while(*calc_ptr==' ')calc_ptr++;if(*calc_ptr=='+'){calc_ptr++;v+=calc_mul();}else if(*calc_ptr=='-'){calc_ptr++;v-=calc_mul();}else break;}return v;}

/* ── b64 encode ───────────────────────────────────────────────── */
static const char b64c[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static void b64_encode(const unsigned char *in,int len){if(!in||len<=0)return;for(int i=0;i<len;i+=3){unsigned int v=(unsigned int)in[i]<<16;if(i+1<len)v|=(unsigned int)in[i+1]<<8;if(i+2<len)v|=in[i+2];pchar_a(b64c[(v>>18)&63]);pchar_a(b64c[(v>>12)&63]);pchar_a(i+1<len?b64c[(v>>6)&63]:'=');pchar_a(i+2<len?b64c[v&63]:'=');}pchar_a('\n');}

/* ── netstats ─────────────────────────────────────────────────── */
static void print_netstats(void){
    prt("=== Network Statistics ===\n");
    prt("TX pkts:    ");prt_uint(net_stats.tx_packets);pchar_a('\n');
    prt("RX pkts:    ");prt_uint(net_stats.rx_packets);pchar_a('\n');
    prt("TX errors:  ");prt_uint(net_stats.tx_errors);pchar_a('\n');
    prt("RX errors:  ");prt_uint(net_stats.rx_errors);pchar_a('\n');
    prt("Dropped:    ");prt_uint(net_stats.rx_dropped);pchar_a('\n');
    prt("ARP req TX: ");prt_uint(net_stats.arp_requests_sent);pchar_a('\n');
    prt("ARP rep TX: ");prt_uint(net_stats.arp_replies_sent);pchar_a('\n');
    prt("ARP rep RX: ");prt_uint(net_stats.arp_replies_recv);pchar_a('\n');
    prt("ARP hits:   ");prt_uint(net_stats.arp_cache_hits);pchar_a('\n');
    prt("ARP miss:   ");prt_uint(net_stats.arp_cache_misses);pchar_a('\n');
    prt("DHCP disc:  ");prt_uint(net_stats.dhcp_discover);pchar_a('\n');
    prt("DHCP offer: ");prt_uint(net_stats.dhcp_offer);pchar_a('\n');
    prt("DHCP req:   ");prt_uint(net_stats.dhcp_request);pchar_a('\n');
    prt("DHCP ack:   ");prt_uint(net_stats.dhcp_ack);pchar_a('\n');
    prt("DNS query:  ");prt_uint(net_stats.dns_queries);pchar_a('\n');
    prt("DNS reply:  ");prt_uint(net_stats.dns_replies);pchar_a('\n');
    prt("DNS tmout:  ");prt_uint(net_stats.dns_timeouts);pchar_a('\n');
    prt("ICMP TX:    ");prt_uint(net_stats.icmp_echo_sent);pchar_a('\n');
    prt("ICMP RX:    ");prt_uint(net_stats.icmp_echo_recv);pchar_a('\n');
    prt("ICMP tmout: ");prt_uint(net_stats.icmp_timeout);pchar_a('\n');
    prt("TCP conn:   ");prt_uint(net_stats.tcp_connect);pchar_a('\n');
    prt("TCP TX:     ");prt_uint(net_stats.tcp_data_tx);pchar_a('\n');
    prt("TCP RX:     ");prt_uint(net_stats.tcp_data_rx);pchar_a('\n');
    prt("TCP RST:    ");prt_uint(net_stats.tcp_rst);pchar_a('\n');
    prt("TCP tmout:  ");prt_uint(net_stats.tcp_timeout);pchar_a('\n');
    prt("IP cksum e: ");prt_uint(net_stats.ip_cksum_errors);pchar_a('\n');
    prt("IP malform: ");prt_uint(net_stats.ip_malformed);pchar_a('\n');
    prt("Timeouts:   ");prt_uint(net_stats.timeouts);pchar_a('\n');
}

/* ================================================================
   SHELL COMMAND HANDLER
   ================================================================ */
static void do_cmd(char *cmd){
    while(*cmd==' ')cmd++;if(!*cmd)return;
    char verb[64];int vi=0;
    while(cmd[vi]&&cmd[vi]!=' '&&vi<63){verb[vi]=cmd[vi];vi++;}verb[vi]=0;
    char *args=cmd+vi;while(*args==' ')args++;

    if(strcmp(verb,"cls")==0||strcmp(verb,"clear")==0){cls();return;}
    if(strcmp(verb,"version")==0){prt("Aethrix " VERSION "\n");return;}
    if(strcmp(verb,"whoami")==0){prt(cu);if(cr)prt(" (root)");pchar_a('\n');return;}
    if(strcmp(verb,"now")==0){
        int h=cmos_bcd(cmos_read(4)),m=cmos_bcd(cmos_read(2)),s=cmos_bcd(cmos_read(0));
        int d=cmos_bcd(cmos_read(7)),mo=cmos_bcd(cmos_read(8)),y=cmos_bcd(cmos_read(9));
        prt_int(h);pchar_a(':');if(m<10)pchar_a('0');prt_int(m);pchar_a(':');if(s<10)pchar_a('0');prt_int(s);
        prt("  ");prt_int(d);pchar_a('/');if(mo<10)pchar_a('0');prt_int(mo);prt("/20");prt_int(y);pchar_a('\n');return;
    }
    if(strcmp(verb,"sysinfo")==0){
        prt("Aethrix " VERSION "\nUser: ");prt(cu);
        prt("\nDisk: ");prt(disk_ok?"OK":"None");
        prt("\nNIC:  ");prt(nic_type==NIC_RTL?"RTL8139":nic_type==NIC_PCNET?"PCnet":nic_type==NIC_E1000?"E1000":"None");
        prt("\nWiFi: ");prt(wifi_state==WIFI_NONE?"None":wifi_state==WIFI_DETECTED?"Detected":"Connected");
        prt("\nNet:  ");prt(net_up?"UP":"DOWN");if(net_up){prt(" IP=");prt_ip(net_ip);}
        prt("\nFiles:");prt_int(fc);prt("\nUsers:");prt_int(uc);
        prt("\nTSC:  ");prt_uint(rdtsc_ticks_per_ms);prt(" ticks/ms\n");return;
    }
    if(strcmp(verb,"disk")==0){prt(disk_ok?"Disk: OK\n":"Disk: None\n");return;}
    if(strcmp(verb,"save")==0||strcmp(verb,"netsave")==0){save_disk();return;}
    if(strcmp(verb,"sound")==0){if(strcmp(args,"on")==0){sound_on=1;prt("ON\n");}else if(strcmp(args,"off")==0){sound_on=0;prt("OFF\n");}else prt("sound on|off\n");return;}
    if(strcmp(verb,"beep")==0){char *p=args;unsigned int freq=0,ms=200;while(*p>='0'&&*p<='9'){freq=freq*10+(*p)-'0';p++;}while(*p==' ')p++;if(*p){ms=0;while(*p>='0'&&*p<='9'){ms=ms*10+(*p)-'0';p++;}}if(freq)sound_play(freq,ms);else prt("beep <hz> [ms]\n");return;}
    if(strcmp(verb,"play")==0){static const char *n[]={"C4","D4","E4","F4","G4","A4","B4","C5"};static const unsigned int f[]={262,294,330,349,392,440,494,523};for(int i=0;i<8;i++)if(strcmp(args,n[i])==0){sound_play(f[i],300);return;}prt("C4 D4 E4 F4 G4 A4 B4 C5\n");return;}
    if(strcmp(verb,"calc")==0){if(!*args){prt("calc <expr>\n");return;}calc_ptr=args;prt_int(calc_expr());pchar_a('\n');return;}

    if(strcmp(verb,"ls")==0){
        int found=0;
        for(int i=0;i<fc;i++)if(files[i].parent==cwd){
            if(files[i].is_dir){prt_b(files[i].n);pchar_b('/');}
            else{char *dot=files[i].n;while(*dot&&*dot!='.')dot++;if(*dot=='.'){char *ext=dot+1;if(strcmp(ext,"txt")==0||strcmp(ext,"py")==0||strcmp(ext,"c")==0||strcmp(ext,"h")==0||strcmp(ext,"md")==0||strcmp(ext,"sh")==0||strcmp(ext,"cpp")==0||strcmp(ext,"js")==0||strcmp(ext,"html")==0||strcmp(ext,"css")==0)prt_g(files[i].n);else prt(files[i].n);}else prt(files[i].n);}
            pchar_a('\n');found++;
        }
        if(!found)prt("(empty)\n");return;
    }
    if(strcmp(verb,"lsall")==0){for(int i=0;i<fc;i++)if(files[i].parent==cwd){prt(files[i].is_dir?"DIR ":"FILE");prt("  ");prt(files[i].n);prt("  ");prt_int(files[i].s);prt("B\n");}return;}
    if(strcmp(verb,"pwd")==0){char pw[256];build_pwd(pw);prt_m(pw);pchar_a('\n');return;}
    if(strcmp(verb,"cd")==0){
        char *p=args;
        if(strcmp(p,"~")==0||!*p){cwd=0;return;}
        if(strcmp(p,"..")==0){if(cwd==0)return;if(cwd>0&&cwd<=fc)cwd=files[cwd-1].parent;else cwd=0;return;}
        for(int i=0;i<fc;i++)if(files[i].parent==cwd&&files[i].is_dir&&strcmp(files[i].n,p)==0){cwd=i+1;return;}
        prt("Not found\n");return;
    }
    if(strcmp(verb,"mkdir")==0){char *n=args;if(!*n){prt("mkdir <name>\n");return;}if(ffile(n)>=0){prt("Exists\n");return;}if(fc>=MAX_FILES){prt("Max files\n");return;}strcpy(files[fc].n,n);files[fc].is_dir=1;files[fc].c[0]=0;files[fc].s=0;files[fc].parent=cwd;fc++;save_disk();prt("Created\n");return;}
    if(strcmp(verb,"touch")==0){char *n=args;if(!*n){prt("touch <name>\n");return;}if(ffile(n)>=0)return;if(fc>=MAX_FILES){prt("Max files\n");return;}strcpy(files[fc].n,n);files[fc].is_dir=0;files[fc].c[0]=0;files[fc].s=0;files[fc].parent=cwd;fc++;save_disk();return;}
    if(strcmp(verb,"nano")==0){nano(args);return;}
    if(strcmp(verb,"cat")==0){int id=ffile(args);if(id<0||id>=fc){prt("Not found\n");return;}if(files[id].is_dir){prt("Is directory\n");return;}prt(files[id].c);pchar_a('\n');return;}
    if(strcmp(verb,"echo")==0){prt(args);pchar_a('\n');return;}
    if(strcmp(verb,"find")==0){int found=0;for(int i=0;i<fc;i++)if(files[i].parent==cwd&&(strstr(files[i].n,args)||(!files[i].is_dir&&strstr(files[i].c,args)))){prt(files[i].n);pchar_a('\n');found++;}if(!found)prt("No matches\n");return;}
    if(strcmp(verb,"grep")==0){char pat[128],fn[64];int pi=0;while(args[pi]&&args[pi]!=' '&&pi<127){pat[pi]=args[pi];pi++;}pat[pi]=0;char *fp=args+pi;while(*fp==' ')fp++;strcpy(fn,fp);int id=ffile(fn);if(id<0||id>=fc){prt("Not found\n");return;}GrepCtx g;g.pat=pat;g.invert=0;g.icase=0;g.count=0;g.linenum=0;g.found=0;each_line(files[id].c,grep_line_cb,&g);return;}
    if(strcmp(verb,"cp")==0||strcmp(verb,"dup")==0){char src[64],dst[64];int si=0;while(args[si]&&args[si]!=' '&&si<63){src[si]=args[si];si++;}src[si]=0;char *dp=args+si;while(*dp==' ')dp++;strncpy(dst,dp,63);dst[63]=0;int id=ffile(src);if(id<0||id>=fc){prt("Not found\n");return;}if(fc>=MAX_FILES){prt("Max files\n");return;}if(ffile(dst)>=0){prt("Exists\n");return;}files[fc]=files[id];strcpy(files[fc].n,dst);fc++;save_disk();prt("Copied\n");return;}
    if(strcmp(verb,"mv")==0||strcmp(verb,"relocate")==0){char src[64],dst[64];int si=0;while(args[si]&&args[si]!=' '&&si<63){src[si]=args[si];si++;}src[si]=0;char *dp=args+si;while(*dp==' ')dp++;strncpy(dst,dp,63);dst[63]=0;int id=ffile(src);if(id<0||id>=fc){prt("Not found\n");return;}strncpy(files[id].n,dst,63);files[id].n[63]=0;save_disk();prt("Moved\n");return;}
    if(strcmp(verb,"rm")==0||strcmp(verb,"destroy")==0){if(!cr){prt("Permission denied\n");return;}int id=ffile(args);if(id<0||id>=fc){prt("Not found\n");return;}for(int i=id;i<fc-1;i++)files[i]=files[i+1];fc--;save_disk();prt("Removed\n");return;}

    if(strcmp(verb,"users")==0){if(!cr){prt("Permission denied\n");return;}for(int i=0;i<uc;i++){prt(users[i].n);prt(users[i].r?" [root]\n":"\n");}return;}
    if(strcmp(verb,"go")==0&&strcmp(args,"admin")==0){if(cr){prt("Already root\n");return;}int rid=-1;for(int i=0;i<uc;i++)if(users[i].r){rid=i;break;}if(rid<0){prt("No root user\n");return;}prt("Root password: ");char rp[32];input(rp,32,1);if(strcmp(rp,users[rid].p)==0){strcpy(cu,users[rid].n);cr=1;prt("OK\n");}else prt("Wrong password\n");return;}
    if(strcmp(verb,"changepass")==0){char *who=args;if(!*who)who=cu;int id=fuser(who);if(id<0){prt("Not found\n");return;}if(!cr&&strcmp(who,cu)!=0){prt("Permission denied\n");return;}prt("New password: ");char np[32];input(np,32,1);prt("Confirm: ");char cp2[32];input(cp2,32,1);if(strcmp(np,cp2)!=0){prt("Mismatch\n");return;}strncpy(users[id].p,np,31);users[id].p[31]=0;save_disk();prt("Changed\n");return;}
    if(strcmp(verb,"logout")==0||strcmp(verb,"exit")==0){save_disk();cu[0]=0;cr=0;cwd=0;for(volatile int i=0;i<2000000;i++);login();return;}
    if(strcmp(verb,"shutdown")==0){save_disk();cls();prt("Aethrix halted.\n");asm volatile("cli");while(1)asm volatile("hlt");}

    if(strcmp(verb,"ifconfig")==0){prt("eth0: flags=4163 mtu 1500\n");if(net_up){prt(" inet ");prt_ip(net_ip);prt(" netmask ");prt_ip(net_mask);prt(" gw ");prt_ip(net_gw);pchar_a('\n');}prt(" ether ");for(int i=0;i<6;i++){prt_hex8(nic_mac[i]);if(i<5)pchar_a(':');}pchar_a('\n');return;}
    if(strcmp(verb,"netstat")==0){prt("eth0: RX ");prt_uint(net_stats.rx_packets);prt(" TX ");prt_uint(net_stats.tx_packets);pchar_a('\n');return;}
    if(strcmp(verb,"netstats")==0){print_netstats();return;}
    if(strcmp(verb,"route")==0){prt("default via ");prt_ip(net_gw);pchar_a('\n');return;}
    if(strcmp(verb,"arp")==0){
        arp_expire();int s=0;
        for(int i=0;i<ARP_CACHE;i++){
            if(arp_cache[i].nud_state==0)continue;
            prt_ip(arp_cache[i].ip);prt(" -> ");
            for(int j=0;j<6;j++){prt_hex8(arp_cache[i].mac[j]);if(j<5)pchar_a(':');}
            pchar_a(' ');
            const char *st=arp_cache[i].nud_state==NUD_REACHABLE?"REACHABLE":arp_cache[i].nud_state==NUD_STALE?"STALE":arp_cache[i].nud_state==NUD_INCOMPLETE?"INCOMPLETE":arp_cache[i].nud_state==NUD_FAILED?"FAILED":"UNKNOWN";
            prt(st);pchar_a('\n');s++;
        }
        if(!s)prt("(empty)\n");return;
    }
    if(strcmp(verb,"ipset")==0){
        unsigned char a[3][4]={{0}};int ai=0,val=0,pi=0;
        for(char *p=args;*p&&ai<3;p++){if(*p>='0'&&*p<='9'){val=val*10+(*p-'0');}else if(*p=='.'||*p==' '){a[ai][pi]=(unsigned char)val;val=0;pi++;if(*p==' '||pi==4){pi=0;ai++;}}}
        if(pi<4&&ai<3)a[ai][pi]=(unsigned char)val;
        memcpy(net_ip,a[0],4);memcpy(net_mask,a[1],4);memcpy(net_gw,a[2],4);net_up=1;prt("OK\n");return;
    }
    if(strcmp(verb,"dhcp")==0||strcmp(verb,"renew")==0){dhcp_do();return;}
    if(strcmp(verb,"wifi")==0){wifi_cmd(args);return;}
    if(strcmp(verb,"ping")==0){
        unsigned char dst[4]={8,8,8,8};int cnt=4;char *p=args;
        if(strncmp(p,"-c ",3)==0){p+=3;cnt=atoi(p);while(*p&&*p!=' ')p++;while(*p==' ')p++;}
        if(*p)parse_ip(p,dst);else if(*args)parse_ip(args,dst);
        do_ping(dst,cnt);return;
    }
    if(strcmp(verb,"dns")==0){dns_cmd(args);return;}
    if(strcmp(verb,"netdebug")==0){
        prt("NIC: ");prt(nic_type==NIC_RTL?"RTL8139":nic_type==NIC_PCNET?"PCnet":nic_type==NIC_E1000?"E1000":"None");pchar_a('\n');
        prt("MAC: ");for(int i=0;i<6;i++){prt_hex8(nic_mac[i]);if(i<5)pchar_a(':');}pchar_a('\n');
        prt("IP:  ");prt_ip(net_ip);pchar_a('\n');prt("GW:  ");prt_ip(net_gw);pchar_a('\n');prt("DNS: ");prt_ip(net_dns);pchar_a('\n');
        prt("RX:  ");prt_uint(net_stats.rx_packets);prt("  TX: ");prt_uint(net_stats.tx_packets);pchar_a('\n');
        prt("Drp: ");prt_uint(net_stats.rx_dropped);prt("  TXerr: ");prt_uint(net_stats.tx_errors);pchar_a('\n');
        prt("WiFi:");prt(wifi_state==WIFI_NONE?"None":wifi_state==WIFI_DETECTED?"Detected":"Connected");pchar_a('\n');
        prt("Q:   head=");prt_int(pkt_q_head);prt(" tail=");prt_int(pkt_q_tail);pchar_a('\n');
        prt("TSC: ");prt_uint(rdtsc_ticks_per_ms);prt(" ticks/ms\n");
        return;
    }
    if(strcmp(verb,"webget")==0){
        if(!net_up){prt("No network\n");return;}
        unsigned char wip[4]={0};char wpath[128]="/";char *p=args;
        if(parse_ip(p,wip)){while(*p&&*p!=' ')p++;while(*p==' ')p++;if(*p){strncpy(wpath,p,127);wpath[127]=0;}}
        else{char host[64]={0};int hi=0;while(*p&&*p!=' '&&*p!='/'&&hi<63){host[hi]=*p;hi++;p++;}host[hi]=0;if(*p=='/')strncpy(wpath,p,127);if(!dns_lookup_ip(host,wip)){prt("DNS failed\n");return;}}
        static unsigned char gbuf[2048];
        int glen=http_get(wip,80,"aethrix",wpath,gbuf,2047);
        if(glen>0){gbuf[glen]=0;char *body=strstr_ptr((char*)gbuf,"\r\n\r\n");if(body)prt(body+4);else prt((char*)gbuf);}
        else prt("No response\n");pchar_a('\n');return;
    }
    if(strcmp(verb,"ask")==0||strcmp(verb,"aethrix")==0){
        if(!net_up){prt("No network. Use: dhcp\n");return;}
        if(!*args){prt("ask <question>\n");return;}
        unsigned char ddg_ip[4]={0};
        if(!dns_lookup_ip("api.duckduckgo.com",ddg_ip)){ddg_ip[0]=52;ddg_ip[1]=142;ddg_ip[2]=24;ddg_ip[3]=215;}
        prt("\n  ");prt_m("Aethrix AI");prt(" - Querying...\n\n");
        static char enc[512];int ei=0;
        for(int i=0;args[i]&&ei<500;i++){if(args[i]==' '){if(ei+3<500){enc[ei]='%';enc[ei+1]='2';enc[ei+2]='0';ei+=3;}}else enc[ei++]=args[i];}
        enc[ei]=0;
        static char path[600];path[0]=0;strcat(path,"/?q=");strcat(path,enc);strcat(path,"&format=json&no_html=1&skip_disambig=1");
        static unsigned char rbuf[2048];int rlen=http_get(ddg_ip,80,"api.duckduckgo.com",path,rbuf,2047);
        if(rlen<=0){prt("  No response\n");return;}rbuf[rlen]=0;
        char *body=strstr_ptr((char*)rbuf,"\r\n\r\n");if(!body){prt("  Invalid response\n");return;}body+=4;
        int found=0;
        char *answer=strstr_ptr(body,"\"Answer\":\"");char *abst=strstr_ptr(body,"\"AbstractText\":\"");
        char *heading=strstr_ptr(body,"\"Heading\":\"");char *abst_url=strstr_ptr(body,"\"AbstractURL\":\"");
        if(answer){answer+=10;prt("  ");while(*answer&&*answer!='"'){pchar_m(*answer);answer++;}pchar_a('\n');found=1;}
        if(abst&&!found){abst+=16;prt("  ");while(*abst&&*abst!='"'){pchar_a(*abst);abst++;}pchar_a('\n');found=1;}
        if(heading){heading+=10;prt_b("  Topic: ");while(*heading&&*heading!='"'){pchar_a(*heading);heading++;}pchar_a('\n');found=1;}
        if(abst_url){abst_url+=14;prt_g("  Source: ");while(*abst_url&&*abst_url!='"'){pchar_a(*abst_url);abst_url++;}pchar_a('\n');}
        if(!found)prt("  No results found.\n");pchar_a('\n');return;
    }
    if(strcmp(verb,"history")==0){for(int i=0;i<hist_count;i++){prt_int(i+1);prt(": ");prt(history[i]);pchar_a('\n');}return;}
    if(strcmp(verb,"alias")==0){if(!*args){for(int i=0;i<alias_count;i++){prt(aliases[i][0]);prt("='");prt(aliases[i][1]);prt("'\n");}return;}char an[64]={0};int ai=0;while(args[ai]&&args[ai]!='='&&ai<63){an[ai]=args[ai];ai++;}an[ai]=0;char *av=args+ai;if(*av=='=')av++;if(alias_count<20){strncpy(aliases[alias_count][0],an,63);strncpy(aliases[alias_count][1],av,63);alias_count++;}return;}
    if(strcmp(verb,"b64encode")==0){int id=ffile(args);if(id<0||id>=fc){prt("Not found\n");return;}b64_encode((unsigned char*)files[id].c,files[id].s);return;}
    if(strcmp(verb,"help")==0){
        prt("=== Aethrix " VERSION " ===\n");
        prt("FILE:   ls lsall pwd cd mkdir touch nano cat echo cp mv rm find grep\n");
        prt("USER:   whoami users go admin changepass logout shutdown exit\n");
        prt("SYS:    version sysinfo now disk save calc b64encode\n");
        prt("NET:    ifconfig netstat netstats route arp ping dns dhcp renew\n");
        prt("        ipset netdebug webget wifi\n");
        prt("SOUND:  beep play sound\n");
        prt("SHELL:  history alias\n");
        prt("AI:     ask <question>  (requires network)\n");
        return;
    }
    for(int i=0;i<alias_count;i++){if(strcmp(verb,aliases[i][0])==0){static char abuf[256];strncpy(abuf,aliases[i][1],255);abuf[255]=0;if(*args){strcat(abuf," ");strncat_s(abuf,args,255-strlen(abuf));}do_cmd(abuf);return;}}
    prt("Unknown: ");prt(verb);pchar_a('\n');
}

/* ── Shell loop ───────────────────────────────────────────────── */
static void shell(void){
    cls();
    prt("==============================================\n");
    prt("            Aethrix " VERSION "\n");
    prt("  Disk:");prt(disk_ok?"OK  ":"NO  ");prt("NIC:");prt(nic_type!=NIC_NONE?"OK  ":"NO  ");prt("Net:");prt(net_up?"UP":"DOWN");pchar_a('\n');
    prt("==============================================\n\n");
    prompt();
    static char cmd[256];int pos=0;int hist_pos=-1;
    while(1){
        net_process(4);
        unsigned char st=inb(0x64);if(!(st&0x01))continue;if(st&0x20){inb(0x60);continue;}
        char c=kb_translate(inb(0x60));
        if(c=='\n'){cmd[pos]=0;pos=0;pchar_a('\n');hist_add(cmd);hist_pos=-1;do_cmd(cmd);if(!cu[0])return;prompt();}
        else if(c=='\b'){if(pos>0){pos--;pchar_a('\b');}}
        else if(c==3){prt("^C\n");pos=0;prompt();}
        else if(c&&c>=' '&&c<='~'&&pos<255){cmd[pos]=c;pos++;pchar_a(c);}
    }
}

/* ── Login ────────────────────────────────────────────────────── */
static void login(void){
    while(1){
        cls();prt("==============================================\n");prt("                  Aethrix\n");prt("==============================================\n\n");
        char un[32],up[32];prt("Username: ");input(un,32,0);
        int id=fuser(un);if(id<0){prt("Not found\n");for(volatile int i=0;i<3000000;i++);continue;}
        prt("Password: ");input(up,32,1);
        if(strcmp(up,users[id].p)!=0){prt("Wrong password\n");for(volatile int i=0;i<3000000;i++);continue;}
        prt("\nWelcome, ");prt(un);prt("!\n");for(volatile int i=0;i<2000000;i++);
        strcpy(cu,users[id].n);cr=users[id].r;shell();return;
    }
}

/* ── First boot ───────────────────────────────────────────────── */
static void first_boot(void){
    while(1){
        cls();prt("==============================================\n");prt("          Aethrix - First Setup\n");prt("==============================================\n\n");
        char un[32],up[32],up2[32];
        prt("Username: ");input(un,32,0);
        if(!un[0]){prt("Username cannot be empty\n");for(volatile int i=0;i<2000000;i++);continue;}
        prt("Password: ");input(up,32,1);prt("Confirm:  ");input(up2,32,1);
        if(strcmp(up,up2)!=0){prt("Passwords do not match\n");for(volatile int i=0;i<3000000;i++);continue;}
        strncpy(users[0].n,un,31);users[0].n[31]=0;strncpy(users[0].p,up,31);users[0].p[31]=0;users[0].r=0;
        char rn[32];strncpy(rn,un,27);rn[27]=0;strcat(rn,"_root");
        strncpy(users[1].n,rn,31);users[1].n[31]=0;strncpy(users[1].p,up,31);users[1].p[31]=0;users[1].r=1;
        uc=2;fc=0;cwd=0;save_disk();
        prt("\nAccount: ");prt(un);prt("\nRoot:    ");prt(rn);prt("\n\nPress ENTER to login...");wait_enter();
        login();return;
    }
}

/* ── Kernel entry ─────────────────────────────────────────────── */
void kernel_main(unsigned int magic,unsigned int mb_addr){
    if(magic!=0x2BADB002)return;
    if(mb_addr){unsigned int *mbp=(unsigned int*)mb_addr;if(mbp[0]&1)mb_mem_upper=mbp[2];}
    outb(0x3D4,0x0A);outb(0x3D5,0x20);
    boot_screen();cls();
    calibrate_tsc();
    prt("Aethrix " VERSION " — TSC: ");prt_uint(rdtsc_ticks_per_ms);prt(" ticks/ms\n");
    memset(users,0,sizeof(users));memset(files,0,sizeof(files));
    memset(arp_cache,0,sizeof(arp_cache));
    memset(aliases,0,sizeof(aliases));memset(vars,0,sizeof(vars));
    memset(history,0,sizeof(history));memset(tcp_conns,0,sizeof(tcp_conns));
    memset(pkt_queue,0,sizeof(pkt_queue));memset(&net_stats,0,sizeof(net_stats));
    sockets_init();
    uc=0;fc=0;cwd=0;net_up=0;nic_type=NIC_NONE;
    alias_count=0;var_count=0;hist_count=0;lcg_seed=12345;
    boot_jingle();
    load_disk();
    detect_nic();
    if(nic_type!=NIC_NONE&&!net_up){
        prt("Auto-DHCP...\n");
        if(dhcp_do_with_retry(3))net_verify_connectivity();
    }
    if(uc==0)first_boot();else login();
}