/* ================================================================
   AETHRIX OS - tcp_validate.h
   TCP Phase 2: public interface for packet validation and checksum

   Declares the types and functions implemented in tcp_validate.c.
   Kept separate from tcp.h because these are Phase 2-specific
   parsing outputs, not part of Phase 1's core public API surface --
   a later phase's connection/state-machine code will most likely
   consume tcp_parse_segment()'s output as its own entry point's
   first step, so this header is the natural boundary between "is
   this a well-formed segment, and what's in it" and "what should we
   do about it."
   ================================================================ */

#ifndef AETHRIX_TCP_VALIDATE_H
#define AETHRIX_TCP_VALIDATE_H

#include <stdint.h>
#include "tcp.h"

/**
 * struct tcp_parsed_segment
 *
 * Every TCP header field already converted to host byte order, plus
 * pointers into the caller's own receive buffer for the options and
 * payload regions. No copies are made -- options/payload point
 * directly into whatever buffer was passed to tcp_parse_segment(),
 * so that buffer must remain valid for as long as this struct is in
 * use.
 *
 * Carries no connection-state interpretation (no notion of whether
 * seq_num is in-window, whether ack_num is plausible for an
 * existing connection, etc.) -- that belongs to a later phase.
 */
typedef struct {
    uint16_t src_port;
    uint16_t dst_port;
    uint32_t seq_num;
    uint32_t ack_num;
    uint8_t  flags;
    uint16_t window;
    uint16_t checksum;
    uint16_t urgent_ptr;

    uint32_t hdr_len;        /* header + options length, in bytes    */
    const uint8_t *options;  /* points into caller's buffer, or NULL
                                 if hdr_len == TCP_MIN_HDR_LEN         */
    uint32_t options_len;

    const uint8_t *payload;  /* points into caller's buffer, or NULL
                                 if payload_len == 0                   */
    uint32_t payload_len;
} tcp_parsed_segment_t;

/**
 * struct tcp_parsed_options
 *
 * Result of walking a segment's option list. Each field is only
 * meaningful when its corresponding have_*/sack_permitted flag is
 * set. This phase only extracts these values -- it does not act on
 * them (no MSS clamping, no window scaling applied anywhere, no
 * SACK-based retransmission), since there is no connection state or
 * retransmission queue yet for them to inform.
 */
typedef struct {
    int      have_mss;
    uint16_t mss;

    int      have_window_scale;
    uint8_t  window_scale;

    int      sack_permitted;

    int      have_timestamp;
    uint32_t timestamp_value;
    uint32_t timestamp_echo;
} tcp_parsed_options_t;

/**
 * tcp_checksum()
 *
 * Computes the TCP checksum (RFC 793 section 3.1) over the IPv4
 * pseudo-header followed by a complete TCP segment (header +
 * options + payload). Exposed publicly so a later phase's transmit
 * path can call it directly rather than duplicating the pseudo-
 * header construction.
 */
uint16_t tcp_checksum(uint32_t src_ip, uint32_t dst_ip,
                       const uint8_t *segment, uint32_t segment_len);

/**
 * tcp_parse_segment()
 *
 * Validates framing, verifies the checksum, parses options, and
 * fills *out_segment / *out_options describing a received TCP
 * segment -- without interpreting anything that requires knowledge
 * of an existing connection or the TCP state machine.
 *
 * src_ip/dst_ip are the IPv4 addresses from the already-validated
 * IPv4 header (network byte order), required for the pseudo-header
 * checksum. buffer must contain at least len valid bytes; every
 * field this function reads is bounds-checked before the read
 * happens.
 *
 * Returns 1 and fills the output parameters on success. Returns 0
 * on any validation failure, having already updated the appropriate
 * tcp_stats_t counter; output parameters are left unwritten in that
 * case.
 */
int tcp_parse_segment(uint32_t src_ip, uint32_t dst_ip,
                       const uint8_t *buffer, uint32_t len,
                       tcp_parsed_segment_t *out_segment,
                       tcp_parsed_options_t *out_options);

/**
 * tcp_finalize_checksum()
 *
 * Computes and writes the checksum field into a fully-assembled
 * outgoing segment (header complete, options written, payload
 * copied in, checksum field expected to be zero on entry). Does not
 * build or transmit a segment itself -- only performs checksum
 * generation, per this phase's scope.
 */
void tcp_finalize_checksum(uint32_t src_ip, uint32_t dst_ip,
                            uint8_t *segment, uint32_t segment_len);

#endif /* AETHRIX_TCP_VALIDATE_H */