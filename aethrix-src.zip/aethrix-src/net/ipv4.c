/* ================================================================
   AETHRIX OS - ipv4.c
   Internet Protocol v4: validation, checksum, dispatch, send
   ================================================================ */

#include "ipv4.h"
#include "ethernet.h"
#include "arp.h"
#include "endian.h"

/* ── Assumptions about surrounding headers ────────────────────────
   This file was written without visibility into ethernet.h / arp.h,
   so it assumes the following are already declared there. Reconcile
   names against your actual headers before building:

     extern uint8_t  local_mac[6];
     extern uint32_t local_ip;                  (network byte order)
     int eth_send(const uint8_t *dst_mac, uint16_t ethertype,
                  const uint8_t *payload, uint32_t payload_len);
     int arp_lookup(uint32_t ip, uint8_t *out_mac);
     #define ETH_TYPE_IPV4 0x0800

   arp_lookup() and eth_send() match the signatures used in the ARP
   and Ethernet layers already written for this project. If your
   actual field/function names differ, only the call sites below
   need to change -- the logic does not depend on them beyond this. */

extern uint8_t  local_mac[6];
extern uint32_t local_ip;

/* Transport-layer entry points. Declared here rather than pulled in
   via icmp.h/udp.h/tcp.h so this file doesn't take on an include
   dependency on those layers beyond the three function signatures
   it actually calls -- IPv4 dispatches to them but never implements
   or inspects their internals. If icmp.h/udp.h/tcp.h already declare
   these with matching signatures, these externs are redundant but
   harmless; if the real signatures differ, update the calls below
   and these declarations together. */
extern void icmp_receive(uint32_t src_ip, uint8_t *payload, uint32_t len);
extern void udp_receive(uint32_t src_ip, uint8_t *payload, uint32_t len);
extern void tcp_receive(uint32_t src_ip, uint8_t *payload, uint32_t len);

#define IPV4_MAX_PACKET     65535   /* per the 16-bit total_len field */

/* ── Statistics ────────────────────────────────────────────────────
   ipv4_stats_t is declared in ipv4.h; only the live instance lives
   here. */
static ipv4_stats_t ipv4_stats = {0, 0, 0, 0, 0, 0, 0, 0};

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   IPV4_DEBUG_ENABLED locally during bring-up. Not wired to a
   specific logging call since this file doesn't own logging policy. */
#define IPV4_DEBUG_ENABLED 0
static inline void ipv4_debug(const char *msg)
{
#if IPV4_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* ── Identification counter ───────────────────────────────────────
   RFC 791 wants each transmitted datagram to carry a value here
   that's reasonably unlikely to collide with recent packets to the
   same destination. A simple incrementing counter is sufficient for
   a hobby OS -- it doesn't need to be globally unique, just not
   constant. */
static uint16_t ipv4_id_counter = 0;

/* ── Checksum ──────────────────────────────────────────────────────
   Standard Internet checksum (RFC 1071): ones'-complement sum of
   16-bit words, with any carry out of bit 15 folded back in, then
   ones'-complemented. Works for both header-only and full-datagram
   checksums, so transport layers can reuse this rather than each
   reimplementing it. */
uint16_t ipv4_checksum(const void *data, uint32_t len)
{
    const uint8_t *bytes = (const uint8_t*)data;
    uint32_t sum = 0;

    while(len > 1)
    {
        sum += (uint16_t)((bytes[0] << 8) | bytes[1]);
        bytes += 2;
        len   -= 2;
    }

    /* Odd trailing byte: treated as the high byte of a final word
       whose low byte is zero, per RFC 1071. */
    if(len == 1)
        sum += (uint16_t)(bytes[0] << 8);

    while(sum >> 16)
        sum = (sum & 0xFFFF) + (sum >> 16);

    return (uint16_t)~sum;
}

/* ── Header field accessors ───────────────────────────────────────
   ver_ihl packs two 4-bit fields; kept as small named helpers so
   the bit manipulation isn't repeated inline at every call site. */
static inline uint8_t ipv4_version(const struct ipv4_header *h)
{
    return (uint8_t)(h->ver_ihl >> 4);
}

static inline uint8_t ipv4_ihl_words(const struct ipv4_header *h)
{
    return (uint8_t)(h->ver_ihl & 0x0F);
}

/* ── Packet validation ─────────────────────────────────────────────
   Every check here exists to make the reads that follow provably
   safe: len is checked against both the minimum fixed header size
   and the header's own claimed length before anything past the
   first 20 bytes is touched, and total_len is checked against len
   before it's trusted for anything downstream. */
static int ipv4_packet_is_valid(const uint8_t *buffer, uint32_t len,
                                 const struct ipv4_header *hdr,
                                 uint32_t *out_hdr_len,
                                 uint32_t *out_total_len)
{
    if(len < IPV4_MIN_HDR_LEN)
    {
        ipv4_debug("ipv4: packet shorter than minimum header");
        return 0;
    }

    if(ipv4_version(hdr) != IPV4_VERSION)
    {
        ipv4_debug("ipv4: unsupported version");
        return 0;
    }

    uint8_t ihl_words = ipv4_ihl_words(hdr);
    if(ihl_words < IPV4_MIN_IHL_WORDS)
    {
        ipv4_debug("ipv4: IHL below minimum");
        return 0;
    }

    uint32_t hdr_len = (uint32_t)ihl_words * 4;
    if(hdr_len > len)
    {
        ipv4_debug("ipv4: header length exceeds received buffer");
        return 0;
    }

    uint32_t total_len = ntohs(hdr->total_len);
    if(total_len < hdr_len)
    {
        ipv4_debug("ipv4: total length smaller than header length");
        return 0;
    }
    if(total_len > len)
    {
        ipv4_debug("ipv4: total length exceeds received buffer");
        return 0;
    }

    if(hdr->ttl == 0)
    {
        ipv4_stats.ttl_expired++;
        ipv4_debug("ipv4: TTL expired");
        return 0;
    }

    /* Destination filter: accept unicast to us or the limited
       broadcast address. Anything else isn't ours to process --
       this build doesn't route. */
    if(hdr->dst_addr != local_ip && hdr->dst_addr != 0xFFFFFFFF)
    {
        ipv4_debug("ipv4: destination address not local");
        return 0;
    }

    *out_hdr_len  = hdr_len;
    *out_total_len = total_len;
    return 1;
}

/* Verify the header checksum over exactly the header bytes (options
   included, payload excluded). The checksum field itself is part of
   the summed range -- a correct checksum over the whole header
   (including the checksum field as received) always sums to zero. */
static int ipv4_checksum_is_valid(const struct ipv4_header *hdr, uint32_t hdr_len)
{
    return ipv4_checksum(hdr, hdr_len) == 0;
}

/* Detect fragmentation. This build does not implement reassembly;
   fragments are safely rejected rather than partially processed, so
   we never hand a transport layer an incomplete datagram. */
static int ipv4_is_fragment(const struct ipv4_header *hdr)
{
    uint16_t flags_frag = ntohs(hdr->flags_frag);
    int      more_frags = (flags_frag & IPV4_FLAG_MF) != 0;
    int      has_offset  = (flags_frag & IPV4_FRAG_OFFSET_MASK) != 0;
    return more_frags || has_offset;
}

/* ── Receive ───────────────────────────────────────────────────────
   Called by the Ethernet layer for every frame with EtherType IPv4.
   Owns validation, checksum verification, fragment rejection, and
   protocol dispatch -- nothing below that belongs to ICMP/UDP/TCP
   is implemented here. */
void ipv4_receive(uint8_t *buffer, uint32_t len)
{
    if(buffer == 0)
    {
        ipv4_stats.malformed++;
        ipv4_debug("ipv4: null buffer");
        return;
    }

    if(len < IPV4_MIN_HDR_LEN)
    {
        ipv4_stats.malformed++;
        ipv4_debug("ipv4: packet too short");
        return;
    }

    struct ipv4_header *hdr = (struct ipv4_header*)buffer;

    uint32_t hdr_len = 0, total_len = 0;
    if(!ipv4_packet_is_valid(buffer, len, hdr, &hdr_len, &total_len))
    {
        /* ttl_expired is counted inside ipv4_packet_is_valid() when
           that's specifically why validation failed; everything
           else lands here as a generic malformed/dropped packet. */
        if(hdr->ttl != 0)
            ipv4_stats.malformed++;
        return;
    }

    if(!ipv4_checksum_is_valid(hdr, hdr_len))
    {
        ipv4_stats.checksum_failures++;
        ipv4_debug("ipv4: checksum failure");
        return;
    }

    if(ipv4_is_fragment(hdr))
    {
        ipv4_stats.fragmented++;
        ipv4_debug("ipv4: fragmented packet rejected");
        return;
    }

    uint8_t  *payload     = buffer + hdr_len;
    uint32_t  payload_len = total_len - hdr_len;

    switch(hdr->protocol)
    {
        case IPV4_PROTO_ICMP:
            ipv4_stats.rx_packets++;
            icmp_receive(hdr->src_addr, payload, payload_len);
            break;

        case IPV4_PROTO_UDP:
            ipv4_stats.rx_packets++;
            udp_receive(hdr->src_addr, payload, payload_len);
            break;

        case IPV4_PROTO_TCP:
            ipv4_stats.rx_packets++;
            tcp_receive(hdr->src_addr, payload, payload_len);
            break;

        default:
            ipv4_stats.unknown_protocol++;
            ipv4_debug("ipv4: unknown protocol");
            break;
    }
}

/* ── Send ────────────────────────────────────────────────────────
   Builds an IPv4 header around payload, resolves the destination
   MAC via ARP, and hands the assembled datagram to the Ethernet
   layer. Does not implement ARP itself -- a cache miss simply fails
   the send rather than blocking to wait for a reply, since this
   file has no business owning that retry/timeout policy. */
int ipv4_send(uint32_t dst_ip, uint8_t protocol,
              const uint8_t *payload, uint32_t payload_len)
{
    if(payload == 0 && payload_len != 0)
    {
        ipv4_debug("ipv4_send: null payload with nonzero length");
        return 0;
    }

    uint32_t total_len = IPV4_MIN_HDR_LEN + payload_len;
    if(total_len > IPV4_MAX_PACKET)
    {
        ipv4_debug("ipv4_send: payload too large for a single datagram");
        return 0;
    }

    uint8_t dst_mac[6];
    if(!arp_lookup(dst_ip, dst_mac))
    {
        ipv4_stats.dropped++;
        ipv4_debug("ipv4_send: ARP miss, packet dropped");
        return 0;
    }

    uint8_t packet[IPV4_MIN_HDR_LEN + 1500];
    if(total_len > sizeof(packet))
    {
        ipv4_debug("ipv4_send: payload exceeds local send buffer");
        return 0;
    }

    struct ipv4_header *hdr = (struct ipv4_header*)packet;
    hdr->ver_ihl    = (uint8_t)((IPV4_VERSION << 4) | IPV4_MIN_IHL_WORDS);
    hdr->tos        = 0;
    hdr->total_len  = htons((uint16_t)total_len);
    hdr->id         = htons(ipv4_id_counter++);
    hdr->flags_frag = htons(IPV4_FLAG_DF); /* single-datagram sends only */
    hdr->ttl        = IPV4_DEFAULT_TTL;
    hdr->protocol   = protocol;
    hdr->checksum   = 0;
    hdr->src_addr   = local_ip;
    hdr->dst_addr   = dst_ip;

    hdr->checksum = htons(ipv4_checksum(hdr, IPV4_MIN_HDR_LEN));

    if(payload_len > 0)
    {
        uint8_t *body = packet + IPV4_MIN_HDR_LEN;
        for(uint32_t i = 0; i < payload_len; i++)
            body[i] = payload[i];
    }

    int sent = eth_send(dst_mac, ETH_TYPE_IPV4, packet, total_len);
    if(sent)
        ipv4_stats.tx_packets++;
    else
        ipv4_stats.dropped++;

    return sent;
}

/* ── Stats accessor ────────────────────────────────────────────── */
ipv4_stats_t ipv4_get_stats(void)
{
    return ipv4_stats;
}