/* ================================================================
   AETHRIX OS - icmp.c
   Internet Control Message Protocol: Echo Request / Reply
   ================================================================ */

#include "icmp.h"
#include "ipv4.h"
#include "endian.h"

/* ── Assumptions about surrounding headers ────────────────────────
   This file was written without visibility into ipv4.h's exact
   signatures beyond what was established when ipv4.c was written
   earlier in this project. It assumes:

     uint16_t     ipv4_checksum(const void *data, uint32_t len);
     int          ipv4_send(uint32_t dst_ip, uint8_t protocol,
                             const uint8_t *payload, uint32_t payload_len);
     #define IPV4_PROTO_ICMP 1

   All three are already declared in ipv4.h as written for this
   project. If your actual signatures differ, only the call sites
   below need to change. */

#define ICMP_MAX_PAYLOAD    1472   /* keeps a full packet under a single
                                       Ethernet MTU alongside IPv4/ICMP
                                       headers; adjust if jumbo frames
                                       or fragmentation are ever added */

/* ── Statistics ────────────────────────────────────────────────────
   icmp_stats_t is declared in icmp.h; only the live instance lives
   here. */
static icmp_stats_t icmp_stats = {0, 0, 0, 0, 0, 0};

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   ICMP_DEBUG_ENABLED locally during bring-up. Not wired to a
   specific logging call since this file doesn't own logging policy. */
#define ICMP_DEBUG_ENABLED 0
static inline void icmp_debug(const char *msg)
{
#if ICMP_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* ── Packet validation ─────────────────────────────────────────────
   Every field read by this file lies within the first ICMP_HDR_LEN
   bytes of the header, or within [ICMP_HDR_LEN, len) for the
   payload -- the length check below is what makes both provably
   safe. Checksum is verified separately since it covers the whole
   packet, not just the fixed header. */
static int icmp_packet_is_valid(uint32_t len, const struct icmp_header *hdr)
{
    if(len < ICMP_HDR_LEN)
    {
        icmp_debug("icmp: packet shorter than header");
        return 0;
    }

    if(hdr->type == ICMP_TYPE_ECHO_REQUEST || hdr->type == ICMP_TYPE_ECHO_REPLY)
    {
        if(hdr->code != ICMP_CODE_ECHO)
        {
            icmp_debug("icmp: invalid code for echo type");
            return 0;
        }
    }

    /* Other types are not rejected here as "invalid" -- they're
       simply not implemented, and are counted separately as unknown
       types in icmp_receive() rather than as malformed packets. */
    return 1;
}

/* Reuses the IPv4 layer's checksum routine per RFC 1071 -- ICMP's
   checksum algorithm is identical to IPv4's, just computed over a
   different byte range (the whole ICMP message, not just a header),
   so there's no reason to duplicate the arithmetic here. */
static int icmp_checksum_is_valid(const uint8_t *buffer, uint32_t len)
{
    return ipv4_checksum(buffer, len) == 0;
}

/* ── Sending ───────────────────────────────────────────────────────
   Builds a complete ICMP message (header + payload) into a local
   buffer, computes the checksum over the whole thing, and hands it
   to ipv4_send(). Never touches Ethernet or IPv4 header fields
   directly -- that boundary belongs to ipv4_send(). */
static int icmp_send(uint32_t dst_ip, uint8_t type, uint8_t code,
                      uint16_t identifier, uint16_t sequence,
                      const uint8_t *payload, uint32_t payload_len)
{
    if(payload_len > ICMP_MAX_PAYLOAD)
    {
        icmp_debug("icmp_send: payload too large");
        return 0;
    }

    uint8_t packet[ICMP_HDR_LEN + ICMP_MAX_PAYLOAD];
    uint32_t total_len = ICMP_HDR_LEN + payload_len;

    struct icmp_header *hdr = (struct icmp_header*)packet;
    hdr->type       = type;
    hdr->code       = code;
    hdr->checksum   = 0;
    hdr->identifier = htons(identifier);
    hdr->sequence   = htons(sequence);

    if(payload_len > 0 && payload != 0)
    {
        uint8_t *body = packet + ICMP_HDR_LEN;
        for(uint32_t i = 0; i < payload_len; i++)
            body[i] = payload[i];
    }

    hdr->checksum = htons(ipv4_checksum(packet, total_len));

    return ipv4_send(dst_ip, IPV4_PROTO_ICMP, packet, total_len);
}

/* Send an Echo Request. Exposed publicly so a ping command or
   similar caller can initiate one; icmp.c does not track outstanding
   pings itself -- matching replies against requests is the caller's
   responsibility once icmp_receive() observes an Echo Reply. */
int icmp_send_echo_request(uint32_t dst_ip, uint16_t identifier,
                            uint16_t sequence,
                            const uint8_t *payload, uint32_t payload_len)
{
    return icmp_send(dst_ip, ICMP_TYPE_ECHO_REQUEST, ICMP_CODE_ECHO,
                      identifier, sequence, payload, payload_len);
}

/* Reply to an Echo Request: identifier, sequence, and payload are
   echoed back unchanged per RFC 792 -- the sender uses them to match
   the reply to its request, so ICMP must not alter them. */
static void icmp_send_echo_reply(uint32_t dst_ip, const struct icmp_header *req,
                                  const uint8_t *req_payload, uint32_t req_payload_len)
{
    int sent = icmp_send(dst_ip, ICMP_TYPE_ECHO_REPLY, ICMP_CODE_ECHO,
                          ntohs(req->identifier), ntohs(req->sequence),
                          req_payload, req_payload_len);
    if(sent)
        icmp_stats.echo_replies_sent++;

    icmp_debug(sent ? "icmp: echo reply sent" : "icmp: echo reply send failed");
}

/* ── Receive ───────────────────────────────────────────────────────
   Called by the IPv4 layer for every datagram with protocol ICMP.
   Owns validation, checksum verification, and Echo Request/Reply
   handling -- nothing here parses IPv4 or Ethernet headers, and
   unknown types are counted and dropped rather than processed. */
void icmp_receive(uint32_t src_ip, uint8_t *buffer, uint32_t len)
{
    if(buffer == 0)
    {
        icmp_stats.invalid_packets++;
        icmp_debug("icmp: null buffer");
        return;
    }

    if(len < ICMP_HDR_LEN)
    {
        icmp_stats.invalid_packets++;
        icmp_debug("icmp: packet too short");
        return;
    }

    struct icmp_header *hdr = (struct icmp_header*)buffer;

    if(!icmp_packet_is_valid(len, hdr))
    {
        icmp_stats.invalid_packets++;
        return;
    }

    if(!icmp_checksum_is_valid(buffer, len))
    {
        icmp_stats.checksum_failures++;
        icmp_debug("icmp: checksum failure");
        return;
    }

    uint8_t  *payload     = buffer + ICMP_HDR_LEN;
    uint32_t  payload_len = len - ICMP_HDR_LEN;

    switch(hdr->type)
    {
        case ICMP_TYPE_ECHO_REQUEST:
            icmp_stats.echo_requests_received++;
            icmp_debug("icmp: echo request received");
            icmp_send_echo_reply(src_ip, hdr, payload, payload_len);
            break;

        case ICMP_TYPE_ECHO_REPLY:
            icmp_stats.echo_replies_received++;
            icmp_debug("icmp: echo reply received");
            /* Matching this reply to an outstanding request (by
               identifier/sequence/source) is left to whatever issued
               the request -- e.g. a ping command polling stats or a
               registered callback -- since ICMP itself has no notion
               of "who is waiting for this." */
            break;

        default:
            icmp_stats.unknown_types++;
            icmp_debug("icmp: unknown type, dropped");
            break;
    }
}

/* ── Stats accessor ────────────────────────────────────────────── */
icmp_stats_t icmp_get_stats(void)
{
    return icmp_stats;
}