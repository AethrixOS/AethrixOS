/* ================================================================
   AETHRIX OS - ipv4.h
   Internet Protocol v4: public interface
   ================================================================ */

#ifndef AETHRIX_IPV4_H
#define AETHRIX_IPV4_H

#include <stdint.h>

/* ── Wire format ───────────────────────────────────────────────────
   Standard IPv4 header (RFC 791), fixed 20-byte portion only --
   options (if IHL > 5) are skipped over, not parsed. Packed so this
   struct's layout matches the on-wire layout exactly; ipv4.c casts
   a received buffer directly onto this struct. All multi-byte
   fields are network byte order and must go through ntohs/ntohl
   before use. */
struct ipv4_header {
    uint8_t  ver_ihl;      /* version (4 bits) + IHL in words (4 bits) */
    uint8_t  tos;
    uint16_t total_len;
    uint16_t id;
    uint16_t flags_frag;   /* flags (3 bits) + fragment offset (13)    */
    uint8_t  ttl;
    uint8_t  protocol;
    uint16_t checksum;
    uint32_t src_addr;
    uint32_t dst_addr;
} __attribute__((packed));

/* ── Constants ─────────────────────────────────────────────────── */
#define IPV4_VERSION        4
#define IPV4_MIN_IHL_WORDS  5          /* 20 bytes, no options       */
#define IPV4_MIN_HDR_LEN    20
#define IPV4_DEFAULT_TTL    64

#define IPV4_PROTO_ICMP     1
#define IPV4_PROTO_TCP      6
#define IPV4_PROTO_UDP      17

#define IPV4_FLAG_DF        0x4000     /* don't fragment, in flags_frag */
#define IPV4_FLAG_MF        0x2000     /* more fragments                */
#define IPV4_FRAG_OFFSET_MASK 0x1FFF

/* ── Statistics ────────────────────────────────────────────────────
   Snapshot returned by ipv4_get_stats(). Returned by value so
   callers can't mutate the live counters in ipv4.c. */
typedef struct {
    uint32_t rx_packets;
    uint32_t tx_packets;
    uint32_t dropped;
    uint32_t malformed;
    uint32_t checksum_failures;
    uint32_t ttl_expired;
    uint32_t fragmented;
    uint32_t unknown_protocol;
} ipv4_stats_t;

/* ── Public interface ──────────────────────────────────────────────

   ipv4_receive()
     Entry point called by the Ethernet layer for every frame with
     EtherType IPv4. Validates the header (bounds, version, IHL,
     checksum, TTL), rejects fragments, and dispatches the payload
     to ICMP/UDP/TCP by protocol number. buffer must contain at
     least len valid bytes; ipv4_receive() never reads past that.

   ipv4_send()
     Builds an IPv4 header around payload and sends it to dst_ip,
     resolving the destination MAC via the ARP layer. Returns 1 on
     successful handoff to Ethernet, 0 otherwise (e.g. ARP miss).

   ipv4_checksum()
     Standard Internet checksum (RFC 1071) over `len` bytes starting
     at data. Exposed so transport-layer code building pseudo-header
     checksums can reuse it instead of duplicating the algorithm.

   ipv4_get_stats()
     Returns a snapshot of the internal counters, for diagnostics or
     shell commands. */

void         ipv4_receive(uint8_t *buffer, uint32_t len);
int          ipv4_send(uint32_t dst_ip, uint8_t protocol,
                        const uint8_t *payload, uint32_t payload_len);
uint16_t     ipv4_checksum(const void *data, uint32_t len);
ipv4_stats_t ipv4_get_stats(void);

#endif /* AETHRIX_IPV4_H */