/* ================================================================
   AETHRIX OS - tcp_connection.c
   TCP Phase 3: connection table — allocation, lookup, deletion.
   No packet processing, no state transitions, no sequence
   validation -- see tcp_connection.h for this module's scope.
   ================================================================ */

#include "tcp_connection.h"

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   TCP_CONNECTION_DEBUG locally during bring-up. Not wired to a
   specific logging call since this file doesn't own logging policy. */
#define TCP_CONNECTION_DEBUG 0
static inline void tcp_connection_debug(const char *msg)
{
#if TCP_CONNECTION_DEBUG
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* ── Table entry ───────────────────────────────────────────────────
   Wraps tcp_connection_t (defined in tcp.h) with the in-use flag
   this module needs but tcp.h's connection structure doesn't carry.
   The wrapper is internal to this file -- everything outside this
   file only ever sees a tcp_connection_t* into the `conn` field
   below, never the wrapper itself, so tcp.h's struct layout stays
   exactly as Phase 1 defined it. */
typedef struct {
    tcp_connection_t conn;
    int              in_use;
} tcp_connection_slot_t;

/* ── The table ─────────────────────────────────────────────────────
   Fixed-size, statically allocated -- no malloc/free anywhere in
   this module, per the requirement that this be suitable for a
   hobby kernel that may not have (or want to rely on) a heap this
   early in the boot/network stack. */
static tcp_connection_slot_t table[TCP_CONNECTION_TABLE_SIZE];
static tcp_connection_stats_t stats;

/* ── Slot <-> handle helpers ───────────────────────────────────────
   The public API hands out tcp_connection_t* pointers, which are
   exactly &table[i].conn for some i. These helpers convert between
   that pointer and its owning slot without exposing the wrapper
   struct outside this file. */
static tcp_connection_slot_t *tcp_connection_slot_from_handle(tcp_connection_t *conn)
{
    if(conn == 0)
        return 0;

    /* conn must be the `conn` member of some table[i] -- computing
       the enclosing slot via pointer arithmetic on a member whose
       struct starts at offset 0 is safe and portable here since
       `conn` is the first field of tcp_connection_slot_t. */
    tcp_connection_slot_t *slot = (tcp_connection_slot_t*)conn;

    if(slot < &table[0] || slot > &table[TCP_CONNECTION_TABLE_SIZE - 1])
    {
        /* Not a pointer this table owns at all -- defend against
           callers passing garbage or a pointer from somewhere else,
           per tcp_connection_free()/tcp_connection_reset()'s
           documented no-op-on-invalid-pointer behavior. */
        return 0;
    }

    /* Guard against a pointer that lies within the table's memory
       range but isn't actually slot-aligned (e.g. a corrupted or
       miscalculated pointer) -- only accept exact matches. */
    uintptr_t offset = (uintptr_t)slot - (uintptr_t)&table[0];
    if(offset % sizeof(tcp_connection_slot_t) != 0)
        return 0;

    return slot;
}

/* ── Clearing ──────────────────────────────────────────────────────
   Explicitly zeroes every field rather than relying on a bulk
   memset, so this file has no dependency on a libc being available
   (consistent with how this project's DNS client avoided <string.h>
   for the same reason) and so every field this struct will ever
   grow is forced to be listed here rather than silently zeroed by a
   wildcard memset that could hide the fact that a new field needs
   its own reset semantics. */
static void tcp_connection_clear(tcp_connection_slot_t *slot)
{
    slot->conn.local_ip      = 0;
    slot->conn.remote_ip     = 0;
    slot->conn.local_port    = 0;
    slot->conn.remote_port   = 0;

    slot->conn.state         = TCP_STATE_CLOSED;

    slot->conn.snd_una       = 0;
    slot->conn.snd_nxt       = 0;
    slot->conn.snd_wnd       = 0;

    slot->conn.rcv_nxt       = 0;
    slot->conn.rcv_wnd       = 0;

    slot->conn.last_ack_sent = 0;

    slot->conn.retransmit_timer_ms = 0;
    slot->conn.idle_timer_ms       = 0;

    slot->conn.conn_flags    = 0;

    slot->conn.packets_sent     = 0;
    slot->conn.packets_received = 0;
    slot->conn.retransmissions  = 0;

    slot->in_use = 0;
}

/* ── Public API ────────────────────────────────────────────────── */

void tcp_connection_init(void)
{
    for(uint32_t i = 0; i < TCP_CONNECTION_TABLE_SIZE; i++)
        tcp_connection_clear(&table[i]);

    stats.active_connections    = 0;
    stats.allocated_connections = 0;
    stats.freed_connections     = 0;
    stats.allocation_failures   = 0;
    stats.lookup_hits           = 0;
    stats.lookup_misses         = 0;

    tcp_connection_debug("tcp_connection: table initialized");
}

tcp_connection_t *tcp_connection_alloc(uint32_t local_ip, uint32_t remote_ip,
                                        uint16_t local_port, uint16_t remote_port)
{
    for(uint32_t i = 0; i < TCP_CONNECTION_TABLE_SIZE; i++)
    {
        if(table[i].in_use)
            continue;

        /* Found a free slot. tcp_connection_clear() first guarantees
           no field carries over from whatever this slot held before
           -- important since slots are reused across the table's
           lifetime, and a stale sequence number or timer value
           leaking into a new connection would be a genuine
           correctness bug for whatever phase builds on this table. */
        tcp_connection_clear(&table[i]);

        table[i].conn.local_ip    = local_ip;
        table[i].conn.remote_ip   = remote_ip;
        table[i].conn.local_port  = local_port;
        table[i].conn.remote_port = remote_port;
        table[i].conn.state       = TCP_STATE_CLOSED;
        table[i].in_use           = 1;

        stats.active_connections++;
        stats.allocated_connections++;

        tcp_connection_debug("tcp_connection: allocated");
        return &table[i].conn;
    }

    stats.allocation_failures++;
    tcp_connection_debug("tcp_connection: allocation failed, table full");
    return 0;
}

void tcp_connection_free(tcp_connection_t *conn)
{
    tcp_connection_slot_t *slot = tcp_connection_slot_from_handle(conn);
    if(slot == 0 || !slot->in_use)
    {
        /* NULL, a foreign pointer, or a double-free: all treated as
           a no-op per this function's documented contract, rather
           than risking corruption of a slot that isn't actually
           this connection's anymore. */
        tcp_connection_debug("tcp_connection: free() called on invalid or already-free handle");
        return;
    }

    tcp_connection_clear(slot);

    stats.active_connections--;
    stats.freed_connections++;

    tcp_connection_debug("tcp_connection: freed");
}

void tcp_connection_reset(tcp_connection_t *conn)
{
    tcp_connection_slot_t *slot = tcp_connection_slot_from_handle(conn);
    if(slot == 0 || !slot->in_use)
    {
        tcp_connection_debug("tcp_connection: reset() called on invalid or unallocated handle");
        return;
    }

    uint32_t local_ip    = slot->conn.local_ip;
    uint32_t remote_ip   = slot->conn.remote_ip;
    uint16_t local_port  = slot->conn.local_port;
    uint16_t remote_port = slot->conn.remote_port;

    /* tcp_connection_clear() also zeroes in_use and the 4-tuple, so
       both are restored immediately after -- this keeps clearing
       logic in exactly one place (tcp_connection_clear()) rather
       than duplicating "reset every field but these four" here. */
    tcp_connection_clear(slot);

    slot->conn.local_ip    = local_ip;
    slot->conn.remote_ip   = remote_ip;
    slot->conn.local_port  = local_port;
    slot->conn.remote_port = remote_port;
    slot->in_use            = 1;

    tcp_connection_debug("tcp_connection: reset to CLOSED");
}

tcp_connection_t *tcp_connection_find(uint32_t local_ip, uint32_t remote_ip,
                                       uint16_t local_port, uint16_t remote_port)
{
    for(uint32_t i = 0; i < TCP_CONNECTION_TABLE_SIZE; i++)
    {
        if(!table[i].in_use)
            continue;

        if(table[i].conn.local_ip    == local_ip    &&
           table[i].conn.remote_ip   == remote_ip   &&
           table[i].conn.local_port  == local_port  &&
           table[i].conn.remote_port == remote_port)
        {
            stats.lookup_hits++;
            tcp_connection_debug("tcp_connection: lookup hit");
            return &table[i].conn;
        }
    }

    stats.lookup_misses++;
    tcp_connection_debug("tcp_connection: lookup miss");
    return 0;
}

tcp_connection_t *tcp_connection_get(uint32_t index)
{
    if(index >= TCP_CONNECTION_TABLE_SIZE)
        return 0;

    return &table[index].conn;
}

uint32_t tcp_connection_count(void)
{
    return stats.active_connections;
}

void tcp_connection_foreach(void (*callback)(tcp_connection_t *conn, void *user_data),
                             void *user_data)
{
    if(callback == 0)
        return;

    for(uint32_t i = 0; i < TCP_CONNECTION_TABLE_SIZE; i++)
    {
        if(table[i].in_use)
            callback(&table[i].conn, user_data);
    }
}

tcp_connection_stats_t tcp_connection_get_stats(void)
{
    return stats;
}