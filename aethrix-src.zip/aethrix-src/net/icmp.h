/* ================================================================
   AETHRIX OS - icmp.h
   Internet Control Message Protocol: public interface
   ================================================================ */

#ifndef AETHRIX_ICMP_H
#define AETHRIX_ICMP_H

#include <stdint.h>

/* ── Wire format ───────────────────────────────────────────────────
   Fixed 8-byte ICMP header (RFC 792) used by Echo Request/Reply.
   Packed so this struct's layout matches the on-wire layout exactly;
   icmp.c casts a received buffer directly onto this struct.
   Identifier/sequence are only meaningful for Echo Request/Reply --
   other ICMP types reuse these 4 bytes differently, but this build
   only implements Echo, so a single struct is sufficient. */
struct icmp_header {
    uint8_t  type;
    uint8_t  code;
    uint16_t checksum;
    uint16_t identifier;
    uint16_t sequence;
} __attribute__((packed));

#define ICMP_HDR_LEN            8

/* ── Types / codes ─────────────────────────────────────────────── */
#define ICMP_TYPE_ECHO_REPLY    0
#define ICMP_TYPE_ECHO_REQUEST  8
#define ICMP_CODE_ECHO          0   /* the only valid code for both  */

/* ── Statistics ────────────────────────────────────────────────────
   Snapshot returned by icmp_get_stats(). Returned by value so
   callers can't mutate the live counters in icmp.c. */
typedef struct {
    uint32_t echo_requests_received;
    uint32_t echo_replies_received;
    uint32_t echo_replies_sent;
    uint32_t invalid_packets;
    uint32_t checksum_failures;
    uint32_t unknown_types;
} icmp_stats_t;

/* ── Public interface ──────────────────────────────────────────────

   icmp_receive()
     Entry point called by the IPv4 layer for every datagram with
     protocol ICMP. src_ip is the sender's IPv4 address (network
     byte order), already validated by IPv4 -- icmp.c does not parse
     IP headers itself. buffer must contain at least len valid
     bytes; icmp_receive() never reads past that.

   icmp_send_echo_request()
     Builds and sends an Echo Request to dst_ip with the given
     identifier/sequence and payload. Useful for a ping command.
     Returns 1 if handed off to IPv4 successfully, 0 otherwise.

   icmp_get_stats()
     Returns a snapshot of the internal counters, for diagnostics or
     shell commands. */

void         icmp_receive(uint32_t src_ip, uint8_t *buffer, uint32_t len);
int          icmp_send_echo_request(uint32_t dst_ip, uint16_t identifier,
                                     uint16_t sequence,
                                     const uint8_t *payload, uint32_t payload_len);
icmp_stats_t icmp_get_stats(void);

#endif /* AETHRIX_ICMP_H */