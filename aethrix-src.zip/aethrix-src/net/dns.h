/* ================================================================
   AETHRIX OS - dns.h
   DNS client: public interface
   ================================================================ */

#ifndef AETHRIX_DNS_H
#define AETHRIX_DNS_H

#include <stdint.h>

/* ── Result of a lookup ───────────────────────────────────────── */
typedef enum {
    DNS_RESULT_PENDING = 0,   /* query in flight, no answer yet       */
    DNS_RESULT_OK,             /* resolved successfully                */
    DNS_RESULT_NOT_FOUND,      /* server replied but no A record       */
    DNS_RESULT_TIMEOUT,        /* no response after max retries        */
    DNS_RESULT_ERROR           /* malformed query/response, bad input  */
} dns_result_t;

/* ── Statistics ────────────────────────────────────────────────── */
typedef struct {
    uint32_t queries_sent;
    uint32_t responses_received;
    uint32_t cache_hits;
    uint32_t cache_misses;
    uint32_t invalid_packets;
    uint32_t timeouts;
    uint32_t retransmissions;
} dns_stats_t;

/* ── Public interface ──────────────────────────────────────────────

   dns_init()
     Sets the resolver's upstream DNS server. Call once (typically
     after DHCP hands back a DNS server address) before resolving
     anything.

   dns_resolve()
     Starts resolving `hostname` (a NUL-terminated string). If a
     valid cache entry already exists, resolves immediately and
     returns DNS_RESULT_OK with *out_ip filled in. Otherwise sends a
     query and returns DNS_RESULT_PENDING -- the caller must poll
     dns_poll() and re-check via dns_query_result() or wait for the
     resolution to complete before the IP is available. Only one
     resolution is tracked at a time in this client; starting a new
     one before the previous completes replaces it.

   dns_receive()
     Entry point called by the UDP layer for packets addressed to
     the DNS client port (the ephemeral source port used for the
     outstanding query). buffer must contain at least len valid
     bytes, and dns_receive() never reads past that.

   dns_poll()
     Drives timeouts and retransmissions, same pattern as this
     project's DHCP client -- no timer/sleep primitive lives in this
     file, so the caller must invoke this periodically with elapsed
     milliseconds since the previous call.

   dns_query_result()
     Current status of the most recent dns_resolve() call. If the
     result is DNS_RESULT_OK, *out_ip is filled with the resolved
     address.

   dns_get_stats()
     Returns a snapshot of the internal counters. */

void         dns_init(uint32_t server_ip);
dns_result_t dns_resolve(const char *hostname, uint32_t *out_ip);
void         dns_receive(uint32_t src_ip, uint16_t src_port,
                          uint8_t *buffer, uint32_t len);
void         dns_poll(uint32_t elapsed_ms);
dns_result_t dns_query_result(uint32_t *out_ip);
dns_stats_t  dns_get_stats(void);

#endif /* AETHRIX_DNS_H */