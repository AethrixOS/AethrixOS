/* ================================================================
   AETHRIX OS - tcp_connection.h
   TCP Phase 3: connection table — allocation, lookup, deletion.

   This module owns the set of active TCP connections and nothing
   else: no packet processing, no state transitions, no sequence
   validation. It exists so a later phase's state-machine code has
   somewhere to store and find per-connection state.
   ================================================================ */

#ifndef AETHRIX_TCP_CONNECTION_H
#define AETHRIX_TCP_CONNECTION_H

#include <stdint.h>
#include "tcp.h"

/**
 * TCP_CONNECTION_TABLE_SIZE
 *
 * Fixed capacity of the connection table. No dynamic allocation is
 * used anywhere in this module -- the table is a plain static
 * array, sized generously enough for a hobby OS's expected
 * concurrent connection count without wasting meaningful memory.
 * Raise this if a later phase's use case needs more.
 */
#define TCP_CONNECTION_TABLE_SIZE   32

/**
 * struct tcp_connection_stats
 *
 * Counters describing the connection table's own behavior --
 * allocation/lookup outcomes -- as distinct from tcp_stats_t in
 * tcp.h, which tracks packet-level and protocol-level counters.
 * Returned by value so callers can't mutate the live counters.
 */
typedef struct {
    uint32_t active_connections;     /* entries currently in use          */
    uint32_t allocated_connections;  /* total successful allocations ever */
    uint32_t freed_connections;      /* total frees ever                  */
    uint32_t allocation_failures;    /* alloc attempts when table was full*/
    uint32_t lookup_hits;            /* find() calls that matched an entry*/
    uint32_t lookup_misses;          /* find() calls that matched nothing */
} tcp_connection_stats_t;

/**
 * tcp_connection_init()
 *
 * Clears the connection table to all-unused and resets the
 * connection-table statistics to zero. Must be called once during
 * network stack bring-up, before any other tcp_connection_*()
 * function -- calling any other function first operates on
 * undefined table contents.
 */
void tcp_connection_init(void);

/**
 * tcp_connection_alloc()
 *
 * Allocates a free entry from the table and initializes it to a
 * clean CLOSED-state connection identified by the given 4-tuple
 * (local_ip/local_port are this host's side, remote_ip/remote_port
 * are the peer's side; both in the byte orders documented on
 * tcp_connection_t in tcp.h). Does not itself decide whether this
 * 4-tuple should be allowed to exist (e.g. duplicate-tuple
 * rejection, port availability) -- callers building the state
 * machine are expected to call tcp_connection_find() first if that
 * matters for their use case.
 *
 * Returns a pointer to the newly-allocated connection on success.
 * Returns NULL if the table is full, having already incremented
 * allocation_failures.
 *
 * The returned pointer is valid until the corresponding
 * tcp_connection_free() call; it must never be retained beyond
 * that, and never freed with anything other than
 * tcp_connection_free().
 */
tcp_connection_t *tcp_connection_alloc(uint32_t local_ip, uint32_t remote_ip,
                                        uint16_t local_port, uint16_t remote_port);

/**
 * tcp_connection_free()
 *
 * Releases conn back to the table. Every field is explicitly
 * cleared (not just an in-use flag flipped) so a subsequent
 * tcp_connection_alloc() reusing this slot never observes stale
 * sequence numbers, timers, or statistics from a previous
 * connection.
 *
 * Safe to call with conn == NULL (no-op) or with a pointer that
 * does not belong to this table's entries -- both are treated as a
 * no-op rather than undefined behavior, since a later phase's error
 * paths may call this defensively without being certain conn is
 * live.
 */
void tcp_connection_free(tcp_connection_t *conn);

/**
 * tcp_connection_reset()
 *
 * Returns conn to a clean CLOSED state without removing it from the
 * table -- unlike tcp_connection_free(), the entry remains
 * allocated and keeps its 4-tuple identity, but every sequence
 * number, window, timer, flag, and per-connection statistic is
 * cleared. Intended for a later phase's abort/RST handling, where a
 * connection needs to return to CLOSED without the caller having to
 * separately free and re-allocate it.
 *
 * Safe to call with conn == NULL (no-op).
 */
void tcp_connection_reset(tcp_connection_t *conn);

/**
 * tcp_connection_find()
 *
 * Looks up the connection matching the exact 4-tuple
 * (local_ip, remote_ip, local_port, remote_port). This module does
 * not implement TCP's wildcard-matching rules for LISTEN sockets
 * (where remote_ip/remote_port may be unbound) -- that's connection-
 * management policy tied to the state machine, not the table's
 * concern. A later phase can implement wildcard lookup on top of
 * this exact-match primitive, or extend this function, as its own
 * design needs.
 *
 * Returns a pointer to the matching connection, or NULL if none of
 * the in-use entries match. Updates lookup_hits/lookup_misses
 * accordingly.
 */
tcp_connection_t *tcp_connection_find(uint32_t local_ip, uint32_t remote_ip,
                                       uint16_t local_port, uint16_t remote_port);

/**
 * tcp_connection_get()
 *
 * Returns a pointer to table slot `index` (0-based), regardless of
 * whether that slot is currently in use, or NULL if index is out of
 * range. Intended for callers that need direct positional access
 * (e.g. a shell command listing all table slots including free
 * ones) rather than tcp_connection_foreach()'s in-use-only
 * iteration.
 */
tcp_connection_t *tcp_connection_get(uint32_t index);

/**
 * tcp_connection_count()
 *
 * Returns the number of currently in-use entries. Equivalent to
 * reading active_connections from tcp_connection_get_stats(),
 * provided as a direct call for convenience.
 */
uint32_t tcp_connection_count(void);

/**
 * tcp_connection_foreach()
 *
 * Calls callback(conn, user_data) once for every currently in-use
 * connection in the table, in table order. Iteration order is not
 * meaningful (it's not creation order or any other externally
 * useful ordering) -- callers needing a specific order must sort
 * externally.
 *
 * callback must not call tcp_connection_alloc() or
 * tcp_connection_free() on any entry other than the one it was
 * passed, since this function does not defend against the table
 * being mutated out from under an in-progress iteration.
 */
void tcp_connection_foreach(void (*callback)(tcp_connection_t *conn, void *user_data),
                             void *user_data);

/**
 * tcp_connection_get_stats()
 *
 * Returns a snapshot of the connection table's own statistics, for
 * diagnostics or shell commands.
 */
tcp_connection_stats_t tcp_connection_get_stats(void);

#endif /* AETHRIX_TCP_CONNECTION_H */