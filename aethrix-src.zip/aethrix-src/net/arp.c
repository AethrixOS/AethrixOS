/* ================================================================
   AETHRIX OS - arp.c
   Address Resolution Protocol: parsing, cache, request/reply
   ================================================================ */

#include "arp.h"
#include "ethernet.h"
#include "endian.h"

/* ── Assumptions about surrounding headers ────────────────────────
   struct arp_header, ARP_HTYPE_ETH, ARP_PTYPE_IPV4, ARP_OP_REQUEST,
   and ARP_OP_REPLY are now declared in arp.h. This file additionally
   assumes the following are declared in ethernet.h -- reconcile
   names against your actual header before building:

     extern uint8_t local_mac[6];
     extern uint32_t local_ip;                 (network byte order)
     int eth_send(const uint8_t *dst_mac, uint16_t ethertype,
                  const uint8_t *payload, uint32_t payload_len);
     #define ETH_TYPE_ARP   0x0806

   If your actual field/function names differ, only the accessors
   below need to change -- the logic does not depend on layout
   beyond this. */

extern uint8_t  local_mac[6];
extern uint32_t local_ip;

#define ARP_HDR_LEN        28
#define ARP_CACHE_SIZE     16
#define ARP_BROADCAST_MAC  ((const uint8_t[6]){0xFF,0xFF,0xFF,0xFF,0xFF,0xFF})
#define ARP_ZERO_MAC       ((const uint8_t[6]){0x00,0x00,0x00,0x00,0x00,0x00})

/* ── Statistics ────────────────────────────────────────────────────
   arp_stats_t is declared in arp.h; only the live instance lives
   here. */
static arp_stats_t arp_stats = {0, 0, 0, 0, 0, 0, 0};

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   ARP_DEBUG_ENABLED locally during bring-up. Not wired to a specific
   logging call since this file doesn't own logging policy. */
#define ARP_DEBUG_ENABLED 0
static inline void arp_debug(const char *msg)
{
#if ARP_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* ── ARP cache ─────────────────────────────────────────────────────
   Small fixed-size table. Replacement policy is "oldest entry" by a
   simple monotonically increasing counter -- enough for a hobby OS
   without needing a real LRU structure. */
typedef struct {
    uint32_t ip;        /* network byte order                        */
    uint8_t  mac[6];
    int      valid;
    uint32_t age;        /* higher = more recently updated            */
} arp_cache_entry_t;

static arp_cache_entry_t arp_cache[ARP_CACHE_SIZE];
static uint32_t           arp_cache_clock = 0;

static void arp_cache_init_once(void)
{
    static int initialized = 0;
    if(initialized)
        return;

    for(int i = 0; i < ARP_CACHE_SIZE; i++)
    {
        arp_cache[i].ip    = 0;
        arp_cache[i].valid = 0;
        arp_cache[i].age   = 0;
        for(int j = 0; j < 6; j++)
            arp_cache[i].mac[j] = 0;
    }

    initialized = 1;
}

/* Find an existing entry for ip, or return 0 if none. */
static arp_cache_entry_t *arp_cache_find(uint32_t ip)
{
    for(int i = 0; i < ARP_CACHE_SIZE; i++)
    {
        if(arp_cache[i].valid && arp_cache[i].ip == ip)
            return &arp_cache[i];
    }
    return 0;
}

/* Pick a slot to write into: prefer an invalid (empty) slot, and
   fall back to the least-recently-updated valid slot so the cache
   degrades gracefully once full rather than refusing new entries. */
static arp_cache_entry_t *arp_cache_slot_for_replacement(void)
{
    for(int i = 0; i < ARP_CACHE_SIZE; i++)
    {
        if(!arp_cache[i].valid)
            return &arp_cache[i];
    }

    arp_cache_entry_t *oldest = &arp_cache[0];
    for(int i = 1; i < ARP_CACHE_SIZE; i++)
    {
        if(arp_cache[i].age < oldest->age)
            oldest = &arp_cache[i];
    }
    return oldest;
}

/* Insert or refresh the cache entry for (ip, mac). Always wins over
   a stale entry for the same IP -- a fresh ARP reply/request is the
   most current information we have about that host. */
static void arp_cache_update(uint32_t ip, const uint8_t *mac)
{
    arp_cache_init_once();

    arp_cache_entry_t *e = arp_cache_find(ip);
    if(!e)
        e = arp_cache_slot_for_replacement();

    e->ip    = ip;
    e->valid = 1;
    e->age   = ++arp_cache_clock;
    for(int i = 0; i < 6; i++)
        e->mac[i] = mac[i];

    arp_debug("arp: cache updated");
}

/* Public lookup: returns 1 and fills out_mac if a valid entry
   exists, 0 otherwise. Kept simple and synchronous -- callers
   needing "resolve or send request" behavior compose that
   themselves using arp_lookup() + arp_send_request(). */
int arp_lookup(uint32_t ip, uint8_t *out_mac)
{
    arp_cache_init_once();

    arp_cache_entry_t *e = arp_cache_find(ip);
    if(!e)
    {
        arp_stats.cache_misses++;
        arp_debug("arp: cache miss");
        return 0;
    }

    arp_stats.cache_hits++;
    arp_debug("arp: cache hit");
    for(int i = 0; i < 6; i++)
        out_mac[i] = e->mac[i];
    return 1;
}

/* ── Small helpers ─────────────────────────────────────────────── */

static int mac_equal(const uint8_t *a, const uint8_t *b)
{
    for(int i = 0; i < 6; i++)
        if(a[i] != b[i])
            return 0;
    return 1;
}

static int mac_is_zero(const uint8_t *mac)
{
    for(int i = 0; i < 6; i++)
        if(mac[i] != 0x00)
            return 0;
    return 1;
}

/* ── Packet validation ─────────────────────────────────────────────
   Every field this function reads lies within the first ARP_HDR_LEN
   bytes, so the length check below is what makes every later read
   safe -- nothing here reads past buffer[len-1]. */
static int arp_packet_is_valid(const uint8_t *buffer, uint32_t len,
                                const struct arp_header *pkt)
{
    if(len < ARP_HDR_LEN)
    {
        arp_debug("arp: packet shorter than header");
        return 0;
    }

    if(ntohs(pkt->htype) != ARP_HTYPE_ETH)
    {
        arp_debug("arp: unsupported hardware type");
        return 0;
    }

    if(ntohs(pkt->ptype) != ARP_PTYPE_IPV4)
    {
        arp_debug("arp: unsupported protocol type");
        return 0;
    }

    if(pkt->hlen != 6)
    {
        arp_debug("arp: unexpected hardware address length");
        return 0;
    }

    if(pkt->plen != 4)
    {
        arp_debug("arp: unexpected protocol address length");
        return 0;
    }

    uint16_t oper = ntohs(pkt->oper);
    if(oper != ARP_OP_REQUEST && oper != ARP_OP_REPLY)
    {
        arp_debug("arp: unsupported opcode");
        return 0;
    }

    /* A sender hardware address of all zeros isn't a real MAC and
       almost always means the packet is garbage rather than a
       legitimate request/reply -- don't let it into the cache. */
    if(mac_is_zero(pkt->sha))
    {
        arp_debug("arp: zero sender hardware address");
        return 0;
    }

    (void)buffer; /* validated via pkt, kept for signature symmetry */
    return 1;
}

/* ── Sending ─────────────────────────────────────────────────────
   Builds an ARP header and hands it to the Ethernet layer. Neither
   function below touches a NIC or driver directly -- eth_send() owns
   that boundary. */

static void arp_build_header(struct arp_header *pkt, uint16_t oper,
                              const uint8_t *tha, uint32_t tpa)
{
    pkt->htype = htons(ARP_HTYPE_ETH);
    pkt->ptype = htons(ARP_PTYPE_IPV4);
    pkt->hlen  = 6;
    pkt->plen  = 4;
    pkt->oper  = htons(oper);

    for(int i = 0; i < 6; i++)
        pkt->sha[i] = local_mac[i];
    pkt->spa = local_ip;

    for(int i = 0; i < 6; i++)
        pkt->tha[i] = tha[i];
    pkt->tpa = tpa;
}

/* Send an ARP Reply to whoever asked for our address. */
static void arp_send_reply(const uint8_t *dst_mac, uint32_t dst_ip)
{
    struct arp_header pkt;
    arp_build_header(&pkt, ARP_OP_REPLY, dst_mac, dst_ip);

    eth_send(dst_mac, ETH_TYPE_ARP, (const uint8_t*)&pkt, sizeof(pkt));

    arp_stats.replies_sent++;
    arp_debug("arp: reply sent");
}

/* Broadcast an ARP Request for target_ip. Target hardware address is
   unknown by definition, so it's zero-filled per the ARP spec. */
void arp_send_request(uint32_t target_ip)
{
    struct arp_header pkt;
    arp_build_header(&pkt, ARP_OP_REQUEST, ARP_ZERO_MAC, target_ip);

    eth_send(ARP_BROADCAST_MAC, ETH_TYPE_ARP, (const uint8_t*)&pkt, sizeof(pkt));

    arp_stats.requests_sent++;
    arp_debug("arp: request sent");
}

/* ── Request / reply handling ─────────────────────────────────── */

static void arp_handle_request(const struct arp_header *pkt)
{
    arp_stats.requests_received++;

    /* Learn the sender's mapping regardless of who the request was
       for -- this is standard ARP behavior and saves us a future
       request to the same host. */
    arp_cache_update(pkt->spa, pkt->sha);

    if(pkt->tpa != local_ip)
    {
        arp_debug("arp: request not for us, ignored");
        return;
    }

    arp_send_reply(pkt->sha, pkt->spa);
}

static void arp_handle_reply(const struct arp_header *pkt)
{
    arp_stats.replies_received++;
    arp_cache_update(pkt->spa, pkt->sha);
}

/* ── Entry point ───────────────────────────────────────────────────
   Called by the Ethernet layer for every frame with EtherType ARP.
   This function owns nothing below "parse ARP, touch the cache,
   dispatch request/reply" -- no Ethernet or NIC logic belongs here. */
void arp_receive(uint8_t *buffer, uint32_t len)
{
    if(buffer == 0)
    {
        arp_stats.malformed++;
        arp_debug("arp: null buffer");
        return;
    }

    if(len < ARP_HDR_LEN)
    {
        arp_stats.malformed++;
        arp_debug("arp: packet too short");
        return;
    }

    struct arp_header *pkt = (struct arp_header*)buffer;

    if(!arp_packet_is_valid(buffer, len, pkt))
    {
        arp_stats.malformed++;
        return;
    }

    uint16_t oper = ntohs(pkt->oper);
    if(oper == ARP_OP_REQUEST)
        arp_handle_request(pkt);
    else /* ARP_OP_REPLY, already validated above */
        arp_handle_reply(pkt);
}

/* ── Stats accessor ────────────────────────────────────────────── */
arp_stats_t arp_get_stats(void)
{
    return arp_stats;
}