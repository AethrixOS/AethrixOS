/* ================================================================
   AETHRIX OS - ethernet.c
   Ethernet frame handler with broadcast/mac filtering
   ================================================================ */

#include "ethernet.h"
#include "arp.h"
#include "ipv4.h"
#include "endian.h"

extern uint8_t local_mac[6];

/* ── Frame size limits ────────────────────────────────────────────
   ETH_HDR_LEN is expected to be defined in ethernet.h (typically 14:
   6 dest + 6 src + 2 ethertype). ETH_MAX_FRAME bounds the payload
   we're willing to hand to upper layers, guarding against a
   driver/ring bug reporting a bogus oversized length. 1500 is the
   standard Ethernet MTU; adjust here if jumbo frames are ever
   supported by a NIC driver. This file does not assume anything
   about NIC internals — it only bounds what it will accept. */
#ifndef ETH_MAX_FRAME
#define ETH_MAX_FRAME (ETH_HDR_LEN + 1500)
#endif

/* ── Statistics ──────────────────────────────────────────────────
   Lightweight counters for observability. If ethernet.h / another
   subsystem already defines a stats struct for this layer, wire
   these into it instead; kept as static local counters here so this
   file has no dependency on anything outside its declared scope. */
typedef struct {
    uint32_t rx_frames;      /* frames accepted and dispatched      */
    uint32_t dropped_frames; /* frames rejected by MAC filter        */
    uint32_t malformed;      /* frames rejected as structurally bad  */
    uint32_t unknown_proto;  /* frames with an unhandled EtherType   */
} eth_stats_t;

static eth_stats_t eth_stats = {0, 0, 0, 0};

/* Debug hook: flip to 1 locally to trace drops during bring-up.
   Left as a no-op by default so this file stays quiet. Intentionally
   not wired to a real printf/log call here, since this file doesn't
   own logging policy -- replace eth_debug() with your kernel's
   logging primitive if you want output. */
#define ETH_DEBUG_ENABLED 0
static inline void eth_debug(const char *msg)
{
#if ETH_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* ── Broadcast helper ─────────────────────────────────────────── */
static int is_broadcast(const uint8_t *mac)
{
    for(int i = 0; i < 6; i++)
        if(mac[i] != 0xFF)
            return 0;

    return 1;
}

/* ── All-zero MAC helper ──────────────────────────────────────────
   A source or destination MAC of all zeros is not a valid unicast
   address on the wire and typically indicates a malformed or
   uninitialized frame. Used for source-address sanity checking. */
static int is_zero_mac(const uint8_t *mac)
{
    for(int i = 0; i < 6; i++)
        if(mac[i] != 0x00)
            return 0;

    return 1;
}

/* ── Compare MAC ──────────────────────────────────────────────── */
static int mac_equal(const uint8_t *a, const uint8_t *b)
{
    for(int i = 0; i < 6; i++)
        if(a[i] != b[i])
            return 0;

    return 1;
}

/* ── Receive ──────────────────────────────────────────────────────
   Validates and dispatches a single Ethernet frame handed up from
   the active NIC driver. This function only parses the Ethernet
   header and routes the payload -- it must never contain ARP, IPv4,
   or any hardware/register-level logic.

   buffer : raw frame as delivered by the NIC driver
   len    : number of valid bytes in buffer

   Every exit path is bounds-checked before buffer is touched beyond
   len, and no branch reads past buffer[len-1]. */
void eth_receive(uint8_t *buffer, uint32_t len)
{
    if(buffer == 0)
    {
        eth_debug("eth_receive: null buffer");
        return;
    }

    /* Reject anything that can't even hold a full Ethernet header.
       This is the primary guard against reading past the buffer:
       every later field access (h_dest, h_src, h_proto) is within
       the first ETH_HDR_LEN bytes, so once this check passes those
       reads are known-safe. */
    if(len < ETH_HDR_LEN)
    {
        eth_stats.malformed++;
        eth_debug("eth_receive: frame shorter than header");
        return;
    }

    /* Reject implausibly large frames. A NIC driver reporting a
       length beyond what Ethernet actually allows suggests a driver-
       side bug (e.g. ring desync) rather than a real oversized frame;
       drop it here rather than letting it flow to upper layers. */
    if(len > ETH_MAX_FRAME)
    {
        eth_stats.malformed++;
        eth_debug("eth_receive: frame exceeds max size");
        return;
    }

    struct eth_header *eth = (struct eth_header*)buffer;

    /* Reject a source address of all zeros. A real NIC never sources
       a frame from 00:00:00:00:00:00; seeing one here almost always
       means the frame is garbage (uninitialized buffer, driver bug)
       rather than a legitimate packet. */
    if(is_zero_mac(eth->h_source))
    {
        eth_stats.malformed++;
        eth_debug("eth_receive: zero source MAC");
        return;
    }

    /* Filter: accept broadcast or our MAC only. Anything else is not
       a malformed frame -- it's simply not addressed to us -- so it
       is counted separately from malformed/unknown-protocol drops. */
    if(!is_broadcast(eth->h_dest) &&
       !mac_equal(eth->h_dest, local_mac))
    {
        eth_stats.dropped_frames++;
        eth_debug("eth_receive: destination MAC mismatch");
        return;
    }

    uint16_t proto = ntohs(eth->h_proto);

    uint8_t  *payload     = buffer + ETH_HDR_LEN;
    uint32_t  payload_len = len - ETH_HDR_LEN;

    switch(proto)
    {
        case ETH_TYPE_ARP:
            eth_stats.rx_frames++;
            arp_receive(payload, payload_len);
            break;

        case ETH_TYPE_IPV4:
            eth_stats.rx_frames++;
            ipv4_receive(payload, payload_len);
            break;

        default:
            /* Unsupported EtherType: not an error, just not handled
               by any registered upper layer. Counted, not logged
               loudly, and never treated as malformed. */
            eth_stats.unknown_proto++;
            eth_debug("eth_receive: unhandled EtherType");
            break;
    }
}

/* ── Stats accessor ────────────────────────────────────────────────
   Read-only snapshot for diagnostics/shell commands. Returned by
   value so callers can't mutate internal counters. */
eth_stats_t eth_get_stats(void)
{
    return eth_stats;
}