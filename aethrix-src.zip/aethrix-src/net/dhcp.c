/* ================================================================
   AETHRIX OS - dhcp.c
   DHCP client: state machine, packet parsing, construction
   ================================================================ */

#include "dhcp.h"
#include "udp.h"
#include "endian.h"

/* ── Assumptions about surrounding headers ────────────────────────
   This file assumes the following, matching how udp.h was already
   written in this project. Reconcile against your actual headers
   before building:

     int udp_send(uint32_t dst_ip, uint16_t src_port, uint16_t dst_port,
                  const uint8_t *payload, uint32_t payload_len);
     #define UDP_PORT_DHCP_CLIENT 68

   DHCP also needs a way to install the resolved lease into the OS's
   live network configuration and to know the interface's own MAC
   address. Neither is declared anywhere visible to this file, so
   both are extern-declared below with names chosen to match this
   project's existing conventions (local_mac from ethernet.h). If a
   real "apply this config" entry point already exists elsewhere,
   wire dhcp_apply_lease() below to call it instead of just updating
   local state. */

extern uint8_t local_mac[6];

#define DHCP_SERVER_PORT     67
#define DHCP_CLIENT_PORT     68

#define DHCP_MAGIC_COOKIE    0x63825363u

#define DHCP_OP_BOOTREQUEST  1
#define DHCP_OP_BOOTREPLY    2

#define DHCP_HTYPE_ETH        1
#define DHCP_HLEN_ETH         6

#define DHCP_OPT_SUBNET_MASK  1
#define DHCP_OPT_ROUTER       3
#define DHCP_OPT_DNS_SERVER   6
#define DHCP_OPT_LEASE_TIME   51
#define DHCP_OPT_MSG_TYPE     53
#define DHCP_OPT_SERVER_ID    54
#define DHCP_OPT_END          255
#define DHCP_OPT_PAD          0

#define DHCP_MSG_DISCOVER    1
#define DHCP_MSG_OFFER       2
#define DHCP_MSG_REQUEST     3
#define DHCP_MSG_DECLINE     4
#define DHCP_MSG_ACK         5
#define DHCP_MSG_NAK         6
#define DHCP_MSG_RELEASE     7
#define DHCP_MSG_INFORM      8

#define DHCP_FIXED_LEN        236  /* op..file, before the magic cookie */
#define DHCP_MIN_PACKET_LEN  (DHCP_FIXED_LEN + 4) /* + magic cookie      */

#define DHCP_DISCOVER_TIMEOUT_MS   4000
#define DHCP_REQUEST_TIMEOUT_MS    4000
#define DHCP_MAX_RETRIES           4

/* ── Wire format ───────────────────────────────────────────────────
   Fixed portion of a DHCP/BOOTP message (RFC 2131), options
   excluded -- options are variable-length and parsed separately.
   Packed so this struct's layout matches the on-wire layout exactly.
   sname/file are kept as raw arrays since this client neither reads
   nor sets them. */
struct dhcp_header {
    uint8_t  op;
    uint8_t  htype;
    uint8_t  hlen;
    uint8_t  hops;
    uint32_t xid;
    uint16_t secs;
    uint16_t flags;
    uint32_t ciaddr;
    uint32_t yiaddr;
    uint32_t siaddr;
    uint32_t giaddr;
    uint8_t  chaddr[16];
    uint8_t  sname[64];
    uint8_t  file[128];
} __attribute__((packed));

#define DHCP_OPTIONS_MAX     312  /* generous headroom for a Discover/
                                       Request's option list          */

/* ── Client state ──────────────────────────────────────────────── */
static dhcp_state_t state       = DHCP_STATE_INIT;
static uint32_t      xid         = 0;
static uint32_t      elapsed_since_send = 0;
static uint32_t      retry_count = 0;

static dhcp_lease_t  lease;
static int           have_lease = 0;

static uint32_t      offered_ip       = 0;
static uint32_t      offered_server_id = 0;

static dhcp_stats_t  dhcp_stats = {0, 0, 0, 0, 0, 0, 0, 0};

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   DHCP_DEBUG_ENABLED locally during bring-up. Not wired to a
   specific logging call since this file doesn't own logging policy. */
#define DHCP_DEBUG_ENABLED 0
static inline void dhcp_debug(const char *msg)
{
#if DHCP_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* Very small PRNG for transaction IDs. This does not need to be
   cryptographically strong -- RFC 2131 only asks that it be
   reasonably unlikely to collide with another client's in-flight
   transaction on the same segment. Seeded from whatever xid last
   held so successive calls don't repeat. */
static uint32_t dhcp_next_xid(void)
{
    static uint32_t seed = 0x2463FADEu;
    seed = seed * 1103515245u + 12345u;
    return seed;
}

/* ── Option writing (for outgoing packets) ────────────────────────
   Small helpers so message construction below isn't hand-rolling
   the same three-line "tag, length, bytes" pattern at every option. */
static uint8_t *dhcp_put_opt_u8(uint8_t *p, uint8_t tag, uint8_t value)
{
    *p++ = tag;
    *p++ = 1;
    *p++ = value;
    return p;
}

static uint8_t *dhcp_put_opt_bytes(uint8_t *p, uint8_t tag,
                                    const uint8_t *bytes, uint8_t len)
{
    *p++ = tag;
    *p++ = len;
    for(uint8_t i = 0; i < len; i++)
        *p++ = bytes[i];
    return p;
}

/* ── Message construction ─────────────────────────────────────────
   Builds a DHCP Discover or Request into a local buffer and sends
   it via udp_send(). Neither function touches IPv4/Ethernet/NIC
   layers directly -- udp_send() owns that boundary. */
static int dhcp_send_discover(void)
{
    uint8_t packet[DHCP_FIXED_LEN + 4 + 32];
    struct dhcp_header *hdr = (struct dhcp_header*)packet;

    for(uint32_t i = 0; i < sizeof(packet); i++)
        packet[i] = 0;

    hdr->op    = DHCP_OP_BOOTREQUEST;
    hdr->htype = DHCP_HTYPE_ETH;
    hdr->hlen  = DHCP_HLEN_ETH;
    hdr->hops  = 0;
    hdr->xid   = htonl(xid);
    hdr->secs  = 0;
    hdr->flags = htons(0x8000); /* broadcast flag: we have no IP yet */

    for(int i = 0; i < 6; i++)
        hdr->chaddr[i] = local_mac[i];

    uint8_t *p = packet + DHCP_FIXED_LEN;
    *(uint32_t*)p = htonl(DHCP_MAGIC_COOKIE);
    p += 4;

    p = dhcp_put_opt_u8(p, DHCP_OPT_MSG_TYPE, DHCP_MSG_DISCOVER);
    *p++ = DHCP_OPT_END;

    uint32_t len = (uint32_t)(p - packet);

    int sent = udp_send(0xFFFFFFFFu, DHCP_CLIENT_PORT, DHCP_SERVER_PORT,
                         packet, len);
    if(sent)
    {
        dhcp_stats.discovers_sent++;
        dhcp_debug("dhcp: discover sent");
    }
    return sent;
}

static int dhcp_send_request(void)
{
    uint8_t packet[DHCP_FIXED_LEN + 4 + 32];
    struct dhcp_header *hdr = (struct dhcp_header*)packet;

    for(uint32_t i = 0; i < sizeof(packet); i++)
        packet[i] = 0;

    hdr->op    = DHCP_OP_BOOTREQUEST;
    hdr->htype = DHCP_HTYPE_ETH;
    hdr->hlen  = DHCP_HLEN_ETH;
    hdr->hops  = 0;
    hdr->xid   = htonl(xid);
    hdr->secs  = 0;
    hdr->flags = htons(0x8000);

    for(int i = 0; i < 6; i++)
        hdr->chaddr[i] = local_mac[i];

    uint8_t *p = packet + DHCP_FIXED_LEN;
    *(uint32_t*)p = htonl(DHCP_MAGIC_COOKIE);
    p += 4;

    p = dhcp_put_opt_u8(p, DHCP_OPT_MSG_TYPE, DHCP_MSG_REQUEST);

    uint32_t requested_ip_be = offered_ip;
    p = dhcp_put_opt_bytes(p, 50 /* Requested IP Address */,
                            (const uint8_t*)&requested_ip_be, 4);

    uint32_t server_id_be = offered_server_id;
    p = dhcp_put_opt_bytes(p, DHCP_OPT_SERVER_ID,
                            (const uint8_t*)&server_id_be, 4);

    *p++ = DHCP_OPT_END;

    uint32_t len = (uint32_t)(p - packet);

    int sent = udp_send(0xFFFFFFFFu, DHCP_CLIENT_PORT, DHCP_SERVER_PORT,
                         packet, len);
    if(sent)
    {
        dhcp_stats.requests_sent++;
        dhcp_debug("dhcp: request sent");
    }
    return sent;
}

/* ── Option parsing (for incoming packets) ────────────────────────
   Walks the TLV option list starting at `options`, bounded strictly
   by options_len -- every read of a tag/length/value byte is checked
   against the remaining length before it happens, so this never
   reads past the end of the received buffer regardless of what a
   malicious or corrupt server sends. Unknown options are skipped by
   their declared length rather than interpreted. */
typedef struct {
    int      have_msg_type;
    uint8_t  msg_type;
    int      have_subnet_mask;
    uint32_t subnet_mask;
    int      have_router;
    uint32_t router;
    int      have_dns;
    uint32_t dns_server;
    int      have_lease_time;
    uint32_t lease_time;
    int      have_server_id;
    uint32_t server_id;
} dhcp_parsed_options_t;

static int dhcp_parse_options(const uint8_t *options, uint32_t options_len,
                               dhcp_parsed_options_t *out)
{
    uint32_t i = 0;

    out->have_msg_type    = 0;
    out->have_subnet_mask = 0;
    out->have_router      = 0;
    out->have_dns         = 0;
    out->have_lease_time  = 0;
    out->have_server_id   = 0;

    while(i < options_len)
    {
        uint8_t tag = options[i];

        if(tag == DHCP_OPT_PAD)
        {
            i++;
            continue;
        }
        if(tag == DHCP_OPT_END)
            return 1;

        /* Every option beyond PAD/END has a length byte; bail rather
           than read past the buffer if it's missing. */
        if(i + 1 >= options_len)
        {
            dhcp_debug("dhcp: option truncated before length byte");
            return 0;
        }

        uint8_t opt_len = options[i + 1];

        if(i + 2 + opt_len > options_len)
        {
            dhcp_debug("dhcp: option length exceeds remaining buffer");
            return 0;
        }

        const uint8_t *value = &options[i + 2];

        switch(tag)
        {
            case DHCP_OPT_MSG_TYPE:
                if(opt_len == 1)
                {
                    out->msg_type      = value[0];
                    out->have_msg_type = 1;
                }
                break;

            case DHCP_OPT_SUBNET_MASK:
                if(opt_len == 4)
                {
                    out->subnet_mask      = *(const uint32_t*)value;
                    out->have_subnet_mask = 1;
                }
                break;

            case DHCP_OPT_ROUTER:
                /* RFC 2132 allows a list of routers; this client only
                   needs one default gateway, so only the first
                   4-byte entry is used even if more are present. */
                if(opt_len >= 4)
                {
                    out->router      = *(const uint32_t*)value;
                    out->have_router = 1;
                }
                break;

            case DHCP_OPT_DNS_SERVER:
                /* Same story as Router: first server only. */
                if(opt_len >= 4)
                {
                    out->dns_server = *(const uint32_t*)value;
                    out->have_dns   = 1;
                }
                break;

            case DHCP_OPT_LEASE_TIME:
                if(opt_len == 4)
                {
                    out->lease_time      = ntohl(*(const uint32_t*)value);
                    out->have_lease_time = 1;
                }
                break;

            case DHCP_OPT_SERVER_ID:
                if(opt_len == 4)
                {
                    out->server_id      = *(const uint32_t*)value;
                    out->have_server_id = 1;
                }
                break;

            default:
                /* Unknown option: skip by its declared length. This
                   is what makes "skip unknown options safely"
                   actually safe -- opt_len was already bounds-checked
                   above before we get here. */
                break;
        }

        i += 2 + opt_len;
    }

    /* Reached the end of the buffer without an End option. Not
       necessarily malicious, but per validation rules this packet's
       option list is not well-formed -- caller decides how strict
       to be. */
    dhcp_debug("dhcp: option list missing End marker");
    return 1;
}

/* ── Packet validation ─────────────────────────────────────────────
   Checks everything up through the magic cookie before any option
   parsing is attempted, and confirms the transaction ID matches the
   request this client actually sent -- without that check, this
   client would accept a reply to someone else's DHCP conversation on
   the same broadcast segment. */
static int dhcp_packet_is_valid(const uint8_t *buffer, uint32_t len,
                                 const struct dhcp_header **out_hdr)
{
    if(len < DHCP_MIN_PACKET_LEN)
    {
        dhcp_debug("dhcp: packet shorter than minimum size");
        return 0;
    }

    const struct dhcp_header *hdr = (const struct dhcp_header*)buffer;

    if(hdr->op != DHCP_OP_BOOTREPLY)
    {
        dhcp_debug("dhcp: not a BOOTREPLY");
        return 0;
    }

    if(hdr->htype != DHCP_HTYPE_ETH || hdr->hlen != DHCP_HLEN_ETH)
    {
        dhcp_debug("dhcp: unexpected hardware type/length");
        return 0;
    }

    if(ntohl(hdr->xid) != xid)
    {
        dhcp_debug("dhcp: transaction ID mismatch");
        return 0;
    }

    uint32_t cookie = ntohl(*(const uint32_t*)(buffer + DHCP_FIXED_LEN));
    if(cookie != DHCP_MAGIC_COOKIE)
    {
        dhcp_debug("dhcp: bad magic cookie");
        return 0;
    }

    *out_hdr = hdr;
    return 1;
}

/* ── Lease application ─────────────────────────────────────────────
   Installs a bound lease into this file's local state. This client
   has no visibility into a global "network config" subsystem, so if
   one exists elsewhere in the kernel, wire it in here -- this is the
   single place a real IP/gateway/DNS assignment would be pushed out
   to the rest of the OS. */
static void dhcp_apply_lease(const struct dhcp_header *hdr,
                              const dhcp_parsed_options_t *opts)
{
    lease.ip_addr     = hdr->yiaddr;
    lease.subnet_mask = opts->have_subnet_mask ? opts->subnet_mask : 0;
    lease.gateway     = opts->have_router      ? opts->router      : 0;
    lease.dns_server  = opts->have_dns         ? opts->dns_server  : 0;
    lease.lease_time  = opts->have_lease_time  ? opts->lease_time  : 0;
    lease.server_id   = opts->have_server_id   ? opts->server_id   : offered_server_id;

    have_lease = 1;
    state       = DHCP_STATE_BOUND;
    retry_count = 0;

    dhcp_debug("dhcp: lease obtained, client BOUND");
}

/* ── Receive ───────────────────────────────────────────────────────
   Called by the UDP layer for packets addressed to the DHCP client
   port. Only actually processes a message when it matches the state
   currently being waited on (Offer while DISCOVER_SENT, ACK/NAK
   while REQUEST_SENT); anything else is safely ignored rather than
   treated as an error, since stray retransmitted server replies are
   normal on a broadcast segment. */
void dhcp_receive(uint32_t src_ip, uint16_t src_port, uint8_t *buffer, uint32_t len)
{
    (void)src_port;

    if(buffer == 0)
    {
        dhcp_stats.invalid_packets++;
        dhcp_debug("dhcp: null buffer");
        return;
    }

    const struct dhcp_header *hdr = 0;
    if(!dhcp_packet_is_valid(buffer, len, &hdr))
    {
        dhcp_stats.invalid_packets++;
        return;
    }

    uint32_t options_len = len - DHCP_MIN_PACKET_LEN;
    const uint8_t *options = buffer + DHCP_MIN_PACKET_LEN;

    dhcp_parsed_options_t opts;
    if(!dhcp_parse_options(options, options_len, &opts) || !opts.have_msg_type)
    {
        dhcp_stats.invalid_packets++;
        dhcp_debug("dhcp: option parse failure or missing message type");
        return;
    }

    switch(opts.msg_type)
    {
        case DHCP_MSG_OFFER:
            if(state != DHCP_STATE_DISCOVER_SENT)
            {
                dhcp_debug("dhcp: unexpected offer, ignored");
                return;
            }

            dhcp_stats.offers_received++;
            offered_ip        = hdr->yiaddr;
            offered_server_id = opts.have_server_id ? opts.server_id : src_ip;
            state              = DHCP_STATE_OFFER_RECEIVED;
            elapsed_since_send = 0;
            retry_count        = 0;
            dhcp_debug("dhcp: offer received");

            /* Move straight to REQUEST -- this client takes the
               first valid Offer it sees rather than collecting and
               comparing multiple, which keeps the state machine
               simple and is sufficient for a hobby OS on a typical
               single-DHCP-server network. */
            if(dhcp_send_request())
                state = DHCP_STATE_REQUEST_SENT;
            break;

        case DHCP_MSG_ACK:
            if(state != DHCP_STATE_REQUEST_SENT)
            {
                dhcp_debug("dhcp: unexpected ack, ignored");
                return;
            }

            dhcp_stats.acks_received++;
            dhcp_apply_lease(hdr, &opts);
            break;

        case DHCP_MSG_NAK:
            if(state != DHCP_STATE_REQUEST_SENT)
            {
                dhcp_debug("dhcp: unexpected nak, ignored");
                return;
            }

            dhcp_stats.naks_received++;
            dhcp_debug("dhcp: nak received, restarting from INIT");

            /* Per RFC 2131, a NAK means start over -- the server
               rejected our Request, so there's nothing to salvage
               from the current transaction. */
            state              = DHCP_STATE_INIT;
            have_lease         = 0;
            retry_count        = 0;
            elapsed_since_send = 0;
            xid                = dhcp_next_xid();
            dhcp_send_discover();
            state = DHCP_STATE_DISCOVER_SENT;
            break;

        default:
            /* DHCPDECLINE/RELEASE/INFORM etc. are server-facing or
               not part of this client's supported flow -- ignored
               safely rather than treated as invalid. */
            dhcp_debug("dhcp: unsupported message type, ignored");
            break;
    }
}

/* ── Timeout / retransmission driver ──────────────────────────────
   No sleep or timer primitive lives in this file -- the caller is
   expected to invoke this periodically with elapsed time since the
   last call. Only DISCOVER_SENT and REQUEST_SENT states are timed;
   INIT and BOUND have nothing to time out. */
void dhcp_poll(uint32_t elapsed_ms)
{
    if(state != DHCP_STATE_DISCOVER_SENT && state != DHCP_STATE_REQUEST_SENT)
        return;

    elapsed_since_send += elapsed_ms;

    uint32_t timeout = (state == DHCP_STATE_DISCOVER_SENT)
                        ? DHCP_DISCOVER_TIMEOUT_MS
                        : DHCP_REQUEST_TIMEOUT_MS;

    if(elapsed_since_send < timeout)
        return;

    dhcp_stats.timeouts++;
    elapsed_since_send = 0;

    if(retry_count >= DHCP_MAX_RETRIES)
    {
        /* Exhausted retries -- go back to INIT rather than retrying
           forever. A caller polling dhcp_get_state() can decide
           whether to call dhcp_start() again later. */
        dhcp_debug("dhcp: max retries exceeded, returning to INIT");
        state       = DHCP_STATE_INIT;
        retry_count = 0;
        return;
    }

    retry_count++;
    dhcp_stats.retransmissions++;

    if(state == DHCP_STATE_DISCOVER_SENT)
    {
        dhcp_debug("dhcp: discover timeout, retrying");
        dhcp_send_discover();
    }
    else
    {
        dhcp_debug("dhcp: request timeout, retrying");
        dhcp_send_request();
    }
}

/* ── Public control / accessors ───────────────────────────────── */

void dhcp_start(void)
{
    state              = DHCP_STATE_INIT;
    have_lease         = 0;
    retry_count        = 0;
    elapsed_since_send = 0;
    xid                = dhcp_next_xid();

    if(dhcp_send_discover())
        state = DHCP_STATE_DISCOVER_SENT;
}

dhcp_state_t dhcp_get_state(void)
{
    return state;
}

int dhcp_get_lease(dhcp_lease_t *out_lease)
{
    if(!have_lease || out_lease == 0)
        return 0;

    *out_lease = lease;
    return 1;
}

dhcp_stats_t dhcp_get_stats(void)
{
    return dhcp_stats;
}