#ifndef AETHRIX_ETHERNET_H
#define AETHRIX_ETHERNET_H

#include <stdint.h>

#define ETH_ALEN        6
#define ETH_HDR_LEN     14

#define ETH_TYPE_IPV4   0x0800
#define ETH_TYPE_ARP    0x0806

#define ETH_MIN_FRAME   60
#define ETH_MAX_FRAME   1518

struct eth_header {
    uint8_t  h_dest[ETH_ALEN];
    uint8_t  h_source[ETH_ALEN];
    uint16_t h_proto;
} __attribute__((packed));

void eth_receive(uint8_t *buffer, uint32_t len);

void eth_send(
    const uint8_t *dest_mac,
    uint16_t proto,
    const uint8_t *payload,
    uint32_t len
);

#endif