/* ================================================================
   AETHRIX OS - dns.c
   DNS client: query construction, response parsing, cache
   ================================================================ */

#include "dns.h"
#include "udp.h"
#include "endian.h"

/* ── Assumptions about surrounding headers ────────────────────────
   This file assumes the following, matching how udp.h was already
   written in this project. Reconcile against your actual headers
   before building:

     int udp_send(uint32_t dst_ip, uint16_t src_port, uint16_t dst_port,
                  const uint8_t *payload, uint32_t payload_len);
     #define UDP_PORT_DNS 53

   This client also needs a source port to listen on for replies.
   UDP dispatch (in udp.c, per the file written earlier in this
   project) currently only routes port 53 to dns_receive() -- it
   does not support per-query ephemeral source ports. This client
   therefore always sends from and listens on port 53 itself, same
   as the DHCP client's fixed port 68. If ephemeral source ports are
   ever added to udp.c's dispatch table, update DNS_CLIENT_PORT
   handling here and the routing table there together. */

#define DNS_SERVER_PORT      53
#define DNS_CLIENT_PORT      53

#define DNS_MAX_PACKET       512   /* classic DNS-over-UDP ceiling (RFC
                                       1035); this client neither sends
                                       nor expects EDNS0 larger sizes */
#define DNS_HDR_LEN          12

#define DNS_TYPE_A           1
#define DNS_CLASS_IN         1

#define DNS_FLAG_QR          0x8000  /* 1 = response                  */
#define DNS_FLAG_OPCODE_MASK 0x7800
#define DNS_FLAG_RCODE_MASK  0x000F

#define DNS_MAX_NAME_LEN     255
#define DNS_MAX_LABEL_LEN    63
#define DNS_MAX_COMPRESSION_JUMPS  16  /* bounds pointer-chasing so a
                                           malicious/corrupt response
                                           can never loop forever      */

#define DNS_QUERY_TIMEOUT_MS  3000
#define DNS_MAX_RETRIES       3

#define DNS_CACHE_SIZE        16
#define DNS_MAX_HOSTNAME      128

/* ── Wire format ───────────────────────────────────────────────────
   Fixed 12-byte DNS header (RFC 1035 section 4.1.1). Packed so this
   struct's layout matches the on-wire layout exactly. Question and
   answer sections are variable-length and parsed separately. */
struct dns_header {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
} __attribute__((packed));

/* ── Cache ─────────────────────────────────────────────────────── */
typedef struct {
    char     hostname[DNS_MAX_HOSTNAME];
    uint32_t ip;            /* network byte order */
    uint32_t ttl_remaining_ms;
    int      valid;
} dns_cache_entry_t;

static dns_cache_entry_t dns_cache[DNS_CACHE_SIZE];
static uint32_t          dns_cache_clock = 0; /* for oldest-wins replacement */

/* ── Resolver state (single outstanding query at a time) ──────── */
static uint32_t     dns_server_ip = 0;
static int           server_configured = 0;

static char          pending_hostname[DNS_MAX_HOSTNAME];
static int           pending_active = 0;
static uint16_t      pending_id = 0;
static uint32_t      pending_elapsed_ms = 0;
static uint32_t      pending_retries = 0;

static dns_result_t  last_result = DNS_RESULT_ERROR;
static uint32_t      last_result_ip = 0;

static dns_stats_t   dns_stats = {0, 0, 0, 0, 0, 0, 0};

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   DNS_DEBUG_ENABLED locally during bring-up. Not wired to a specific
   logging call since this file doesn't own logging policy. */
#define DNS_DEBUG_ENABLED 0
static inline void dns_debug(const char *msg)
{
#if DNS_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

static uint16_t dns_next_id(void)
{
    static uint16_t seed = 0x51A3;
    seed = (uint16_t)(seed * 25173u + 13849u);
    return seed;
}

/* ── Small string helpers ─────────────────────────────────────────
   This file avoids assuming a libc is available (typical for a
   hobby kernel), so the handful of string operations it needs are
   implemented locally rather than pulled in via <string.h>. */
static uint32_t dns_strlen(const char *s)
{
    uint32_t n = 0;
    while(s[n] != '\0')
        n++;
    return n;
}

static int dns_streq(const char *a, const char *b)
{
    uint32_t i = 0;
    while(a[i] != '\0' && b[i] != '\0')
    {
        if(a[i] != b[i])
            return 0;
        i++;
    }
    return a[i] == '\0' && b[i] == '\0';
}

static void dns_strcpy_bounded(char *dst, const char *src, uint32_t dst_size)
{
    uint32_t i = 0;
    while(i + 1 < dst_size && src[i] != '\0')
    {
        dst[i] = src[i];
        i++;
    }
    dst[i] = '\0';
}

/* ── Cache ─────────────────────────────────────────────────────── */
static void dns_cache_init_once(void)
{
    static int initialized = 0;
    if(initialized)
        return;

    for(int i = 0; i < DNS_CACHE_SIZE; i++)
    {
        dns_cache[i].valid = 0;
        dns_cache[i].hostname[0] = '\0';
    }
    initialized = 1;
}

static dns_cache_entry_t *dns_cache_find(const char *hostname)
{
    for(int i = 0; i < DNS_CACHE_SIZE; i++)
    {
        if(dns_cache[i].valid && dns_streq(dns_cache[i].hostname, hostname))
            return &dns_cache[i];
    }
    return 0;
}

static dns_cache_entry_t *dns_cache_slot_for_replacement(void)
{
    for(int i = 0; i < DNS_CACHE_SIZE; i++)
    {
        if(!dns_cache[i].valid)
            return &dns_cache[i];
    }

    /* Full: evict the entry with the least TTL remaining rather than
       tracking a separate age counter -- a lease closest to expiry
       is the least useful one to keep. */
    dns_cache_entry_t *soonest = &dns_cache[0];
    for(int i = 1; i < DNS_CACHE_SIZE; i++)
    {
        if(dns_cache[i].ttl_remaining_ms < soonest->ttl_remaining_ms)
            soonest = &dns_cache[i];
    }
    return soonest;
}

static void dns_cache_insert(const char *hostname, uint32_t ip, uint32_t ttl_seconds)
{
    dns_cache_init_once();

    dns_cache_entry_t *e = dns_cache_find(hostname);
    if(!e)
        e = dns_cache_slot_for_replacement();

    dns_strcpy_bounded(e->hostname, hostname, DNS_MAX_HOSTNAME);
    e->ip    = ip;
    e->valid = 1;

    /* A TTL of 0 from the server technically means "don't cache,"
       but this client still stores it very briefly rather than
       special-casing zero -- it will simply expire on the very next
       dns_poll() tick. Overflow-safe: ttl_seconds is bounded well
       under UINT32_MAX/1000 for any real DNS response. */
    e->ttl_remaining_ms = ttl_seconds * 1000u;

    dns_debug("dns: cache entry inserted");
}

/* Ages every cache entry by elapsed_ms and invalidates anything
   whose TTL has run out. Called from dns_poll() so cache expiry
   doesn't need its own separate driving mechanism. */
static void dns_cache_age(uint32_t elapsed_ms)
{
    for(int i = 0; i < DNS_CACHE_SIZE; i++)
    {
        if(!dns_cache[i].valid)
            continue;

        if(dns_cache[i].ttl_remaining_ms <= elapsed_ms)
        {
            dns_cache[i].valid = 0;
            dns_debug("dns: cache entry expired");
        }
        else
        {
            dns_cache[i].ttl_remaining_ms -= elapsed_ms;
        }
    }
}

/* ── Hostname encoding (for outgoing queries) ─────────────────────
   Encodes "example.com" as length-prefixed labels: 7 example 3 com 0
   per RFC 1035 section 4.1.2. Rejects hostnames that don't fit DNS's
   own limits before writing anything, rather than truncating
   silently. Returns the number of bytes written, or 0 on failure. */
static uint32_t dns_encode_hostname(const char *hostname, uint8_t *out, uint32_t out_size)
{
    uint32_t name_len = dns_strlen(hostname);
    if(name_len == 0 || name_len > DNS_MAX_NAME_LEN)
    {
        dns_debug("dns_encode_hostname: hostname length out of range");
        return 0;
    }

    uint32_t out_i = 0;
    uint32_t label_start = 0;

    for(uint32_t i = 0; i <= name_len; i++)
    {
        if(hostname[i] == '.' || hostname[i] == '\0')
        {
            uint32_t label_len = i - label_start;

            if(label_len == 0 || label_len > DNS_MAX_LABEL_LEN)
            {
                dns_debug("dns_encode_hostname: invalid label length");
                return 0;
            }

            if(out_i + 1 + label_len >= out_size)
            {
                dns_debug("dns_encode_hostname: output buffer too small");
                return 0;
            }

            out[out_i++] = (uint8_t)label_len;
            for(uint32_t j = 0; j < label_len; j++)
                out[out_i++] = (uint8_t)hostname[label_start + j];

            label_start = i + 1;
        }
    }

    if(out_i >= out_size)
    {
        dns_debug("dns_encode_hostname: no room for terminating zero label");
        return 0;
    }
    out[out_i++] = 0; /* root label terminator */

    return out_i;
}

/* ── Query construction ───────────────────────────────────────────
   Builds a standard iterative query for an A record and sends it.
   Does not touch UDP/IPv4/Ethernet internals -- udp_send() owns
   that boundary. */
static int dns_send_query(const char *hostname, uint16_t id)
{
    uint8_t packet[DNS_MAX_PACKET];
    struct dns_header *hdr = (struct dns_header*)packet;

    hdr->id      = htons(id);
    hdr->flags   = htons(0x0100); /* standard query, recursion desired */
    hdr->qdcount = htons(1);
    hdr->ancount = 0;
    hdr->nscount = 0;
    hdr->arcount = 0;

    uint8_t *p = packet + DNS_HDR_LEN;
    uint32_t remaining = sizeof(packet) - DNS_HDR_LEN;

    uint32_t name_len = dns_encode_hostname(hostname, p, remaining);
    if(name_len == 0)
        return 0;
    p += name_len;

    if((uint32_t)(p - packet) + 4 > sizeof(packet))
    {
        dns_debug("dns_send_query: packet too small for question footer");
        return 0;
    }

    *(uint16_t*)p = htons(DNS_TYPE_A);  p += 2;
    *(uint16_t*)p = htons(DNS_CLASS_IN); p += 2;

    uint32_t total_len = (uint32_t)(p - packet);

    int sent = udp_send(dns_server_ip, DNS_CLIENT_PORT, DNS_SERVER_PORT,
                         packet, total_len);
    if(sent)
    {
        dns_stats.queries_sent++;
        dns_debug("dns: query sent");
    }
    return sent;
}

/* ── Name reading (for incoming responses) ─────────────────────────
   Reads a possibly-compressed name starting at buffer[offset] and
   writes nothing back except how many bytes of the *original*
   (non-jumped) stream it consumed -- the caller needs that to find
   the next field after the name, while the name's actual text isn't
   needed for A-record resolution and so is discarded rather than
   copied out. Bounded by DNS_MAX_COMPRESSION_JUMPS so a pointer that
   targets itself, or a chain of pointers, can never loop forever;
   every read from buffer is checked against len first. */
static int dns_skip_name(const uint8_t *buffer, uint32_t len, uint32_t offset,
                          uint32_t *out_consumed)
{
    uint32_t pos = offset;
    uint32_t consumed = 0;      /* bytes consumed in the original stream */
    int      jumped = 0;
    int      jumps = 0;

    while(1)
    {
        if(pos >= len)
        {
            dns_debug("dns_skip_name: ran off end of buffer");
            return 0;
        }

        uint8_t b = buffer[pos];

        if((b & 0xC0) == 0xC0)
        {
            /* Compression pointer: 2 bytes, low 14 bits are the
               offset to jump to. */
            if(pos + 1 >= len)
            {
                dns_debug("dns_skip_name: truncated compression pointer");
                return 0;
            }

            if(!jumped)
            {
                consumed += 2; /* the pointer itself, in the original stream */
                jumped = 1;
            }

            jumps++;
            if(jumps > DNS_MAX_COMPRESSION_JUMPS)
            {
                dns_debug("dns_skip_name: too many compression jumps");
                return 0;
            }

            uint16_t ptr = (uint16_t)(((b & 0x3F) << 8) | buffer[pos + 1]);
            pos = ptr;
            continue;
        }

        if(b == 0)
        {
            if(!jumped)
                consumed += 1;
            break;
        }

        if(b > DNS_MAX_LABEL_LEN)
        {
            dns_debug("dns_skip_name: label exceeds max length");
            return 0;
        }

        uint32_t label_total = 1u + b;
        if(pos + label_total > len)
        {
            dns_debug("dns_skip_name: label runs past buffer");
            return 0;
        }

        if(!jumped)
            consumed += label_total;

        pos += label_total;
    }

    *out_consumed = consumed;
    return 1;
}

/* ── Response validation + parsing ────────────────────────────────
   Every read past the fixed 12-byte header goes through
   dns_skip_name() or an explicit bounds check first, so nothing here
   reads past buffer[len-1] regardless of how the response is
   malformed. */
static int dns_process_response(const uint8_t *buffer, uint32_t len,
                                 uint32_t *out_ip, uint32_t *out_ttl)
{
    if(len < DNS_HDR_LEN)
    {
        dns_debug("dns: response shorter than header");
        return 0;
    }

    const struct dns_header *hdr = (const struct dns_header*)buffer;

    if(ntohs(hdr->id) != pending_id)
    {
        dns_debug("dns: transaction ID mismatch");
        return 0;
    }

    uint16_t flags = ntohs(hdr->flags);
    if(!(flags & DNS_FLAG_QR))
    {
        dns_debug("dns: not a response (QR bit clear)");
        return 0;
    }

    uint16_t rcode = flags & DNS_FLAG_RCODE_MASK;
    if(rcode != 0)
    {
        dns_debug("dns: server returned a nonzero rcode");
        return 0;
    }

    uint16_t qdcount = ntohs(hdr->qdcount);
    uint16_t ancount = ntohs(hdr->ancount);

    uint32_t pos = DNS_HDR_LEN;

    /* Walk the question section. This client only ever sends one
       question, but a well-behaved server echoes it back, so it
       must be skipped correctly to find the answer section. */
    for(uint16_t i = 0; i < qdcount; i++)
    {
        uint32_t consumed = 0;
        if(!dns_skip_name(buffer, len, pos, &consumed))
            return 0;
        pos += consumed;

        if(pos + 4 > len)
        {
            dns_debug("dns: question section truncated");
            return 0;
        }
        pos += 4; /* qtype + qclass */
    }

    /* Walk the answer section looking for the first A record. Other
       record types are skipped by their declared RDLENGTH -- never
       interpreted -- which is what makes ignoring AAAA/MX/TXT/CNAME/
       NS/SOA here actually safe rather than just "not implemented". */
    for(uint16_t i = 0; i < ancount; i++)
    {
        uint32_t consumed = 0;
        if(!dns_skip_name(buffer, len, pos, &consumed))
            return 0;
        pos += consumed;

        if(pos + 10 > len)
        {
            dns_debug("dns: answer record header truncated");
            return 0;
        }

        uint16_t rtype    = ntohs(*(const uint16_t*)(buffer + pos));
        uint16_t rclass   = ntohs(*(const uint16_t*)(buffer + pos + 2));
        uint32_t rttl     = ntohl(*(const uint32_t*)(buffer + pos + 4));
        uint16_t rdlength = ntohs(*(const uint16_t*)(buffer + pos + 8));
        pos += 10;

        if(pos + rdlength > len)
        {
            dns_debug("dns: answer RDATA runs past buffer");
            return 0;
        }

        if(rtype == DNS_TYPE_A && rclass == DNS_CLASS_IN)
        {
            if(rdlength != 4)
            {
                dns_debug("dns: A record with unexpected RDLENGTH");
                return 0;
            }

            *out_ip  = *(const uint32_t*)(buffer + pos); /* already network order */
            *out_ttl = rttl;
            return 1;
        }

        /* Not an A/IN record: skip exactly rdlength bytes without
           interpreting them. */
        pos += rdlength;
    }

    dns_debug("dns: no A record in answer section");
    return 0;
}

/* ── Receive ───────────────────────────────────────────────────────
   Called by the UDP layer for packets addressed to the DNS client
   port. Ignores anything that doesn't match the currently pending
   query rather than treating it as an error -- stray or duplicate
   responses are normal on an unreliable transport. */
void dns_receive(uint32_t src_ip, uint16_t src_port, uint8_t *buffer, uint32_t len)
{
    (void)src_port;

    if(!pending_active)
    {
        dns_debug("dns: response received with no pending query, ignored");
        return;
    }

    if(server_configured && src_ip != dns_server_ip)
    {
        dns_debug("dns: response from unexpected server, ignored");
        return;
    }

    if(buffer == 0 || len < DNS_HDR_LEN)
    {
        dns_stats.invalid_packets++;
        dns_debug("dns: null buffer or packet too short");
        return;
    }

    uint32_t ip = 0, ttl = 0;
    if(!dns_process_response(buffer, len, &ip, &ttl))
    {
        dns_stats.invalid_packets++;
        return;
    }

    dns_stats.responses_received++;
    dns_debug("dns: response received");

    dns_cache_insert(pending_hostname, ip, ttl);

    last_result    = DNS_RESULT_OK;
    last_result_ip = ip;
    pending_active = 0;
}

/* ── Timeout / retransmission driver ──────────────────────────────
   Same pattern as this project's DHCP client: no timer/sleep
   primitive lives here, so the caller must invoke this periodically
   with elapsed milliseconds since the previous call. Also drives
   cache expiry so that doesn't need a separate mechanism. */
void dns_poll(uint32_t elapsed_ms)
{
    dns_cache_init_once();
    dns_cache_age(elapsed_ms);

    if(!pending_active)
        return;

    pending_elapsed_ms += elapsed_ms;
    if(pending_elapsed_ms < DNS_QUERY_TIMEOUT_MS)
        return;

    pending_elapsed_ms = 0;
    dns_stats.timeouts++;

    if(pending_retries >= DNS_MAX_RETRIES)
    {
        dns_debug("dns: max retries exceeded");
        last_result    = DNS_RESULT_TIMEOUT;
        pending_active = 0;
        return;
    }

    pending_retries++;
    dns_stats.retransmissions++;
    dns_debug("dns: query timeout, retrying");
    dns_send_query(pending_hostname, pending_id);
}

/* ── Public control / accessors ───────────────────────────────── */

void dns_init(uint32_t server_ip)
{
    dns_cache_init_once();
    dns_server_ip     = server_ip;
    server_configured = 1;
}

dns_result_t dns_resolve(const char *hostname, uint32_t *out_ip)
{
    dns_cache_init_once();

    if(hostname == 0 || out_ip == 0)
        return DNS_RESULT_ERROR;

    if(dns_strlen(hostname) == 0 || dns_strlen(hostname) >= DNS_MAX_HOSTNAME)
    {
        dns_debug("dns_resolve: hostname too long or empty");
        return DNS_RESULT_ERROR;
    }

    dns_cache_entry_t *cached = dns_cache_find(hostname);
    if(cached)
    {
        dns_stats.cache_hits++;
        dns_debug("dns: cache hit");
        *out_ip = cached->ip;
        last_result    = DNS_RESULT_OK;
        last_result_ip = cached->ip;
        return DNS_RESULT_OK;
    }
    dns_stats.cache_misses++;
    dns_debug("dns: cache miss");

    if(!server_configured)
    {
        dns_debug("dns_resolve: no DNS server configured");
        return DNS_RESULT_ERROR;
    }

    dns_strcpy_bounded(pending_hostname, hostname, DNS_MAX_HOSTNAME);
    pending_id          = dns_next_id();
    pending_elapsed_ms  = 0;
    pending_retries     = 0;
    last_result         = DNS_RESULT_PENDING;

    if(!dns_send_query(pending_hostname, pending_id))
    {
        pending_active = 0;
        last_result    = DNS_RESULT_ERROR;
        return DNS_RESULT_ERROR;
    }

    pending_active = 1;
    return DNS_RESULT_PENDING;
}

dns_result_t dns_query_result(uint32_t *out_ip)
{
    if(last_result == DNS_RESULT_OK && out_ip != 0)
        *out_ip = last_result_ip;
    return last_result;
}

dns_stats_t dns_get_stats(void)
{
    return dns_stats;
}