/* ================================================================
   AETHRIX OS - tcp_validate.c
   TCP Phase 2: packet validation, checksum, and header/option
   parsing. No connection management, no state machine, no
   sequence/ack/window logic -- those belong to a later phase.
   ================================================================ */

#include "tcp.h"
#include "tcp_validate.h"
#include "ipv4.h"
#include "endian.h"

/* ── Assumptions about surrounding headers ────────────────────────
   This file assumes ipv4.h declares, matching how it was already
   written in this project:

     uint16_t ipv4_checksum(const void *data, uint32_t len);

   Reused here rather than reimplemented, per the RFC 1071
   algorithm being identical for IPv4/ICMP/UDP/TCP -- only the byte
   range and pseudo-header differ. */

/* ── Limits ────────────────────────────────────────────────────── */

/* Largest complete segment (header + options + payload) this layer
   will validate in one call. Matches this project's other transport
   layers' MTU-derived ceiling; a segment larger than this either
   didn't come from a single untagmented IPv4 datagram on a normal
   Ethernet path, or is lying about its own length. */
#define TCP_MAX_SEGMENT_LEN   (TCP_MAX_HDR_LEN + 65535)

/* ── Statistics ────────────────────────────────────────────────────
   This phase only touches the packet-level counters relevant to
   validation and checksum outcomes -- connections_opened/closed,
   resets, retransmissions, and duplicate tracking belong to the
   connection-management phase and are left at zero here. */
static tcp_stats_t tcp_stats = {0};

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   TCP_DEBUG_ENABLED locally during bring-up. Not wired to a
   specific logging call since this file doesn't own logging policy. */
#define TCP_DEBUG_ENABLED 0
static inline void tcp_debug(const char *msg)
{
#if TCP_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* ================================================================
   HEADER FIELD ACCESSORS
   ================================================================ */

/**
 * tcp_data_offset_words()
 *
 * Extracts the data offset field (bits 7-4 of data_offset_reserved)
 * as a word count. Multiply by 4 to get the header length in bytes.
 * Kept as a named helper so the bit shift isn't repeated inline at
 * every call site.
 */
static inline uint8_t tcp_data_offset_words(const struct tcp_header *hdr)
{
    return (uint8_t)(hdr->data_offset_reserved >> 4);
}

/**
 * tcp_reserved_bits()
 *
 * Extracts the 4 reserved bits (bits 3-0 of data_offset_reserved).
 * RFC 793 requires these be transmitted as zero; a nonzero value
 * here is either a non-conformant peer or a corrupted packet, and
 * either way this layer treats it as invalid rather than silently
 * masking it off.
 */
static inline uint8_t tcp_reserved_bits(const struct tcp_header *hdr)
{
    return (uint8_t)(hdr->data_offset_reserved & 0x0F);
}

/* ================================================================
   CHECKSUM
   ================================================================ */

/**
 * tcp_checksum()
 *
 * Computes the TCP checksum (RFC 793 section 3.1) over a pseudo-
 * header followed by the complete TCP segment (header + options +
 * payload). The pseudo-header -- source/destination IPv4 address, a
 * zero byte, the protocol number, and the TCP length -- is not part
 * of the actual segment on the wire; it exists only to fold IP-layer
 * addressing into the checksum so a segment can't be misdelivered
 * between two hosts without detection.
 *
 * segment/segment_len must together represent the entire TCP
 * segment (header through the last payload byte) exactly as it
 * would appear on the wire; this function does not itself trim or
 * validate segment_len against a header's own claimed length --
 * callers (tcp_checksum_valid() below, and the future transmit
 * path) are responsible for passing the correct range.
 *
 * Reuses ipv4_checksum()'s ones'-complement summation over a single
 * contiguous buffer rather than reimplementing that algorithm --
 * the pseudo-header and segment are copied into one local buffer
 * and summed in a single pass, the same approach this project's UDP
 * layer already uses for its own pseudo-header checksum.
 */
uint16_t tcp_checksum(uint32_t src_ip, uint32_t dst_ip,
                       const uint8_t *segment, uint32_t segment_len)
{
    struct pseudo_header {
        uint32_t src_ip;
        uint32_t dst_ip;
        uint8_t  zero;
        uint8_t  protocol;
        uint16_t tcp_len;
    } __attribute__((packed));

    uint8_t buf[sizeof(struct pseudo_header) + TCP_MAX_SEGMENT_LEN];

    if(segment_len > TCP_MAX_SEGMENT_LEN)
    {
        /* Should be unreachable in practice -- callers only ever pass
           a segment_len already bounded by IPv4's own total-length
           validation on the receive path, or by the future transmit
           path's own size checks. Fail closed rather than overflow
           buf if that invariant is ever violated. */
        tcp_debug("tcp_checksum: segment too large for pseudo-header buffer");
        return 0xFFFF; /* never equals a valid computed checksum of 0 */
    }

    struct pseudo_header *pseudo = (struct pseudo_header*)buf;
    pseudo->src_ip   = src_ip;
    pseudo->dst_ip   = dst_ip;
    pseudo->zero     = 0;
    pseudo->protocol = TCP_PROTOCOL_NUMBER;
    pseudo->tcp_len  = htons((uint16_t)segment_len);

    uint8_t *segment_copy = buf + sizeof(struct pseudo_header);
    for(uint32_t i = 0; i < segment_len; i++)
        segment_copy[i] = segment[i];

    return ipv4_checksum(buf, sizeof(struct pseudo_header) + segment_len);
}

/**
 * tcp_checksum_valid()
 *
 * Verifies a received segment's checksum. A correctly-checksummed
 * segment, summed together with its own checksum field (as received,
 * not zeroed), always folds to exactly zero -- that's the defining
 * property of the ones'-complement checksum, and is what this
 * function relies on rather than recomputing the checksum from
 * scratch and comparing values.
 */
static int tcp_checksum_valid(uint32_t src_ip, uint32_t dst_ip,
                               const uint8_t *segment, uint32_t segment_len)
{
    return tcp_checksum(src_ip, dst_ip, segment, segment_len) == 0;
}

/* ================================================================
   HEADER VALIDATION
   ================================================================ */

/**
 * tcp_header_valid()
 *
 * Validates a TCP segment's framing before any field beyond the
 * fixed header is trusted: minimum/maximum header length, the data
 * offset against the actual received length, and the reserved bits.
 * Every check here exists to make the reads that follow (option
 * parsing, payload extraction) provably safe -- out_hdr_len is only
 * written once it's confirmed to be both internally consistent
 * (>= the fixed header, <= TCP_MAX_HDR_LEN) and within the bytes
 * actually received (<= len).
 *
 * Does not verify the checksum -- that's a separate, more expensive
 * check performed by the caller only after this cheaper structural
 * validation passes, so a segment with a bogus data offset is
 * rejected before spending time summing the whole thing.
 */
static int tcp_header_valid(const uint8_t *buffer, uint32_t len,
                             const struct tcp_header *hdr,
                             uint32_t *out_hdr_len)
{
    if(len < TCP_MIN_HDR_LEN)
    {
        tcp_debug("tcp: segment shorter than minimum header");
        return 0;
    }

    uint8_t offset_words = tcp_data_offset_words(hdr);
    uint32_t hdr_len = (uint32_t)offset_words * 4;

    if(hdr_len < TCP_MIN_HDR_LEN)
    {
        tcp_debug("tcp: data offset below minimum header length");
        return 0;
    }

    if(hdr_len > TCP_MAX_HDR_LEN)
    {
        /* Not actually reachable given data offset is only 4 bits
           (max value 15 words = 60 bytes = TCP_MAX_HDR_LEN), but
           checked explicitly rather than relying on that fact
           silently holding if the field width ever changes. */
        tcp_debug("tcp: data offset exceeds maximum header length");
        return 0;
    }

    if(hdr_len > len)
    {
        tcp_debug("tcp: header length exceeds received segment");
        return 0;
    }

    if(tcp_reserved_bits(hdr) != 0)
    {
        tcp_debug("tcp: nonzero reserved bits");
        return 0;
    }

    if(hdr->src_port == 0 || hdr->dst_port == 0)
    {
        /* Port 0 is reserved and never a valid TCP endpoint (RFC
           793 doesn't explicitly forbid it on the wire, but no
           legitimate TCP implementation sends it, and accepting it
           here would let a segment address a port this stack could
           never have listened on or connected from). */
        tcp_debug("tcp: source or destination port is zero");
        return 0;
    }

    *out_hdr_len = hdr_len;
    return 1;
}

/* ================================================================
   PARSED SEGMENT
   ================================================================
   struct tcp_parsed_segment is declared in tcp_validate.h; see
   that header for field documentation. */

/* ================================================================
   OPTION PARSING
   ================================================================
   struct tcp_parsed_options is declared in tcp_validate.h; see that
   header for field documentation. */

/**
 * tcp_parse_options()
 *
 * Walks the TLV option list starting at `options`, strictly bounded
 * by options_len -- every read of a kind/length/value byte is
 * checked against the remaining length before it happens, so this
 * never reads past the end of the caller's buffer regardless of
 * what a malformed or hostile segment contains.
 *
 * Unknown option kinds are skipped by their declared length rather
 * than interpreted, which is what makes "ignore unknown options
 * safely" actually safe rather than merely unimplemented. SACK
 * block contents are intentionally not extracted (SACK Permitted is
 * recorded as a flag only) -- parsing the block list itself is
 * deferred to whatever later phase implements SACK-based
 * retransmission, since this phase has no retransmission queue for
 * that information to inform.
 *
 * Returns 1 if the option list was well-formed (every option's
 * declared length fit within the buffer), 0 otherwise. A return of
 * 0 means the caller should treat the whole segment as malformed --
 * this function does not partially trust a corrupted option list.
 */
static int tcp_parse_options(const uint8_t *options, uint32_t options_len,
                              tcp_parsed_options_t *out)
{
    uint32_t i = 0;

    out->have_mss          = 0;
    out->have_window_scale = 0;
    out->sack_permitted    = 0;
    out->have_timestamp    = 0;

    while(i < options_len)
    {
        uint8_t kind = options[i];

        if(kind == TCP_OPT_KIND_END)
            return 1;

        if(kind == TCP_OPT_KIND_NOP)
        {
            i++;
            continue;
        }

        /* Every option beyond END/NOP carries its own length byte;
           bail rather than read past the buffer if it's missing. */
        if(i + 1 >= options_len)
        {
            tcp_debug("tcp: option truncated before length byte");
            return 0;
        }

        uint8_t opt_len = options[i + 1];

        /* RFC 793: length includes the kind and length bytes
           themselves, so the smallest legal length for any option
           carrying a value is 2. An option claiming a length smaller
           than that (or claiming to be END/NOP's implicit 1-byte
           length while using this branch) is malformed. */
        if(opt_len < 2)
        {
            tcp_debug("tcp: option length field too small");
            return 0;
        }

        if(i + opt_len > options_len)
        {
            tcp_debug("tcp: option length exceeds remaining buffer");
            return 0;
        }

        const uint8_t *value = &options[i + 2];
        uint8_t value_len = (uint8_t)(opt_len - 2);

        switch(kind)
        {
            case TCP_OPT_KIND_MSS:
                if(opt_len == TCP_OPT_LEN_MSS && value_len == 2)
                {
                    out->mss      = ntohs(*(const uint16_t*)value);
                    out->have_mss = 1;
                }
                else
                {
                    tcp_debug("tcp: MSS option with unexpected length");
                    return 0;
                }
                break;

            case TCP_OPT_KIND_WSCALE:
                if(opt_len == TCP_OPT_LEN_WSCALE && value_len == 1)
                {
                    out->window_scale      = value[0];
                    out->have_window_scale = 1;
                }
                else
                {
                    tcp_debug("tcp: window scale option with unexpected length");
                    return 0;
                }
                break;

            case TCP_OPT_KIND_SACK_PERM:
                if(opt_len == TCP_OPT_LEN_SACK_PERM)
                {
                    out->sack_permitted = 1;
                }
                else
                {
                    tcp_debug("tcp: SACK-permitted option with unexpected length");
                    return 0;
                }
                break;

            case TCP_OPT_KIND_SACK:
                /* Length is variable (2 + 8 bytes per block); only
                   the bound check above matters here since block
                   contents aren't extracted in this phase. Still
                   validated for a sane length so a corrupt SACK
                   option doesn't silently pass as well-formed. */
                if(value_len == 0 || (value_len % 8) != 0)
                {
                    tcp_debug("tcp: SACK option with non-block-aligned length");
                    return 0;
                }
                break;

            case TCP_OPT_KIND_TIMESTAMP:
                if(opt_len == TCP_OPT_LEN_TIMESTAMP && value_len == 8)
                {
                    out->timestamp_value = ntohl(*(const uint32_t*)value);
                    out->timestamp_echo  = ntohl(*(const uint32_t*)(value + 4));
                    out->have_timestamp  = 1;
                }
                else
                {
                    tcp_debug("tcp: timestamp option with unexpected length");
                    return 0;
                }
                break;

            default:
                /* Unrecognized kind: skip by its declared length,
                   already bounds-checked above. This is the "ignore
                   unknown options safely" path. */
                tcp_debug("tcp: unrecognized option kind, skipped");
                break;
        }

        i += opt_len;
    }

    /* Reached the end of the buffer without an explicit END option.
       Not necessarily malicious -- END is only required if the
       option area isn't already exhausted -- so this is treated as
       well-formed rather than rejected. */
    return 1;
}

/* ================================================================
   SEGMENT PARSING (validation + checksum + options, combined)
   ================================================================ */

/**
 * tcp_parse_segment()
 *
 * Top-level entry point for this phase: validates framing, verifies
 * the checksum, parses options, and fills out a tcp_parsed_segment_t
 * plus a tcp_parsed_options_t describing the segment -- all without
 * making any decision that requires knowing about an existing
 * connection or the TCP state machine. That interpretation (does
 * this ACK make sense, is this sequence number in-window, what
 * state should this transition to) is deliberately left to a later
 * phase; this function's job ends at "is this a well-formed,
 * correctly-checksummed TCP segment, and if so, here's what's in
 * it."
 *
 * src_ip/dst_ip are the IPv4 addresses from the already-validated
 * IPv4 header (network byte order) -- required for the pseudo-
 * header checksum, but this function does not parse or trust
 * anything else about the IPv4 layer.
 *
 * buffer must contain at least len valid bytes. Every field this
 * function reads is bounds-checked before the read happens; nothing
 * here reads past buffer[len-1].
 *
 * Returns 1 and fills *out_segment / *out_options on success. On
 * any validation failure, returns 0, updates the appropriate
 * statistics counter, and leaves *out_segment / *out_options
 * unwritten.
 */
int tcp_parse_segment(uint32_t src_ip, uint32_t dst_ip,
                       const uint8_t *buffer, uint32_t len,
                       tcp_parsed_segment_t *out_segment,
                       tcp_parsed_options_t *out_options)
{
    if(buffer == 0 || out_segment == 0 || out_options == 0)
    {
        tcp_stats.invalid_packets++;
        tcp_debug("tcp: null buffer or output pointer");
        return 0;
    }

    if(len > TCP_MAX_SEGMENT_LEN)
    {
        tcp_stats.malformed_packets++;
        tcp_debug("tcp: segment exceeds maximum supported length");
        return 0;
    }

    if(len < TCP_MIN_HDR_LEN)
    {
        tcp_stats.malformed_packets++;
        tcp_debug("tcp: segment shorter than minimum header");
        return 0;
    }

    const struct tcp_header *hdr = (const struct tcp_header*)buffer;

    uint32_t hdr_len = 0;
    if(!tcp_header_valid(buffer, len, hdr, &hdr_len))
    {
        tcp_stats.malformed_packets++;
        return 0;
    }

    if(!tcp_checksum_valid(src_ip, dst_ip, buffer, len))
    {
        tcp_stats.checksum_failures++;
        tcp_debug("tcp: checksum failure");
        return 0;
    }

    uint32_t options_len = hdr_len - TCP_MIN_HDR_LEN;
    const uint8_t *options = (options_len > 0) ? (buffer + TCP_MIN_HDR_LEN) : 0;

    tcp_parsed_options_t parsed_opts;
    if(options_len > 0 && !tcp_parse_options(options, options_len, &parsed_opts))
    {
        tcp_stats.invalid_packets++;
        tcp_debug("tcp: malformed option list");
        return 0;
    }
    if(options_len == 0)
    {
        parsed_opts.have_mss          = 0;
        parsed_opts.have_window_scale = 0;
        parsed_opts.sack_permitted    = 0;
        parsed_opts.have_timestamp    = 0;
    }

    uint32_t payload_len = len - hdr_len;
    const uint8_t *payload = (payload_len > 0) ? (buffer + hdr_len) : 0;

    out_segment->src_port    = ntohs(hdr->src_port);
    out_segment->dst_port    = ntohs(hdr->dst_port);
    out_segment->seq_num     = ntohl(hdr->seq_num);
    out_segment->ack_num     = ntohl(hdr->ack_num);
    out_segment->flags       = hdr->flags;
    out_segment->window      = ntohs(hdr->window);
    out_segment->checksum    = ntohs(hdr->checksum);
    out_segment->urgent_ptr  = ntohs(hdr->urgent_ptr);
    out_segment->hdr_len     = hdr_len;
    out_segment->options     = options;
    out_segment->options_len = options_len;
    out_segment->payload     = payload;
    out_segment->payload_len = payload_len;

    *out_options = parsed_opts;

    tcp_stats.packets_received++;
    tcp_debug("tcp: segment parsed and validated");
    return 1;
}

/* ================================================================
   OUTGOING CHECKSUM GENERATION
   ================================================================ */

/**
 * tcp_finalize_checksum()
 *
 * Computes and writes the checksum field for a segment that has
 * already been fully assembled -- header complete, options written,
 * payload copied in, and hdr->checksum field zeroed by the caller
 * before this is called. This function does not build or transmit
 * a segment itself (that belongs to a later phase's send path); it
 * only performs the last step of "compute the checksum now that
 * everything else about this segment is final," per this phase's
 * scope of checksum generation without a full transmit path.
 *
 * segment_len is the complete segment length (header + options +
 * payload) exactly as it will be transmitted.
 */
void tcp_finalize_checksum(uint32_t src_ip, uint32_t dst_ip,
                            uint8_t *segment, uint32_t segment_len)
{
    struct tcp_header *hdr = (struct tcp_header*)segment;
    hdr->checksum = 0;
    hdr->checksum = htons(tcp_checksum(src_ip, dst_ip, segment, segment_len));
}

/* ================================================================
   STATISTICS ACCESSOR
   ================================================================ */

tcp_stats_t tcp_get_stats(void)
{
    return tcp_stats;
}