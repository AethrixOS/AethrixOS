/* ================================================================
   AETHRIX OS - tcp.h
   Transmission Control Protocol: public interface (Phase 1)

   This header defines the TCP wire format, protocol constants,
   connection state enum, connection structure, statistics
   structure, and public API surface. It contains no packet
   processing, checksum, sequencing, or state-transition logic --
   those belong to tcp.c in a later phase.

   TCP communicates only with the IPv4 layer (ipv4_send() /
   ipv4_receive() dispatch); this header does not reference
   Ethernet, ARP, DHCP, DNS, or any NIC driver.
   ================================================================ */

#ifndef AETHRIX_TCP_H
#define AETHRIX_TCP_H

#include <stdint.h>

/* ================================================================
   WIRE FORMAT
   ================================================================ */

/**
 * struct tcp_header
 *
 * Standard TCP segment header (RFC 793), fixed 20-byte portion
 * only -- options, when present, follow immediately after this
 * struct in the packet and are addressed separately (see
 * TCP_MIN_HDR_LEN / TCP_MAX_HDR_LEN below). Packed so this struct's
 * in-memory layout matches the on-wire layout exactly; a received
 * buffer can be cast directly onto this struct.
 *
 * All multi-byte fields are network byte order and must go through
 * ntohs()/ntohl() before use, and htons()/htonl() when populated
 * for transmission.
 *
 * data_offset_reserved packs two fields into one byte:
 *   bits 7-4: data offset, in 32-bit words (header length / 4)
 *   bits 3-0: reserved, must be sent as zero (RFC 793 section 3.1)
 *
 * flags packs the eight TCP control bits into one byte, in the
 * order they appear on the wire (bit 7 = CWR down to bit 0 = FIN).
 * See "TCP FLAGS" below for the individual bit constants.
 */
struct tcp_header {
    uint16_t src_port;             /* sending port                        */
    uint16_t dst_port;             /* receiving port                      */
    uint32_t seq_num;              /* sequence number                     */
    uint32_t ack_num;              /* acknowledgement number              */
    uint8_t  data_offset_reserved; /* data offset (4 bits) + reserved (4) */
    uint8_t  flags;                /* control bits: CWR..FIN              */
    uint16_t window;               /* receive window size                */
    uint16_t checksum;             /* pseudo-header + segment checksum   */
    uint16_t urgent_ptr;           /* urgent pointer, valid iff URG set  */
} __attribute__((packed));

/* ================================================================
   TCP FLAGS
   ================================================================ */

/**
 * Individual bits of struct tcp_header.flags (RFC 793, with ECE/CWR
 * added by RFC 3168). Combine with bitwise OR when building a
 * segment; test with bitwise AND when parsing one.
 */
#define TCP_FLAG_FIN   0x01  /* no more data from sender                  */
#define TCP_FLAG_SYN   0x02  /* synchronize sequence numbers              */
#define TCP_FLAG_RST   0x04  /* reset the connection                      */
#define TCP_FLAG_PSH   0x08  /* push buffered data to the application     */
#define TCP_FLAG_ACK   0x10  /* acknowledgement field is significant      */
#define TCP_FLAG_URG   0x20  /* urgent pointer field is significant       */
#define TCP_FLAG_ECE   0x40  /* ECN-Echo (RFC 3168)                       */
#define TCP_FLAG_CWR   0x80  /* Congestion Window Reduced (RFC 3168)      */

/* ================================================================
   PROTOCOL CONSTANTS
   ================================================================ */

/** IPv4 protocol number identifying TCP (matches IPV4_PROTO_TCP). */
#define TCP_PROTOCOL_NUMBER        6

/** Fixed TCP header size in bytes, with no options present. */
#define TCP_MIN_HDR_LEN            20

/**
 * Largest possible TCP header in bytes: data offset is a 4-bit
 * word count, so the header (including options) can never exceed
 * 15 * 4 = 60 bytes.
 */
#define TCP_MAX_HDR_LEN            60

/** Largest an options block can be: max header minus the fixed part. */
#define TCP_MAX_OPTIONS_LEN        (TCP_MAX_HDR_LEN - TCP_MIN_HDR_LEN)

/**
 * Sizes of individual TCP options this stack is expected to
 * recognize, in bytes, including each option's own kind/length
 * octets. Defined here so option-parsing code has named sizes to
 * validate against instead of magic numbers.
 */
#define TCP_OPT_KIND_END           0   /* end of option list           */
#define TCP_OPT_KIND_NOP           1   /* no-operation / padding       */
#define TCP_OPT_KIND_MSS           2   /* maximum segment size         */
#define TCP_OPT_KIND_WSCALE        3   /* window scale                 */
#define TCP_OPT_KIND_SACK_PERM     4   /* SACK permitted               */
#define TCP_OPT_KIND_SACK          5   /* SACK block(s)                */
#define TCP_OPT_KIND_TIMESTAMP     8   /* timestamps                   */

#define TCP_OPT_LEN_MSS            4   /* kind + len + 2-byte MSS value */
#define TCP_OPT_LEN_WSCALE         3   /* kind + len + 1-byte shift     */
#define TCP_OPT_LEN_SACK_PERM      2   /* kind + len, no value          */
#define TCP_OPT_LEN_TIMESTAMP      10  /* kind + len + 2 x 4-byte time  */

/**
 * Default receive window size, in bytes, offered by a newly-created
 * connection before any runtime tuning is applied.
 */
#define TCP_DEFAULT_WINDOW         8192

/**
 * Placeholder default Maximum Segment Size, in bytes, used before
 * MSS negotiation logic exists. 536 is RFC 793's default MSS for
 * any connection that didn't negotiate a larger value, and is safe
 * for any IPv4 path.
 */
#define TCP_DEFAULT_MSS            536

/* ================================================================
   TCP CONNECTION STATES
   ================================================================ */

/**
 * enum tcp_state
 *
 * The eleven TCP connection states defined by RFC 793's state
 * diagram. This header only declares the enum; which transitions
 * between states are legal, and how they're triggered, is
 * state-machine logic that belongs to tcp.c.
 */
typedef enum {
    TCP_STATE_CLOSED = 0,     /* no connection; the initial/final state  */
    TCP_STATE_LISTEN,          /* waiting for a connection request        */
    TCP_STATE_SYN_SENT,        /* sent SYN, waiting for matching SYN+ACK  */
    TCP_STATE_SYN_RECEIVED,    /* received SYN, sent SYN+ACK, awaiting ACK*/
    TCP_STATE_ESTABLISHED,     /* open connection, data may flow          */
    TCP_STATE_FIN_WAIT_1,      /* sent FIN, awaiting ACK or peer's FIN    */
    TCP_STATE_FIN_WAIT_2,      /* our FIN acked, awaiting peer's FIN      */
    TCP_STATE_CLOSE_WAIT,      /* received peer's FIN, awaiting local close*/
    TCP_STATE_CLOSING,         /* both sides sent FIN, not yet fully acked*/
    TCP_STATE_LAST_ACK,        /* sent FIN after CLOSE_WAIT, awaiting ACK */
    TCP_STATE_TIME_WAIT        /* waiting for stray segments to expire    */
} tcp_state_t;

/* ================================================================
   TCP CONNECTION STRUCTURE
   ================================================================ */

/**
 * struct tcp_connection
 *
 * Represents a single TCP connection (one 4-tuple's worth of
 * state). This structure only holds data; nothing in tcp.h reads or
 * writes these fields -- that logic belongs to tcp.c in a later
 * phase.
 *
 * Sequence-space fields (send/receive sequence, acknowledgement,
 * windows) follow RFC 793 section 3.2's naming where a direct
 * equivalent exists, so this structure reads naturally against the
 * RFC's state diagram and variable list.
 *
 * Timer and statistics fields are declared as placeholders: their
 * types are fixed now so later phases don't need to change this
 * structure's layout, but no timer or stats logic is implemented
 * here.
 */
typedef struct tcp_connection {
    /* -- Identity: the 4-tuple that names this connection -- */
    uint32_t local_ip;           /* local IPv4 address, network order   */
    uint32_t remote_ip;          /* remote IPv4 address, network order  */
    uint16_t local_port;         /* local TCP port, host order          */
    uint16_t remote_port;        /* remote TCP port, host order         */

    /* -- Connection state -- */
    tcp_state_t state;           /* current position in the state machine*/

    /* -- Send sequence space (RFC 793 fig. 4) -- */
    uint32_t snd_una;            /* oldest unacknowledged sequence number*/
    uint32_t snd_nxt;            /* next sequence number to send         */
    uint16_t snd_wnd;            /* send window, as advertised by peer   */

    /* -- Receive sequence space -- */
    uint32_t rcv_nxt;            /* next sequence number expected        */
    uint16_t rcv_wnd;            /* receive window offered to peer       */

    /* -- Acknowledgement bookkeeping -- */
    uint32_t last_ack_sent;      /* ack number most recently transmitted */

    /* -- Timers (placeholders: type fixed, logic deferred) -- */
    uint32_t retransmit_timer_ms; /* time remaining on the RTO, if any   */
    uint32_t idle_timer_ms;       /* time since last activity            */

    /* -- Connection flags: bitfield of TCP_CONN_FLAG_* below -- */
    uint32_t conn_flags;

    /* -- Per-connection statistics (placeholders) -- */
    uint32_t packets_sent;
    uint32_t packets_received;
    uint32_t retransmissions;
} tcp_connection_t;

/**
 * Bits for tcp_connection_t.conn_flags. Declared here so later
 * phases have a stable set of names to target; no code in this
 * phase sets or reads them.
 */
#define TCP_CONN_FLAG_PASSIVE_OPEN   0x00000001u /* opened via tcp_listen() */
#define TCP_CONN_FLAG_ACTIVE_OPEN    0x00000002u /* opened via tcp_connect()*/
#define TCP_CONN_FLAG_FIN_SENT       0x00000004u /* local FIN transmitted   */
#define TCP_CONN_FLAG_FIN_RECEIVED   0x00000008u /* peer's FIN received     */

/* ================================================================
   TCP STATISTICS
   ================================================================ */

/**
 * struct tcp_stats_t
 *
 * Stack-wide counters, aggregated across all connections. Returned
 * by value from tcp_get_stats() so callers can't mutate the live
 * counters maintained internally by tcp.c.
 */
typedef struct {
    uint32_t packets_transmitted;   /* segments sent, all connections    */
    uint32_t packets_received;      /* segments received, all connections*/
    uint32_t connections_opened;    /* connections that reached ESTABLISHED*/
    uint32_t connections_closed;    /* connections that reached CLOSED
                                        after having been established     */
    uint32_t resets;                /* RST segments sent or received     */
    uint32_t retransmissions;       /* segments retransmitted            */
    uint32_t checksum_failures;     /* segments dropped for bad checksum */
    uint32_t malformed_packets;     /* segments dropped for bad framing  */
    uint32_t dropped_packets;       /* segments dropped for any other
                                        validation failure                */
    uint32_t duplicate_packets;     /* segments identified as duplicates */
    uint32_t duplicate_acks;        /* ACKs identified as duplicates     */
    uint32_t invalid_packets;       /* segments rejected outright (e.g.
                                        impossible seq/ack, bad flags)    */
} tcp_stats_t;

/* ================================================================
   PUBLIC API
   ================================================================ */

/**
 * tcp_init()
 *
 * One-time initialization of the TCP layer's internal state (e.g.
 * connection table, statistics). Must be called once during network
 * stack bring-up, before any other tcp_*() function.
 */
void tcp_init(void);

/**
 * tcp_receive()
 *
 * Entry point called by the IPv4 layer for every datagram with
 * protocol TCP. src_ip and dst_ip are the sender/receiver IPv4
 * addresses from the already-validated IPv4 header (network byte
 * order); buffer/len are the TCP segment (header + options +
 * payload) exactly as received. Implementation deferred to a later
 * phase.
 */
void tcp_receive(uint32_t src_ip, uint32_t dst_ip, uint8_t *buffer, uint32_t len);

/**
 * tcp_send()
 *
 * Transmits payload on an established connection. Implementation
 * (segmentation, sequencing, retransmission queueing) deferred to a
 * later phase. Returns the number of bytes accepted for sending, or
 * a negative value on failure, once implemented.
 */
int tcp_send(tcp_connection_t *conn, const uint8_t *payload, uint32_t payload_len);

/**
 * tcp_connect()
 *
 * Initiates an active open to (remote_ip, remote_port) from
 * local_port. Implementation of the SYN_SENT handshake deferred to
 * a later phase. Returns a connection handle once implemented.
 */
tcp_connection_t *tcp_connect(uint32_t remote_ip, uint16_t remote_port,
                               uint16_t local_port);

/**
 * tcp_listen()
 *
 * Places a connection in LISTEN on local_port, ready to accept a
 * passive open. Implementation deferred to a later phase. Returns a
 * connection handle once implemented.
 */
tcp_connection_t *tcp_listen(uint16_t local_port);

/**
 * tcp_close()
 *
 * Begins a graceful close on conn (RFC 793's active/passive close
 * sequences). Implementation of the FIN_WAIT/CLOSE_WAIT/LAST_ACK/
 * TIME_WAIT transitions deferred to a later phase.
 */
void tcp_close(tcp_connection_t *conn);

/**
 * tcp_poll()
 *
 * Drives all timer-based behavior (retransmission timeout,
 * exponential backoff, delayed ACK, TIME_WAIT expiry) across every
 * active connection. TCP has no timer/sleep primitive of its own;
 * the caller is expected to invoke this periodically with elapsed
 * milliseconds since the previous call, matching the polling
 * pattern already used by this stack's DHCP and DNS clients.
 * Implementation deferred to a later phase.
 */
void tcp_poll(uint32_t elapsed_ms);

/**
 * tcp_get_stats()
 *
 * Returns a snapshot of the stack-wide statistics counters, for
 * diagnostics or shell commands.
 */
tcp_stats_t tcp_get_stats(void);

#endif /* AETHRIX_TCP_H */