/* ================================================================
   AETHRIX OS - arp.h
   Address Resolution Protocol: public interface
   ================================================================ */

#ifndef AETHRIX_ARP_H
#define AETHRIX_ARP_H

#include <stdint.h>

/* ── Wire format ───────────────────────────────────────────────────
   Standard ARP packet for Ethernet/IPv4 (RFC 826). Packed so the
   struct's in-memory layout matches the on-wire layout exactly --
   arp.c casts a received buffer directly onto this struct. */
struct arp_header {
    uint16_t htype;   /* hardware type (1 = Ethernet)        */
    uint16_t ptype;   /* protocol type (0x0800 = IPv4)        */
    uint8_t  hlen;    /* hardware address length (6)          */
    uint8_t  plen;    /* protocol address length (4)          */
    uint16_t oper;    /* opcode: request or reply             */
    uint8_t  sha[6];  /* sender hardware address               */
    uint32_t spa;     /* sender protocol address (net order)  */
    uint8_t  tha[6];  /* target hardware address               */
    uint32_t tpa;     /* target protocol address (net order)  */
} __attribute__((packed));

/* ── Constants ─────────────────────────────────────────────────── */
#define ARP_HTYPE_ETH   1
#define ARP_PTYPE_IPV4  0x0800

#define ARP_OP_REQUEST  1
#define ARP_OP_REPLY    2

/* ── Statistics ────────────────────────────────────────────────────
   Snapshot returned by arp_get_stats(). Returned by value so callers
   can't mutate the live counters in arp.c. */
typedef struct {
    uint32_t requests_sent;
    uint32_t requests_received;
    uint32_t replies_sent;
    uint32_t replies_received;
    uint32_t cache_hits;
    uint32_t cache_misses;
    uint32_t malformed;
} arp_stats_t;

/* ── Public interface ──────────────────────────────────────────────

   arp_receive()
     Entry point called by the Ethernet layer for every frame with
     EtherType ARP. Validates the packet, updates the cache, and
     replies to requests targeting this host. buffer must contain at
     least len valid bytes; arp_receive() never reads past that.

   arp_send_request()
     Broadcasts an ARP Request for target_ip (network byte order).
     Does not block waiting for a reply -- use arp_lookup() after a
     short delay, or retry, depending on caller needs.

   arp_lookup()
     Looks up ip (network byte order) in the ARP cache. On a hit,
     copies the 6-byte MAC into out_mac and returns 1. On a miss,
     returns 0 and out_mac is left unmodified.

   arp_get_stats()
     Returns a snapshot of the internal counters, for diagnostics or
     shell commands. */

void        arp_receive(uint8_t *buffer, uint32_t len);
void        arp_send_request(uint32_t target_ip);
int         arp_lookup(uint32_t ip, uint8_t *out_mac);
arp_stats_t arp_get_stats(void);

#endif /* AETHRIX_ARP_H */