/* ================================================================
   AETHRIX OS - dhcp.h
   DHCP client: public interface
   ================================================================ */

#ifndef AETHRIX_DHCP_H
#define AETHRIX_DHCP_H

#include <stdint.h>

/* ── Client state machine ─────────────────────────────────────── */
typedef enum {
    DHCP_STATE_INIT = 0,
    DHCP_STATE_DISCOVER_SENT,
    DHCP_STATE_OFFER_RECEIVED,
    DHCP_STATE_REQUEST_SENT,
    DHCP_STATE_BOUND
} dhcp_state_t;

/* ── Resulting lease, once bound ──────────────────────────────── */
typedef struct {
    uint32_t ip_addr;      /* network byte order */
    uint32_t subnet_mask;
    uint32_t gateway;
    uint32_t dns_server;
    uint32_t lease_time;   /* seconds, host byte order */
    uint32_t server_id;    /* DHCP server that issued the lease */
} dhcp_lease_t;

/* ── Statistics ────────────────────────────────────────────────── */
typedef struct {
    uint32_t discovers_sent;
    uint32_t offers_received;
    uint32_t requests_sent;
    uint32_t acks_received;
    uint32_t naks_received;
    uint32_t invalid_packets;
    uint32_t timeouts;
    uint32_t retransmissions;
} dhcp_stats_t;

/* ── Public interface ──────────────────────────────────────────────

   dhcp_start()
     Resets the client to INIT and sends the first Discover. Call
     once at boot (or whenever you want to force a fresh lease).

   dhcp_receive()
     Entry point called by the UDP layer for packets addressed to
     the DHCP client port. src_ip/src_port are the sender's address
     as seen by UDP; buffer must contain at least len valid bytes,
     and dhcp_receive() never reads past that.

   dhcp_poll()
     Drives timeouts and retransmissions. This client has no timer
     or sleep primitive of its own -- call this periodically (e.g.
     once per scheduler tick or once per second from the kernel's
     main loop) with the number of milliseconds elapsed since the
     previous call. Without regular dhcp_poll() calls, a lost
     Discover or Request will stall forever rather than retry.

   dhcp_get_state()
     Current client state, for a shell command or boot-time status
     line.

   dhcp_get_lease()
     Copies the current lease into *out_lease and returns 1 if the
     client is BOUND, or returns 0 (out_lease left untouched) if not
     yet bound.

   dhcp_get_stats()
     Returns a snapshot of the internal counters. */

void         dhcp_start(void);
void         dhcp_receive(uint32_t src_ip, uint16_t src_port,
                           uint8_t *buffer, uint32_t len);
void         dhcp_poll(uint32_t elapsed_ms);
dhcp_state_t dhcp_get_state(void);
int          dhcp_get_lease(dhcp_lease_t *out_lease);
dhcp_stats_t dhcp_get_stats(void);

#endif /* AETHRIX_DHCP_H */