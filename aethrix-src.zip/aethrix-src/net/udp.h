/* ================================================================
   AETHRIX OS - udp.h
   User Datagram Protocol: public interface
   ================================================================ */

#ifndef AETHRIX_UDP_H
#define AETHRIX_UDP_H

#include <stdint.h>

/* ── Wire format ───────────────────────────────────────────────────
   Standard UDP header (RFC 768). Packed so this struct's layout
   matches the on-wire layout exactly; udp.c casts a received buffer
   directly onto this struct. All multi-byte fields are network byte
   order and must go through ntohs before use. */
struct udp_header {
    uint16_t src_port;
    uint16_t dst_port;
    uint16_t length;    /* header + payload, in bytes */
    uint16_t checksum;  /* zero means "checksum disabled" per RFC 768 */
} __attribute__((packed));

#define UDP_HDR_LEN         8

/* Well-known ports this build dispatches to. */
#define UDP_PORT_DHCP_CLIENT  68
#define UDP_PORT_DNS          53

/* ── Statistics ────────────────────────────────────────────────────
   Snapshot returned by udp_get_stats(). Returned by value so callers
   can't mutate the live counters in udp.c. */
typedef struct {
    uint32_t rx_packets;
    uint32_t tx_packets;
    uint32_t dropped;
    uint32_t malformed;
    uint32_t checksum_failures;
    uint32_t checksum_disabled;
    uint32_t unknown_port;
} udp_stats_t;

/* ── Public interface ──────────────────────────────────────────────

   udp_receive()
     Entry point called by the IPv4 layer for every datagram with
     protocol UDP. src_ip and dst_ip are the sender/receiver IPv4
     addresses from the already-validated IPv4 header (network byte
     order) -- udp.c needs both to verify the checksum's pseudo-
     header but does not parse IPv4 headers itself. buffer must
     contain at least len valid bytes; udp_receive() never reads
     past that.

     Note: this adds dst_ip to the (src_ip, buffer, len) shape used
     by icmp_receive() in this project, since UDP's checksum -- unlike
     ICMP's -- covers a pseudo-header that includes the destination
     address (RFC 768). If IPv4's dispatch call site was written
     against a 3-argument shape, it needs a small update to pass
     dst_ip through here.

   udp_send()
     Builds a UDP header around payload, addressed from src_port to
     (dst_ip, dst_port), and hands it to ipv4_send(). Returns 1 if
     handed off successfully, 0 otherwise.

   udp_get_stats()
     Returns a snapshot of the internal counters, for diagnostics or
     shell commands. */

void        udp_receive(uint32_t src_ip, uint32_t dst_ip,
                         uint8_t *buffer, uint32_t len);
int         udp_send(uint32_t dst_ip, uint16_t src_port, uint16_t dst_port,
                      const uint8_t *payload, uint32_t payload_len);
udp_stats_t udp_get_stats(void);

#endif /* AETHRIX_UDP_H */