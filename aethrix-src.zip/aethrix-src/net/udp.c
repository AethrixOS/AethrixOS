/* ================================================================
   AETHRIX OS - udp.c
   User Datagram Protocol: validation, checksum, dispatch, send
   ================================================================ */

#include "udp.h"
#include "ipv4.h"
#include "endian.h"

/* ── Assumptions about surrounding headers ────────────────────────
   This file assumes the following, matching how ipv4.h/icmp.h were
   already written in this project. Reconcile against your actual
   headers before building:

     uint16_t ipv4_checksum(const void *data, uint32_t len);
     int      ipv4_send(uint32_t dst_ip, uint8_t protocol,
                         const uint8_t *payload, uint32_t payload_len);
     #define IPV4_PROTO_UDP 17
     extern uint32_t local_ip;                  (network byte order,
                                                   declared in ethernet.h
                                                   per earlier files)

   dhcp_receive() / dns_receive() are declared as externs below
   rather than pulled in via dhcp.h/dns.h, so this file doesn't take
   on an include dependency on those layers beyond the two call
   signatures it actually uses. Update both the externs and the call
   sites together if the real signatures differ. */

extern uint32_t local_ip;

extern void dhcp_receive(uint32_t src_ip, uint16_t src_port,
                          uint8_t *payload, uint32_t len);
extern void dns_receive(uint32_t src_ip, uint16_t src_port,
                         uint8_t *payload, uint32_t len);

#define UDP_MAX_PAYLOAD   1472   /* Ethernet MTU minus IPv4/UDP header
                                     overhead; adjust if fragmentation
                                     is ever added to IPv4 */

/* ── Statistics ────────────────────────────────────────────────────
   udp_stats_t is declared in udp.h; only the live instance lives
   here. */
static udp_stats_t udp_stats = {0, 0, 0, 0, 0, 0, 0};

/* ── Debug hook ────────────────────────────────────────────────────
   Compiled out by default so this file stays quiet; flip
   UDP_DEBUG_ENABLED locally during bring-up. Not wired to a specific
   logging call since this file doesn't own logging policy. */
#define UDP_DEBUG_ENABLED 0
static inline void udp_debug(const char *msg)
{
#if UDP_DEBUG_ENABLED
    (void)msg; /* wire to kernel log function if desired */
#else
    (void)msg;
#endif
}

/* ── Pseudo-header checksum ───────────────────────────────────────
   RFC 768's UDP checksum covers a 12-byte IPv4 pseudo-header (src
   addr, dst addr, zero byte, protocol, UDP length) in addition to
   the UDP header and payload. ipv4_checksum() sums a flat byte
   range using ones'-complement arithmetic, and that arithmetic does
   not distribute over two separately-folded partial checksums --
   they can't be correctly combined after the fact. So the pseudo-
   header is assembled directly in front of a copy of the UDP
   message in one contiguous buffer, and ipv4_checksum() is called
   once over the whole thing, reusing its arithmetic rather than
   reimplementing it. */
static uint16_t udp_checksum(uint32_t src_ip, uint32_t dst_ip,
                              const uint8_t *udp_message, uint32_t udp_len)
{
    struct pseudo_header {
        uint32_t src_ip;
        uint32_t dst_ip;
        uint8_t  zero;
        uint8_t  protocol;
        uint16_t udp_len;
    } __attribute__((packed));

    uint8_t buf[sizeof(struct pseudo_header) + UDP_HDR_LEN + UDP_MAX_PAYLOAD];

    if(udp_len > UDP_HDR_LEN + UDP_MAX_PAYLOAD)
    {
        /* Should be unreachable -- callers only ever pass a udp_len
           already bounded by validation (receive path) or by
           udp_send()'s own UDP_MAX_PAYLOAD check (send path). Fail
           closed rather than overflow buf if that invariant is ever
           violated. */
        udp_debug("udp_checksum: message too large for pseudo-header buffer");
        return 0xFFFF; /* never equals a valid computed checksum of 0 */
    }

    struct pseudo_header *pseudo = (struct pseudo_header*)buf;
    pseudo->src_ip   = src_ip;
    pseudo->dst_ip   = dst_ip;
    pseudo->zero     = 0;
    pseudo->protocol = IPV4_PROTO_UDP;
    pseudo->udp_len  = htons((uint16_t)udp_len);

    uint8_t *msg_copy = buf + sizeof(struct pseudo_header);
    for(uint32_t i = 0; i < udp_len; i++)
        msg_copy[i] = udp_message[i];

    return ipv4_checksum(buf, sizeof(struct pseudo_header) + udp_len);
}

/* ── Packet validation ─────────────────────────────────────────────
   Every field read by this file lies within the first UDP_HDR_LEN
   bytes of the header, or within [UDP_HDR_LEN, len) for the
   payload -- the checks below are what make both provably safe.
   udp_len is the header's own claim about its size and is checked
   against the actual received length before being trusted. */
static int udp_packet_is_valid(uint32_t len, const struct udp_header *hdr,
                                uint32_t *out_udp_len)
{
    if(len < UDP_HDR_LEN)
    {
        udp_debug("udp: packet shorter than header");
        return 0;
    }

    uint32_t udp_len = ntohs(hdr->length);

    if(udp_len < UDP_HDR_LEN)
    {
        udp_debug("udp: length field smaller than header");
        return 0;
    }

    if(udp_len > len)
    {
        udp_debug("udp: length field exceeds received IPv4 payload");
        return 0;
    }

    *out_udp_len = udp_len;
    return 1;
}

/* ── Receive ───────────────────────────────────────────────────────
   Called by the IPv4 layer for every datagram with protocol UDP.
   Owns validation, checksum verification, and port dispatch --
   nothing here parses DHCP/DNS payloads, and unknown ports are
   counted and dropped rather than processed. */
void udp_receive(uint32_t src_ip, uint32_t dst_ip, uint8_t *buffer, uint32_t len)
{
    if(buffer == 0)
    {
        udp_stats.malformed++;
        udp_debug("udp: null buffer");
        return;
    }

    if(len < UDP_HDR_LEN)
    {
        udp_stats.malformed++;
        udp_debug("udp: packet too short");
        return;
    }

    struct udp_header *hdr = (struct udp_header*)buffer;

    uint32_t udp_len = 0;
    if(!udp_packet_is_valid(len, hdr, &udp_len))
    {
        udp_stats.malformed++;
        return;
    }

    if(hdr->checksum == 0)
    {
        /* Checksum disabled per RFC 768 -- valid, not an error, but
           worth tracking separately from packets that were actually
           verified. */
        udp_stats.checksum_disabled++;
        udp_debug("udp: checksum disabled");
    }
    else
    {
        uint16_t computed = udp_checksum(src_ip, dst_ip, buffer, udp_len);
        if(computed != 0)
        {
            udp_stats.checksum_failures++;
            udp_debug("udp: checksum failure");
            return;
        }
    }

    uint16_t dst_port    = ntohs(hdr->dst_port);
    uint16_t src_port    = ntohs(hdr->src_port);
    uint8_t  *payload     = buffer + UDP_HDR_LEN;
    uint32_t  payload_len = udp_len - UDP_HDR_LEN;

    switch(dst_port)
    {
        case UDP_PORT_DHCP_CLIENT:
            udp_stats.rx_packets++;
            dhcp_receive(src_ip, src_port, payload, payload_len);
            break;

        case UDP_PORT_DNS:
            udp_stats.rx_packets++;
            dns_receive(src_ip, src_port, payload, payload_len);
            break;

        default:
            udp_stats.unknown_port++;
            udp_debug("udp: unknown destination port");
            break;
    }
}

/* ── Send ────────────────────────────────────────────────────────
   Builds a UDP header around payload and hands the assembled
   message to ipv4_send(). Payload bytes are copied byte-for-byte
   and never modified -- callers can rely on their buffer contents
   appearing on the wire exactly as given. */
int udp_send(uint32_t dst_ip, uint16_t src_port, uint16_t dst_port,
             const uint8_t *payload, uint32_t payload_len)
{
    if(payload == 0 && payload_len != 0)
    {
        udp_debug("udp_send: null payload with nonzero length");
        return 0;
    }

    if(payload_len > UDP_MAX_PAYLOAD)
    {
        udp_debug("udp_send: payload too large for a single datagram");
        return 0;
    }

    uint8_t  message[UDP_HDR_LEN + UDP_MAX_PAYLOAD];
    uint32_t udp_len = UDP_HDR_LEN + payload_len;

    struct udp_header *hdr = (struct udp_header*)message;
    hdr->src_port = htons(src_port);
    hdr->dst_port = htons(dst_port);
    hdr->length   = htons((uint16_t)udp_len);
    hdr->checksum = 0; /* computed below, after the payload is in place */

    if(payload_len > 0)
    {
        uint8_t *body = message + UDP_HDR_LEN;
        for(uint32_t i = 0; i < payload_len; i++)
            body[i] = payload[i];
    }

    uint16_t checksum = udp_checksum(local_ip, dst_ip, message, udp_len);
    /* RFC 768: a computed checksum of exactly zero is transmitted as
       all-ones, since zero is reserved to mean "checksum disabled". */
    hdr->checksum = htons(checksum == 0 ? 0xFFFF : checksum);

    int sent = ipv4_send(dst_ip, IPV4_PROTO_UDP, message, udp_len);
    if(sent)
        udp_stats.tx_packets++;
    else
        udp_stats.dropped++;

    return sent;
}

/* ── Stats accessor ────────────────────────────────────────────── */
udp_stats_t udp_get_stats(void)
{
    return udp_stats;
}