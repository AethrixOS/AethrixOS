#ifndef AETHRIX_ENDIAN_H
#define AETHRIX_ENDIAN_H

#include <stdint.h>

static inline uint16_t swap16(uint16_t x)
{
    return (x<<8)|(x>>8);
}

#define htons(x) swap16(x)
#define ntohs(x) swap16(x)

#endif