# Aethrix OS Roadmap

> **Long-term development roadmap for Aethrix OS**

---

# Vision

Aethrix OS is a modern operating system built completely from scratch in **C** and **x86 Assembly** for educational, research, and engineering purposes.

The project's objective is to understand every major component of an operating system by implementing it manually instead of relying on existing kernels.

The long-term goal is to create a lightweight, modular, stable operating system capable of running on both virtual machines and real x86 hardware.

---

# Current Status

**Version:** v1.0

Current development includes:

- Bootloader
- Protected Mode
- VGA Console
- Keyboard Driver
- ATA Disk Driver
- Basic Filesystem
- User Management
- Shell
- PCI Detection
- Ethernet
- ARP
- IPv4
- ICMP
- UDP
- DNS
- DHCP (Under Development)
- TCP (Under Development)
- Socket API (Under Development)

---

# Development Philosophy

Aethrix OS follows these principles:

- Simplicity
- Reliability
- Modularity
- Maintainability
- Performance
- Security
- Educational Value

Every subsystem should be:

- Well documented
- Independently maintainable
- Easy to understand
- Easy to debug

---

# Development Roadmap

---

# Phase 1 — Foundation ✅

Completed

- Bootloader
- Protected Mode
- VGA Driver
- Keyboard Driver
- Shell
- ATA Driver
- Basic Filesystem
- User Login
- PCI Detection

Status:

**Completed**

---

# Phase 2 — Hardware Support

Objectives

- Improve PCI Detection
- Stable ATA Driver
- AHCI Driver
- USB Support
- Timer Improvements
- Interrupt Handling
- Better Hardware Detection

Status:

**In Progress**

---

# Phase 3 — Networking Core

Objectives

- Ethernet
- ARP
- IPv4
- Routing
- Packet Queue
- Checksum Validation

Status:

**Mostly Completed**

---

# Phase 4 — Internet Connectivity

Objectives

- DHCP Client
- Automatic IPv4 Configuration
- Gateway Detection
- DNS Resolver
- Reliable Ping
- Connection Verification

Goal

Aethrix OS should automatically obtain network configuration without requiring manual IP assignment.

Status:

**In Progress**

---

# Phase 5 — Transport Layer

Objectives

- UDP
- TCP
- Socket API
- Connection Management
- Retransmission
- Flow Control

Status:

**In Progress**

---

# Phase 6 — Filesystem

Objectives

- Directory Tree
- Metadata
- Permissions
- Improved Storage
- File Management
- Journaling (Future)

Status:

**Planned**

---

# Phase 7 — Memory Management

Objectives

- Physical Memory Manager
- Virtual Memory
- Paging
- Heap
- Dynamic Allocation
- Shared Memory

Status:

**Planned**

---

# Phase 8 — Multitasking

Objectives

- Scheduler
- Processes
- Threads
- Context Switching
- System Timer
- Priorities

Status:

**Planned**

---

# Phase 9 — System Calls

Objectives

- User Mode
- Kernel Mode
- System Call Interface
- Process Management
- File API

Status:

**Planned**

---

# Phase 10 — Graphical Environment

Objectives

- Framebuffer Driver
- Mouse Support
- Window Manager
- Desktop
- Graphics Library
- Fonts

Status:

**Planned**

---

# Phase 11 — Security

Objectives

- File Permissions
- User Groups
- Password Security
- Access Control
- Secure Authentication

Status:

**Planned**

---

# Phase 12 — Applications

Objectives

- Text Editor
- Calculator
- File Manager
- Terminal
- Settings
- Image Viewer

Status:

**Planned**

---

# Phase 13 — Internet Applications

Objectives

- HTTP Client
- HTTPS Support
- Web Browser
- Package Manager
- Software Installer

Status:

**Future**

---

# Phase 14 — Artificial Intelligence

Objectives

- AI Terminal Assistant
- Natural Language Commands
- Command Suggestions
- Local Automation
- Future Cloud Integration

Status:

**Future**

---

# Phase 15 — Hardware Expansion

Objectives

- USB Devices
- Audio Drivers
- Printing
- Wi-Fi Improvements
- Bluetooth
- Modern Storage Devices

Status:

**Future**

---

# Phase 16 — Optimization

Objectives

- Faster Boot Time
- Lower Memory Usage
- Better Driver Performance
- Reduced CPU Usage
- Kernel Optimization

Status:

**Future**

---

# Phase 17 — Aethrix OS 2.0

Goals

- Stable Networking
- Stable Filesystem
- Stable Memory Manager
- Stable Scheduler
- Improved Shell
- Better Hardware Support
- Initial GUI

---

# Phase 18 — Aethrix OS 3.0

Goals

- Modern Desktop Environment
- Browser
- Package Manager
- AI Assistant
- USB Support
- Audio Support
- Multi-user Environment
- Improved Security

---

# Supported Platforms

Current

- QEMU
- VirtualBox
- VMware
- Legacy x86 BIOS Systems

Future

- Real Desktop PCs
- Real Laptops
- UEFI Systems
- x86_64 Architecture

---

# Long-Term Goals

- Complete operating system built entirely from scratch.
- Stable networking stack.
- Reliable filesystem.
- Modular kernel architecture.
- Clean, maintainable source code.
- Comprehensive documentation.
- Educational value for operating system development.
- Support for both virtual machines and real hardware.

---

# Current Priorities

The current focus of development is:

1. Stabilize the networking stack.
2. Complete automatic DHCP and IPv4 configuration.
3. Improve compatibility with real hardware.
4. Refactor the kernel into modular components.
5. Reduce compiler warnings and improve code quality.
6. Expand documentation.

---

# Project Milestones

| Version | Milestone | Status |
|----------|-----------|--------|
| v1.0 | Bootable Kernel | ✅ Completed |
| v1.1 | Stable Networking | 🚧 In Progress |
| v1.2 | Modular Kernel | ⏳ Planned |
| v1.3 | Memory Management | ⏳ Planned |
| v1.4 | Multitasking | ⏳ Planned |
| v1.5 | System Calls | ⏳ Planned |
| v2.0 | GUI Release | ⏳ Planned |
| v2.5 | Internet Applications | 🔮 Future |
| v3.0 | AI-Integrated Operating System | 🔮 Future |

---

# Closing Statement

Aethrix OS is an ongoing long-term project driven by curiosity, learning, and continuous improvement.

Each milestone represents another step toward building a complete operating system while gaining a deeper understanding of computer architecture, low-level programming, and systems engineering.

The roadmap will continue to evolve as the project grows and new ideas are explored.

---

**Last Updated:** June 2026

**Current Version:** v1.0
