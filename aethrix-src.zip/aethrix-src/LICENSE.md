# Aethrix Public License (APL) v1.0

Copyright (c) 2026 Aethrix OS Project

All rights reserved.

---

# 1. Ownership

Aethrix OS and all associated source code, documentation, build scripts, assets, and design materials are the exclusive intellectual property of the Aethrix OS Project unless otherwise stated.

Ownership of this software is not transferred under this license.

---

# 2. Permission to Use

You are permitted to:

- Download official releases.
- Install and run Aethrix OS.
- Use the operating system for personal, educational, or research purposes.
- Evaluate and test the operating system.

---

# 3. Restrictions

Without prior written permission from the copyright holder, you may NOT:

- Copy the source code.
- Redistribute the source code.
- Publish the source code.
- Upload the source code to public repositories.
- Modify the source code.
- Reverse engineer the source code for redistribution.
- Sell any part of the project.
- Claim ownership of any portion of Aethrix OS.
- Create derivative operating systems based on the Aethrix OS source code.

---

# 4. Commercial Use

Commercial use of Aethrix OS, its source code, or any substantial portion of the project is prohibited unless explicit written permission has been granted by the copyright holder.

---

# 5. Documentation

Documentation included with Aethrix OS may be referenced for educational purposes provided proper attribution is given.

Documentation may not be copied in its entirety or redistributed as part of another project without permission.

---

# 6. Contributions

Any contribution voluntarily submitted to the Aethrix OS Project may be reviewed and accepted at the sole discretion of the project maintainers.

Submitting a contribution does not transfer ownership of the entire project.

Unless otherwise agreed in writing, contributors retain copyright to their own original contributions while granting the project permission to include those contributions in future releases.

---

# 7. Third-Party Software

Third-party libraries, drivers, tools, or components included with Aethrix OS remain subject to their respective licenses.

Nothing in this license overrides those licenses.

---

# 8. Warranty Disclaimer

Aethrix OS is provided "AS IS" without warranty of any kind.

The authors make no guarantees regarding:

- Reliability
- Stability
- Performance
- Security
- Fitness for a particular purpose

Use of this software is entirely at your own risk.

---

# 9. Limitation of Liability

In no event shall the authors or contributors be liable for any damages arising from the use or inability to use Aethrix OS.

This includes, but is not limited to:

- Data loss
- Hardware damage
- Software corruption
- Business interruption
- Financial loss

---

# 10. Termination

Any violation of this license immediately terminates all rights granted under it.

Upon termination, all unauthorized copies of the software and source code must be destroyed.

---

# 11. Reservation of Rights

All rights not expressly granted by this license are reserved by the copyright holder.

---

# 12. Contact

For licensing questions or permission requests, contact the Aethrix OS Project through its official project repository or designated communication channels.

---

© 2026 Aethrix OS Project

All Rights Reserved.
